<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Savemp3
 * @since 1.0
 */

global $savemp3_options;

$custom_home_page           = !empty( $savemp3_options['home_page'] )?$savemp3_options['home_page'] : '';
$current_language           = apply_filters( 'wpml_current_language', NULL );
$custom_home_page           = apply_filters( 'wpml_object_id', $custom_home_page, 'page', true, $current_language );
$custom_home_page           = get_permalink( $custom_home_page );
?>

		<footer class="footer">
			<div class="container--xl">
				<div class="footer--wrap">
					<a href="<?php echo $custom_home_page; ?>" class="footer--logo">
						<img src="<?php echo SVMP3_URL; ?>/images/logo.png" alt="Logo">
					</a>

					<div class="footer--menu">
						<?php
							wp_nav_menu(
								array(
									'theme_location' => 'footer-menu',
									'menu_class'     => 'menu',
									'container'      => '',
								)
							);
						?>

						<p class="copyright">&copy;
							<?php echo date("Y"); ?> <?php _e('Savemp3.net All rights reserved', 'savemp3'); ?>
						</p>
					</div>

					<div class="social">
						<a href="https://www.facebook.com/savemp3net/" class="social--link facebook" target="_blank">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-facebook"></use>
								</svg>
							</i>
						</a>
					</div>
				</div>
			</div>

			<div class="languages" id="language--popup">
				<button class="languages--close">
					<i class="icon">
						<svg>
							<use xlink:href="#icon-close"></use>
						</svg>
					</i>
				</button>

				<div class="languages--wrap">
					<h3 class="languages--title">Select Language</h3>

					<?php do_action('wpml_add_language_selector'); ?>
				</div>
			</div>
		</footer>

		<?php wp_footer(); ?>
	</body>
</html>
