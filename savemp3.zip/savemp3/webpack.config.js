
const path = require('path');

const ESLintPlugin = require('eslint-webpack-plugin');

const SpriteLoaderPlugin = require('svg-sprite-loader/plugin');
// SASS Compilation and CSS Post Processing
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const autoprefixer = require('autoprefixer');
const cssnano = require('cssnano');

const TsconfigPathsPlugin = require('tsconfig-paths-webpack-plugin');
const { VueLoaderPlugin } = require('vue-loader');

const StylelintPlugin = require('stylelint-webpack-plugin');
const webpack = require('webpack');

module.exports = (env) => {
    const { mode } = env;
    const inProductionMode = mode === 'production';

    return {
        mode,
        stats: { colors: true, children: false, modules: false },
        performance: { hints: false },

        devtool: !inProductionMode ? 'inline-source-map' : false,
        plugins: [
            new ESLintPlugin({
                extensions: ['js', 'ts', 'vue'],
                failOnError: inProductionMode,
            }),

            new webpack.DefinePlugin({
                __VUE_OPTIONS_API__: JSON.stringify(false),
                __VUE_PROD_DEVTOOLS__: JSON.stringify(false),
            }),

            new VueLoaderPlugin(),

            new StylelintPlugin({
                configFile: '.stylelintrc',
                context: './resources/sass',
            }),

            new MiniCssExtractPlugin({
                filename: '../css/[name].css',
            }),

            new webpack.ProvidePlugin({
                $: 'jquery',
                jQuery: 'jquery',
                'window.jQuery': 'jquery',
            }),

            new SpriteLoaderPlugin({
                plainSprite: true,
            }),
        ],

        resolve: {
            plugins: [new TsconfigPathsPlugin({})],
            extensions: ['.js', '.ts', '.vue'],
        },
        entry: './resources/ts/main.ts',

        output: {
            path: path.resolve(__dirname, 'js'),
            filename: '[name].js',
        },

        module: {
            rules: [
                {
                    include: path.resolve(__dirname, 'resources/ts'),
                    test: /\.vue$/,
                    loader: 'vue-loader',
                    options: {
                        transformAssetUrls: { img: [], video: [] },
                        hotReload: false,
                        productionMode: inProductionMode,
                    },
                },
                {
                    include: path.resolve(__dirname, 'resources/ts'),
                    test: /\.ts(x?)$/,
                    loader: 'ts-loader',
                    options: {
                        appendTsSuffixTo: [/\.vue$/],
                        // TODO: Remove when fixed: https://github.com/vuejs/core/issues/2613
                        ignoreDiagnostics: [2345],
                        transpileOnly: inProductionMode,
                    },
                },
                {
                    test: /\.(scss|css)$/,

                    use: [
                        {
                            loader: MiniCssExtractPlugin.loader,
                            // Required for font-face to work
                            options: { publicPath: '' },
                        },
                        {
                            loader: 'css-loader',
                            options: {
                                url: {
                                    filter(url) {
                                        // Don't resolve url() in public assets
                                        return !/\.\/images\//.test(url);
                                    },
                                },
                            },
                        },
                        {
                            loader: 'postcss-loader',
                            options: {
                                postcssOptions: {
                                    plugins: env.mode === 'production' ? [autoprefixer(), cssnano()] : [autoprefixer()],
                                },
                            },
                        },
                        'resolve-url-loader',
                        {
                            loader: 'sass-loader',
                            // Required for 'resolve-url-loader' to work in production
                            options: { sourceMap: true },
                        },
                    ],
                },
                {
                    test: /\.svg$/,
                    use: [
                        'svg-sprite-loader',
                        'svgo-loader',
                    ],
                },
            ],
        },
    };
};
