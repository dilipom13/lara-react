<?php
/**
 * The header for our theme
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Savemp3
 * @since 1.0
 */

global $savemp3_options, $browser;

$dropbox_upload             =  !empty( $_COOKIE['dropbox_upload'] )?$_COOKIE['dropbox_upload']:'on';
$gdrive_upload              =  !empty( $_COOKIE['gdrive_upload'] )?$_COOKIE['gdrive_upload']:'on';
$select_quality             =  !empty( $_COOKIE['select_quality'] )?$_COOKIE['select_quality']:'128kbps';

$custom_home_page           = !empty( $savemp3_options['home_page'] )?$savemp3_options['home_page'] : '';
$current_language           = apply_filters( 'wpml_current_language', NULL );
$custom_home_page           = apply_filters( 'wpml_object_id', $custom_home_page, 'page', true, $current_language );
$custom_home_page           = get_permalink( $custom_home_page );
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<?php wp_head(); ?>
	</head>

	<body <?php body_class(); ?> cz-shortcut-listen="true">
	<?php if( !is_page_template('page-templates/landing-page.php') ){ ?>
		<header class="header">
			<div class="container--xl">
				<nav class="navbar">
					<a href="<?php echo $custom_home_page; ?>" class="logo">
						<img src="<?php echo SVMP3_URL; ?>/images/logo.png" alt="Logo">
						<span class="thin">Save</span>
						<span class="thick">MP3</span>
					</a>

					<?php
						// wp_nav_menu( array(
						//     'theme_location' => 'main-menu',
						//     'menu_class'     => 'menu header--menu',
						//     'container'      => '',
						// ) );
					?>

					<ul id="menu-main-menu" class="menu header--menu">
						<li class="menu--item has-submenu">
							<a href="#">
								<i class="icon">
									<svg><use xlink:href="#icon-popular"></use></svg>
								</i>

								Popular Tools
							</a>

							<div class="submenu--wrap">
								<div class="submenu">
									<h3 class="submenu--title">Tools</h3>

									<ul class="submenu--list">
										<li class="submenu--item">
											<a href="#">
												<i class="icon">
													<svg><use xlink:href="#icon-video-mp3"></use></svg>
												</i>
												Video to mp3
											</a>
										</li>

										<li class="submenu--item">
											<a href="#">
												<i class="icon">
													<svg><use xlink:href="#icon-youtube-mp3"></use></svg>
												</i>

												YouTube to mp3
											</a>
										</li>

										<li class="submenu--item">
											<a href="#">
												<i class="icon">
													<svg><use xlink:href="#icon-soundcloud-mp3"></use></svg>
												</i>
												Soundcloud to mp3
											</a>
										</li>

										<li class="submenu--item">
											<a href="#">
												<i class="icon">
													<svg><use xlink:href="#icon-dailymotion-mp3"></use></svg>
												</i>
												Dailymotion to mp3
											</a>
										</li>

										<li class="submenu--item">
											<a href="#">
												<i class="icon">
													<svg><use xlink:href="#icon-vimeo-mp3"></use></svg>
												</i>
												Vimeo to mp3
											</a>
										</li>
									</ul>
								</div>

								<div class="submenu odd">
									<h3 class="submenu--title">More</h3>

									<ul class="submenu--list">
										<li class="submenu--item">
											<a href="#">
												<i class="icon">
													<svg><use xlink:href="#icon-help"></use></svg>
												</i>

												How to use
											</a>
										</li>

										<li class="submenu--item">
											<a href="#">
												<i class="icon">
													<svg><use xlink:href="#icon-developer"></use></svg>
												</i>
												Developer
											</a>
										</li>
									</ul>
								</div>
							</div>
						</li>

						<li class="menu--item">
							<a href="/trending/">
								<i class="icon">
									<svg><use xlink:href="#icon-trending"></use></svg>
								</i>
								Trending
							</a>
						</li>

						<li class="menu--item">
							<a href="/identify-music/">
								<i class="icon">
									<svg><use xlink:href="#icon-identify-music"></use></svg>
								</i>

								identify Music
							</a>
						</li>

						<li class="menu--item">
							<a href="/identify-music/">
								<i class="icon">
									<svg><use xlink:href="#icon-chrome-flat"></use></svg>
								</i>

								Addon
							</a>
						</li>

						<li class="menu--item">
							<a href="/identify-music/">
								<i class="icon">
									<svg><use xlink:href="#icon-help"></use></svg>
								</i>

								How to use
							</a>
						</li>
					</ul>
<!--
					<div class="download">
						<button class="download--init header--download">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-<?php echo strtolower($browser['browser_name']); ?>"></use>
								</svg>
							</i>
							<span class="text"><?php _e("Add to", 'savemp3'); ?> <?php echo strtolower($browser['browser_name']); ?></span>
						</button>

						<?php if( $browser['browser_name'] == 'Chrome' || $browser['browser_name'] == 'Edge' || $browser['browser_name'] == 'Yandex Browser' || $browser['browser_name'] == 'UC Browser') { ?>
							<div class="dd--popup download--dropdown" id="main-download">
								<button class="dd--popup-close download--close"></button>
								<div class="dd--details">
									<div class="dd--icon">
										<img src="<?php echo SVMP3_URL; ?>/images/icon-crosspilot.png" alt="dd--icon">
									</div>

									<p class="dd--desc"> <b><?php _e('Crosspilot', 'savemp3'); ?></b> <?php _e('extension is needed to make YouTube Video
										Downloader work properly.', 'savemp3'); ?></p>
								</div>
								<div class="dd--actions">
									<a href="https://chrome.google.com/webstore/detail/crosspilot/migomhggnppjdijnfkiimcpjgnhmnale"
										target="_blank" class="btn--primary">
										<i class="icon"><img src="<?php echo SVMP3_URL; ?>/images/icon-webstore.png" alt="webstore"></i>
										<span><?php _e("Let's Go", 'savemp3'); ?></span>
									</a>

									<a class="link-text" data-fancybox=""
										href="https://www.youtube.com/watch?v=ol1bVODJm2g">
										<?php _e("Watch video", 'savemp3'); ?>
									</a>
								</div>
							</div>
						<?php } ?>

						<?php if( $browser['browser_name'] == 'Opera' ) { ?>

							<div class="dd--popup download--dropdown" id="main-download">
								<button class="dd--popup-close download--close"></button>

								<div class="dd--details">
									<div class="dd--icon">
										<img src="https://cdn-icons-png.flaticon.com/512/2476/2476231.png" alt="dd--icon">
									</div>

									<p class="dd--desc"><?php _e("It will show you a notification in the header. Upon clicking, It will take you to your Opera browser's extensions page. From there, click Install.", 'savemp3'); ?></p>
								</div>

								<div class="dd--actions">
									<a data-browser="Opera" href="javascript:void(0)" data-addon-id="44" class="ac-download-available download_counter btn-primary_green" rel="noopener noreferrer">
											<i class="icon"><img src="http://localhost/wordpress/wp-content/themes/addoncrop-theme/assets/images/icon-webstore.png" alt="webstore"></i>
											<span><?php _e('Download', 'savemp3'); ?></span>
									</a>

									<a class="link-text" data-fancybox="" href="https://www.youtube.com/watch?v=ol1bVODJm2g">
										<?php _e('Watch video', 'savemp3'); ?>
									</a>
								</div>
							</div>
						<?php } ?>

						<?php if( $browser['browser_name'] == 'Firefox' ) { ?>
							<div class="dd--popup download--dropdown" id="main-download">
								<button class="dd--popup-close download--close"></button>
								<div class="dd--details">
									<div class="dd--icon">
										<img src="http://localhost/wordpress/wp-content/uploads/2021/12/icon-tempermonkey.png" alt="dd--icon">
									</div>

									<p class="dd--desc">
										<?php _e('Please, install', 'savemp3'); ?> <a target="_blank" href="https://chrome.google.com/webstore/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo?hl=en" rel="noopener"><?php _e('Tampermonkey', 'savemp3'); ?></a>
										<?php _e('extension To add YouTube Video Downloader to Chrome properly.', 'savemp3'); ?>
									</p>
								</div>

								<div class="dd--steps">
									<a class="dd--step" target="_blank" href="https://chrome.google.com/webstore/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo?hl=en" rel="noopener">
										<label for=""><?php _e('Step 1', 'savemp3'); ?></label>
										<span><?php _e('Install', 'savemp3'); ?> <b><?php _e('Tampermonkey', 'savemp3'); ?></b></span>
									</a>
									<a href="https://userscript.s3.amazonaws.com/youtube-downloader/youtube-downloader.user.js" data-addon-id="42" data-extension-id="44" class="download_counter ac_us_dow_get dd--step onclick-loader">
										<label for=""><?php _e('Step 2', 'savemp3'); ?></label>
										<span><?php _e('Install', 'savemp3'); ?> <strong><?php _e('Userscript', 'savemp3'); ?></strong></span>
										<div class="loader">
											<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19 17">
												<circle class="loadingCircle" cx="2.2" cy="10" r="1.6"></circle>
												<circle class="loadingCircle" cx="9.5" cy="10" r="1.6"></circle>
												<circle class="loadingCircle" cx="16.8" cy="10" r="1.6"></circle>
											</svg>
										</div>
									</a>

								</div>

								<div class="dd--actions">
									<a class="link-text" data-fancybox="" href="https://www.youtube.com/watch?v=ol1bVODJm2g">
										<?php _e('Watch video', 'savemp3'); ?>
									</a>
								</div>
							</div>
						<?php } ?>
					</div> -->

					<div class="settings">
						<button class="settings--init">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-settings"></use>
								</svg>
							</i>
						</button>

						<ul class="settings--menu">
							<label class="menu--label"><?php _e('Settings', 'savemp3'); ?></label>

							<label for="darkMode-init" class="settings--item">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-darkmode"></use>
									</svg>
								</i>

								<span class="text">
									<?php _e('Dark mode', 'savemp3'); ?>
								</span>


								<div class="toggle">
									<input type="checkbox" class="toggle--init" id="darkMode-init">
									<div class="toggle--circle">
										<span class="toggle--sign" id="dark-mode"></span>
									</div>
								</div>
							</label>

							<label for="article-switch" class="settings--item">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-article-hidden"></use>
									</svg>
								</i>

								<span class="text">
									<?php _e('Hide Article', 'savemp3'); ?>
								</span>

								<div class="toggle--switch toggle--text">
									<input type="checkbox" id="article-switch">
									<label for="article-switch"></label>
								</div>
							</label>

							<li class="settings--item">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-quality"></use>
									</svg>
								</i>

								<span class="text">
									<?php _e('Select quality', 'savemp3'); ?>
								</span>

								<select class="quality-hidden-select" data-menu="horizontal">
									<option <?php echo ($select_quality == '128kbps' )?'selected':''; ?> >128kbps</option>
									<option <?php echo ($select_quality == '256kbps' )?'selected':''; ?> >256kbps</option>
									<option <?php echo ($select_quality == '320kbps' )?'selected':''; ?> >320kbps</option>
								</select>
							</li>

							<?php if( !empty( $savemp3_options['enable_dropbox_drive'] ) ){ ?>
								<label class="settings--item">
									<i class="icon">
										<svg>
											<use xlink:href="#icon-dropbox"></use>
										</svg>
									</i>

									<span class="text">
										<?php _e('Dropbox upload', 'savemp3'); ?>
									</span>

									<div class="toggle--switch toggle--text">
										<input type="checkbox" id="toggle-dropbox" <?php echo ($dropbox_upload == 'on')?'checked':''; ?> >
										<label for="toggle-dropbox"></label>
									</div>
								</label>
							<?php } ?>

							<?php if( !empty( $savemp3_options['enable_google_drive'] ) ){ ?>
								<label class="settings--item">
									<i class="icon">
										<svg>
											<use xlink:href="#icon-gdrive"></use>
										</svg>
									</i>

									<span class="text">
										<?php _e('GDrive upload', 'savemp3'); ?>
									</span>

									<div class="toggle--switch toggle--text">
										<input type="checkbox" id="toggle-gdrive" <?php echo ($gdrive_upload == 'on')?'checked':''; ?>>
										<label for="toggle-gdrive"></label>
									</div>
								</label>
							<?php } ?>
						</ul>
					</div>

					<button class="languages--init" rel="language--popup">
						<i class="icon">
							<svg><use xlink:href="#icon-lang-<?php echo ICL_LANGUAGE_CODE; ?>"></use></svg>
						</i>

						<span class="text"><?php echo ICL_LANGUAGE_NAME; ?></span>
					</button>

					<div class="burger-menu"></div>
				</nav>
			</div>
		</header>

		<div class="mobile--menu-wrap">
			<?php
				wp_nav_menu( array(
					'theme_location' => 'mobile-menu',
					'menu_class'     => 'mobile--menu',
					'container'      => '',
				) );
			?>
		</div>
	<?php } ?>
