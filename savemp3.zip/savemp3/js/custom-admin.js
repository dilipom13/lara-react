jQuery(document).ready(function ($) {

    if( $('.savemp3_select2').length ){
        $('.savemp3_select2').select2();    
    } 
    

    /******************************** Theme Options START **********************************/


    //Add more language
    jQuery(document).on("click", ".add_supported_sites_item", function () {
        var cls_ele = $('.rpt-supported-site-item-wrap');
        /* Retrieve the highest current key */
        var key = highest = 1;
        cls_ele.find('.rpt-supported-site-item').each(function () {
            var current = $(this).data('key');
            if (parseInt(current) > highest) {
                highest = current;
            }
        });
        key = highest += 1;
        clone = jQuery(".rpt-supported-site-item").first().clone();
        clone.attr('data-key', key);

        clone.find('input').val('').each(function () {
            var name = $(this).attr('name');
            if (name) {
                name = name.replace(/\[(\d+)\]/, '[' + parseInt(key) + ']');
                $(this).attr('name', name);
            }

        });

        clone.find('.savemp3_class').val('');
        clone.find('.savemp3_name').val('');
        clone.find('.savemp3_link').val('');
        jQuery('.rpt-supported-site-item-wrap').append(clone);

    });



    jQuery(document).on("click", "#supported_sites_options .delete", function () {
        if ($(".rpt-supported-site-item-wrap .rpt-supported-site-item").length > 1) {
            var r = confirm("Are you sure you want to remove this");
            if (r == true) {
                $(this).parent().remove();
            }
        } else {
            alert('You must have at least one element');
        }
    });





    // Update theme options
    $(document).on('click', '.wpos-settings-submit', function () {

        var current_obj = $(this);
        current_obj.attr('disabled', 'disabled');
        // $('.savemp3-success').css('top', ''); // Reset top position
        current_obj.parent().find('.spinner').css('visibility', 'visible');
        //tinyMCE.triggerSave(); // Imp to save wordpress editor content
        var data = {
            action: 'savemp3_update_theme_options',
            form_data: $('.savemp3-settings-form').serialize()
        };
        $.post(ajaxurl, data, function (response) {
            var result = $.parseJSON(response);

            if (result.success == 1) {
                current_obj.removeAttr('disabled', 'disabled');
                current_obj.parent().find('.spinner').css('visibility', 'hidden');
                $('.savemp3-success').show();
            }
        });
        setTimeout("jQuery('.savemp3-success').fadeOut();", 2500);
        return false;
    });

    if ($('.sh-select2').length > 0) {
        $(".sh-select2").select2();
    }

    $(document).on('click', '.genrate_new_url', function () {

        var current_obj = $(this);
        var posts = current_obj.parent().find('.post_list_genrate').val();
        var data = {
            'action': 'wpos_genrate_new_url',
            'posts': posts,
        };

        $.post(ajaxurl, data, function (response) {
            $('.slug_result').html(response.html);

        });

    });

    $(document).on('click', '.theme_setting_import_btn', function () {
        var current_obj = $(this);

        var theme_setting_import = $('#theme_setting_import').val();

        if (theme_setting_import != '') {

            current_obj.attr('disabled', 'disabled');
            $('#theme_setting_import').attr('style', 'none');
            theme_setting_import = JSON.stringify(theme_setting_import);
            var data = {
                action: 'savemp3_update_theme_options_import',
                form_data: theme_setting_import,
            };

            $.post(ajaxurl, data, function (response) {
                var result = $.parseJSON(response);
                if (result.success == 1) {

                    current_obj.removeAttr('disabled', 'disabled');
                    current_obj.parent().find('.spinner').css('visibility', 'hidden');
                    $('.savemp3-success').show();
                    $('#theme_setting_import').val('');

                }

                setTimeout("jQuery('.savemp3-success').fadeOut();", 2500);
                return false;

            });
        } else {

            $('#theme_setting_import').attr('style', 'border: 3px solid red');
        }

    });

    //  Theme tabs
    $(document).on('click', '.wpos-tab-nav-li a', function () {
        if (!$(this).closest('.wpos-tab-nav-li').hasClass("wpos-tab-nav-li-active")) {
            $('.wpos-sub-tab-nav').slideUp();
        }

        //  First remove class "active" from currently active tab
        $(".wpos-tab-nav-li").removeClass('wpos-tab-nav-li-active');
        $(".wpos-tab-nav-li a").removeClass('wpos-tab-nav-active');

        //  Now add class "active" to the selected/clicked tab
        $(this).closest('.wpos-tab-nav-li').addClass('wpos-tab-nav-li-active');
        $(this).addClass("wpos-tab-nav-active");

        //  Hide all tab content
        $(".wpos-tab-cnt").hide();

        //  Here we get the href value of the selected tab
        var selected_tab = $(this).attr("href");

        //  Show the selected tab content
        $(selected_tab).fadeIn('slow');

        if ($(this).parent().find('.wpos-sub-tab-nav').is(':hidden')) {
            $(this).parent().find('.wpos-sub-tab-nav').slideDown();
        }

        //  At the end, we add return false so that the click on the link is not executed
        return false;
    });

    /******************************** Theme Options END **********************************/

    /******************************** Upload screenshots START **********************************/

    // Media Uploader for Upload screenshots
    $(document).on('click', '.wpos-img-uploader', function () {
        var imgfield, showfield;
        imgfield = jQuery(this).prev('input').attr('id');
        showfield = jQuery(this).parents('td').find('.wpos-imgs-preview');
        var multiple_img = jQuery(this).attr('data-multiple');
        multiple_img = (typeof (multiple_img) != 'undefined' && multiple_img == 'true') ? true : false;
        if (typeof wp == "undefined" || savemp3admin.new_ui != '1') { // check for media uploader
            tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
            window.original_send_to_editor = window.send_to_editor;
            window.send_to_editor = function (html) {
                if (imgfield) {
                    var mediaurl = $('img', html).attr('src');
                    $('#' + imgfield).val(mediaurl);
                    showfield.html('<img src="' + mediaurl + '" />');
                    tb_remove();
                    imgfield = '';
                } else {
                    window.original_send_to_editor(html);
                }
            };
            return false;
        } else {
            var file_frame;

            //new media uploader
            var button = jQuery(this);

            // If the media frame already exists, reopen it.
            if (file_frame) {
                file_frame.open();
                return;
            }

            if (multiple_img == true) {
                // Create the media frame.
                file_frame = wp.media.frames.file_frame = wp.media({
                    title: button.data('title'),
                    button: {
                        text: button.data('button-text'),
                    },
                    multiple: true  // Set to true to allow multiple files to be selected
                });
            } else {
                // Create the media frame.
                file_frame = wp.media.frames.file_frame = wp.media({
                    frame: 'post',
                    state: 'insert',
                    title: button.data('title'),
                    button: {
                        text: button.data('button-text'),
                    },
                    multiple: false  // Set to true to allow multiple files to be selected
                });
            }

            file_frame.on('menu:render:default', function (view) {
                // Store our views in an object.
                var views = {};
                // Unset default menu items
                view.unset('library-separator');
                view.unset('gallery');
                view.unset('featured-image');
                view.unset('embed');
                // Initialize the views in our view object.
                view.set(views);
            });

            // When an image is selected, run a callback.
            file_frame.on('select', function () {
                // Get selected size from media uploader
                var selected_size = $('.attachment-display-settings .size').val();
                var selection = file_frame.state().get('selection');
                selection.each(function (attachment, index) {
                    attachment = attachment.toJSON();
                    // Selected attachment url from media uploader
                    var attachment_id = attachment.id ? attachment.id : '';
                    if (attachment_id && attachment.url && multiple_img == true) {

                        var attachment_url = attachment.url ? attachment.url : attachment.sizes.thumbnail.url;
                        var attachment_edit_link = attachment.editLink ? attachment.editLink : '';

                        showfield.append('\
							<div class="wpos-img-wrp">\
								<div class="wpos-img-tools wpos-hide">\
									<span class="wpos-tool-icon wpos-edit-img dashicons dashicons-edit" title="'+ savemp3admin.img_edit_popup_text + '"></span>\
									<a href="'+ attachment_edit_link + '" target="_blank" title="' + savemp3admin.attachment_edit_text + '"><span class="wpos-tool-icon wpos-edit-attachment dashicons dashicons-visibility"></span></a>\
									<span class="wpos-tool-icon wpos-del-tool wpos-del-img dashicons dashicons-no" title="'+ savemp3admin.img_delete_text + '"></span>\
								</div>\
								<img class="wpos-img" src="'+ attachment_url + '" alt="" />\
								<input type="hidden" class="wpos-attachment-no" name="savemp3_options[screen_shot_ids][]" value="'+ attachment_id + '" />\
							</div>\
								');
                        showfield.find('.wpos-img-placeholder').hide();
                    }
                });
            });

            // When an image is selected, run a callback.
            file_frame.on('insert', function () {


                // Get selected size from media uploader
                var selected_size = $('.attachment-display-settings .size').val();
                var selection = file_frame.state().get('selection');
                selection.each(function (attachment, index) {
                    attachment = attachment.toJSON();
                    // Selected attachment url from media uploader
                    var attachment_url = attachment.url ? attachment.url : attachment.sizes.thumbnail.url;
                    // place first attachment in field
                    $('#' + imgfield).val(attachment_url);
                    showfield.html('<img src="' + attachment_url + '" />');
                });
            });

            // Finally, open the modal
            file_frame.open();
        }
    });

    // Remove Single Gallery Image
    $(document).on('click', '.wpos-del-img', function () {
        $(this).closest('.wpos-img-wrp').fadeOut(300, function () {
            $(this).remove();
            if ($('.wpos-img-wrp').length == 0) {
                $('.wpos-img-placeholder').show();
            }
        });
    });

    // Remove All Gallery Image
    $(document).on('click', '.wpos-del-gallery-imgs', function () {
        var ans = confirm(savemp3admin.all_img_delete_text);
        if (ans) {
            $('.wpos-gallery-imgs-wrp .wpos-img-wrp').remove();
            $('.wpos-img-placeholder').fadeIn();
        }
    });

    /******************************** Upload screenshots END **********************************/




    /******************************** Addon FAQ config START **********************************/

    /* Clone repeatable FAQ setting field */
    $(document).on('click', '.sh-add-faq-repeatable', function () {
        var cls_ele = $(this).closest('.faq-control-wrap');
        /* Retrieve the highest current key */
        var key = highest = 1;
        cls_ele.find('.wpos-faq').each(function () {
            var current = $(this).data('key');
            if (parseInt(current) > highest) {
                highest = current;
            }
        });
        key = highest += 1;
        clone = $(".wpos-faq").first().clone();
        clone.attr('data-key', key);
        clone.find('input, select, textarea, label').val('').each(function () {
            var name = $(this).attr('name');
            var id = $(this).attr('id');
            var for_id = $(this).attr('for');

            if (name) {
                name = name.replace(/\[(\d+)\]/, '[' + parseInt(key) + ']');
                $(this).attr('name', name);
            }
            if (typeof id != 'undefined') {
                id = id.replace(/(\d+)/, parseInt(key));
                $(this).attr('id', id);
            }
            if (typeof for_id != 'undefined') {
                for_id = for_id.replace(/(\d+)/, parseInt(key));
                $(this).attr('for', for_id);
            }
        });
        clone.prependTo(".faq-control-repeater");
    });

    $(document).on('click', '.faq-control-wrap .full-faq-remove', function () {
        if ($('.faq-control-wrap .sh-pdt-file-rpt-upload-wrapper.wpos-faq').length > 1) {
            ans = confirm('Are you sure you want to remove');
            if (ans) {
                $(this).closest('.sh-pdt-file-rpt-upload-wrapper.wpos-faq').remove();
            }
        }
        else {
            alert('You can not remove all');
        }
    });

    $('.faq-control-repeater').sortable({
        items: '.wpos-faq',
        cursor: 'move',
        handle: '.sh-pdt-file-rpt-row-header',
        scrollSensitivity: 40,
        forcePlaceholderSize: true,
        forceHelperSize: false,
        helper: 'clone',
        opacity: 0.6,
        placeholder: 'sh-file-placeholder',
        containment: '.faq-control-repeater',
        start: function (event, ui) {
            ui.item.css('background-color', '#f6f6f6');
        },
        stop: function (event, ui) {
            ui.item.removeAttr('style');
        }
    });

    /******************************** Addon FAQ config END **********************************/



    /******************************** Addon Overview Media Uploader START **********************************/

    $(document).on('click', '.wpos-overview-image-upload', function () {
        var imgfield, showfield, img_idfield;
        imgfield = jQuery(this).closest('.wpos-overview-img').find('.wpos_overview_thumb_cls');
        img_idfield = jQuery(this).closest('.wpos-overview-img').find('.wpos_overview_thumb_id');
        showfield = jQuery(this).parents('.wpos-overview-img').find('.wpos_img_view');
        if (typeof wp == "undefined" || savemp3admin.new_ui != '1') { // Check for media uploader
            tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
            window.original_send_to_editor = window.send_to_editor;
            window.send_to_editor = function (html) {
                if (imgfield) {
                    var mediaurl = $('img', html).attr('src');
                    //imgfield.val(mediaurl);
                    showfield.html('<img src="' + mediaurl + '" />');
                    tb_remove();
                } else {
                    window.original_send_to_editor(html);
                }
            };
            return false;
        } else {
            var file_frame;
            //new media uploader
            var button = jQuery(this);

            // If the media frame already exists, reopen it.
            if (file_frame) {
                file_frame.open();
                return;
            }

            // Create the media frame.
            file_frame = wp.media.frames.file_frame = wp.media({
                frame: 'post',
                state: 'insert',
                title: button.data('uploader-title'),
                button: {
                    text: button.data('uploader-button-text'),
                },
                multiple: false  // Set to true to allow multiple files to be selected
            });

            file_frame.on('menu:render:default', function (view) {
                // Store our views in an object.
                var views = {};

                // Unset default menu items
                view.unset('library-separator');
                view.unset('gallery');
                view.unset('featured-image');
                view.unset('embed');

                // Initialize the views in our view object.
                view.set(views);
            });

            // When an image is selected, run a callback.
            file_frame.on('insert', function () {

                // Get selected size from media uploader
                var selected_size = $('.attachment-display-settings .size').val();

                var selection = file_frame.state().get('selection');
                selection.each(function (attachment, index) {
                    attachment = attachment.toJSON();
                    img_idfield_val = attachment.id;
                    // Selected attachment url from media uploader
                    //var attachment_url = attachment.sizes[selected_size].url;
                    var attachment_url = attachment.url ? attachment.url : attachment.sizes.thumbnail.url;
                    imgfield.val(attachment_url);
                    img_idfield.val(img_idfield_val);

                    showfield.html('<img src="' + attachment_url + '" />');
                });
            });

            // Finally, open the modal
            file_frame.open();
        }
    });

    // Delete row
    $(document).on('click', '.wpos-delete-row', function () {
        var num_of_row = $(this).closest('.wpos-content-box-wrp').find('.wpos-content-box-row').length;
        if (num_of_row == 1) {
            alert(savemp3admin.sry_delete_msg);
            return false;
        } else {
            $(this).closest('.wpos-content-box-row').remove();
        }
    });

    // Add row for group button
    $(document).on('click', '.wpos-add-row', function () {
        cls_ele = $(this).closest('.wpos-content-box-wrp');
        clone_ele = $(this).closest('.wpos-content-box-row').clone();

        // Retrieve the highest current key
        var key = highest = -1;
        cls_ele.find('.wpos-content-box-row').each(function () {
            var current = $(this).data('key');
            if (parseInt(current) > highest) {
                highest = current;
            }

        });
        key = highest += 1;
        clone_ele.attr('data-key', key);
        clone_ele.find('input[type=text], input[type=hidden], select, textarea').val('');
        clone_ele.find('img').attr('src', '');
        clone_ele.find('input, select, textarea').each(function () {
            var name = $(this).attr('name');
            var id = $(this).attr('id');
            if (name) {
                name = name.replace(/\[(\d+)\]/, '[' + parseInt(key) + ']');
                $(this).attr('name', name);
            }
            $(this).attr('data-key', key);
            if (typeof id != 'undefined') {
                id = id.replace(/(\d+)/, parseInt(key));
                $(this).attr('id', id);
            }
        });
        clone_ele.appendTo(cls_ele);// Clone and insert
    });



    // Clear Media
    $(document).on('click', '.wpos-image-clear', function () {
        $(this).parent().find('.wpos_overview_thumb_cls').val('');
        $(this).parent().find('.wpos_overview_thumb_id').val('');
        $(this).parent().parent().find('.wpos_img_view').html('');
    });


    /******************************** Addon Overview Media Uploader END **********************************/


    /******************************** Slug Edior Start **********************************/

    $(document).on('change', '.savemp3_post_slug_list', function () {
        
        var selec = $(this).val();
        
        var option = $('option:selected', this).attr('data-slug');

        $('.savemp3_current_slug').val( option );
        
    });


    $(document).on('click', '.slug_change', function () {

        var current_obj = $(this);
        
        var post_id                 =  $('.savemp3_post_slug_list').val();
        var new_slug                =  $('.savemp3_current_new_val').val();

        var lang_list = [];
        $(".common_selected_single:checked").each(function(){
            lang_list.push( $(this).val() );
        });

        if(post_id == ''){
            alert('Please Select post');
            return;
        }

        if(new_slug == ''){
            alert('Please enter slug');
            return;
        }
        
        

        if(lang_list.length == 0 ){
            alert('Please Select languages');
            return;
        }
        
        if( post_id!='' && new_slug!='' && lang_list ){
            current_obj.attr('disabled', 'disabled');
            var data = {
                action    : 'savemp3_slug_change',
                post_id   : post_id,
                new_slug  : new_slug,
                lang_list : lang_list,
            };

            $.post(ajaxurl, data, function (response) {
                if (response.status == 1) {
                    current_obj.removeAttr('disabled', 'disabled');
                    $('.savemp3-result-row').show();
                    $('.current_slug_result').html(response.html);
                }
            });
        } 

       
        
    });


    
    $(".sel_all").change(function() {
        if ( $(this).is(':checked') ){
           $('.common_selected_single').prop('checked', true); 
        } 
        else {
          $('.common_selected_single').prop('checked', false); 
        }
    });

    $(".common_selected_single").change(function() {
       var common_selected_single_count = $('.common_selected_single').length;
       var common_selected_single_checked_count = $('.common_selected_single:checked').length;
       if( common_selected_single_count == common_selected_single_checked_count){
            $('.sel_all').prop('checked', true);      
       }else{
            $('.sel_all').prop('checked', false);      
       }
    });


    $(document).on('click', '.current_slug_result', function() {

        var copyText = $(this);
        copyText.select();
        document.execCommand("copy");
        $('.savemp3-result-copied').show();


    });


    /******************************** Slug Edior End **********************************/




});
