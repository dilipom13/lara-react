jQuery(document).ready(function ($) {
    $(document).on('click', '#toggle-dropbox', function () {
        if ($(this).is(':checked')) {
            setCookie('dropbox_upload', 'on', 365);
        } else {
            setCookie('dropbox_upload', 'off', 365);
        }
    });

    $(document).on('click', '#toggle-gdrive', function () {
        if ($(this).is(':checked')) {
            setCookie('gdrive_upload', 'on', 365);
        } else {
            setCookie('gdrive_upload', 'off', 365);
        }
    });



    $(document).on('change', '.quality-hidden-select', function () {

        var quality = $(this).val();

        setCookie('select_quality', quality, 365);

    });


    $(document).on('click', '.select-menu button', function () {
        $('.quality-hidden-select').change();
    });

    $(document).on('change', '.toggle--init', function () {
        if ($(this).is(':checked')) {
            setCookie('dark_mode', 'on', 365);
        } else {
            setCookie('dark_mode', 'off', 365);
        }
    });


    /*  contact form submit start */


    $('.contact .btn--loading').on("click", function (e) {
        var current_obj = $(this);
        var cls_form = $(this).closest('.contactForm');

        e.preventDefault();

        var formData = cls_form.serialize();
        var email = cls_form.find('#email').val();
        var error = 0;

        if (cls_form.find('#name').val() == '') {

            if (cls_form.find('#name').closest('.form--group').find('.hint').length == 0) {
                cls_form.find('#name').closest('.form--group').append('<span class="hint">'+SAVEMP3_GLOB.required_field+'</span>');
            }

            error = 1;
        } else {
            cls_form.find('#name').closest('.form--group').find('.hint').remove();
            error = 0;
        }

        if (email == '' || !validateEmail(email)) {
            if (cls_form.find('#email').closest('.form--group').find('.hint').length == 0) {
                cls_form.find('#email').closest('.form--group').append('<span class="hint">'+SAVEMP3_GLOB.invalid_email+'</span>');
            }
            error = 1;
        } else {
            cls_form.find('#email').closest('.form--group').find('.hint').remove();
            error = 0;
        }

        if (cls_form.find('#title').val() == '') {
            if (cls_form.find('#title').closest('.form--group').find('.hint').length == 0) {
                cls_form.find('#title').closest('.form--group').append('<span class="hint">'+SAVEMP3_GLOB.required_field+'</span>');
            }
            error = 1;
        } else {
            cls_form.find('#title').closest('.form--group').find('.hint').remove();
            error = 0;
        }

        if (cls_form.find('#message').val() == '') {
            if (cls_form.find('#message').closest('.form--group').find('.hint').length == 0) {
                cls_form.find('#message').closest('.form--group').append('<span class="hint">'+SAVEMP3_GLOB.required_field+'</span>');
            }
            error = 1;
        } else {
            cls_form.find('#message').closest('.form--group').find('.hint').remove();
            error = 0;
        }

        if (error == 1) {
            return false;
        }

        current_obj.addClass('is-loading');
        current_obj.attr('disabled', 'disabled');
        form_data = new FormData();
        form_data.append('form_data', formData);
        form_data.append('action', 'wpos_add_contact');

        $.ajax({
            url: SAVEMP3_GLOB.ajaxurl,
            type: 'POST',
            contentType: false,
            processData: false,
            data: form_data,
            success: function (response) {
                if (response.status == 0) {
                    current_obj.removeClass('is-loading');
                } else if (response.status == 1) {
                    setTimeout(function () {
                        $('.contactForm').trigger("reset");
                        current_obj.removeClass('is-loading');

                        Notification.open({
                            message: SAVEMP3_GLOB.success_msg,
                            prefix: 'contact-notification',
                            parent: '.contact',
                            autoCloseDelay: 3000,
                        });
                    }, 3000);

                }
                current_obj.removeAttr('disabled', 'disabled');
            }
        });

    });
    /*  contact form submit end */


});

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";

}

function check_cname(cookiename) {
    var checking = getCookie(cookiename);
    if (checking != "") {
        return true;
    } else {
        return false;
    }

}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


function validateEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}

// Remove ac iframe.
function ac_remove_ifram() {
    jQuery("#ac-iframe").remove();
}
