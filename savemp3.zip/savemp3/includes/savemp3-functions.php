<?php
/**
 * Functions File
 *
 * @package Savemp3
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;


$client                 = new \Predis\Client( 'tcp:/127.0.0.1:6379' );
$pool                   = new \Cache\Adapter\Predis\PredisCachePool( $client );
$which_browser_result   = new WhichBrowser\Parser( getallheaders(), array( 'cache' => $pool ) );

function savemp3_get_curent_browserinfo() {
    global $which_browser_result;
    $browser_data = array();
    $result       = $which_browser_result;

    if ( $result->browser->name == 'Firefox Mobile' ) {
        $browser_data['browser_name']       = 'Firefox';
    } else if ( $result->browser->name == 'Opera Mobile' ) {
        $browser_data['browser_name']   = 'Opera';
    } else {
        $browser_data['browser_name']       = $result->browser->name;
    }

    $browser_data['browser_version']    = $result->browser->version->value;

    return $browser_data;
}



/**
 * Update default settings
 *
 * @package Savemp3
 * @since 1.0
 */
function savemp3_default_settings() {
    // Take some global variable
    global $savemp3_options;
    $savemp3_options = array(
                                'default_placeholder'          => __('Paste your video or playlist link here', 'savemp3'),
                                'max_results_show'             => 10,
                                'enable_google_drive'          => 1,
                                'enable_dropbox_drive'         => 1,
                                'MP3_API_URL'                  => '',
                                'MP3_API_PUBLIC_KEY'           => '',
                                'MP3_API_SECRET_KEY'           => '',
                                'MP3_YOUTUBE_API_URL'          => '',
                                'MP3_YOUTUBE_API_PUBLIC_KEY'   => '',
                                'MP3_YOUTUBE_API_SECRET_KEY'   => '',
                                'supported-site'               => array(
                                                                        1  => array(
                                                                            'class'     => 'icon-youtube',
                                                                            'name'      => 'Youtube',
                                                                            'label'      => 'Youtube',
                                                                            'link'      => '#',
                                                                        ),
                                                                        2  => array(
                                                                            'class'     => 'icon-facebook-box',
                                                                            'name'      => 'Facebook',
                                                                            'label'      => 'Facebook',
                                                                            'link'      => '#',
                                                                        ),
                                                                        3  => array(
                                                                            'class'     => 'icon-twitter-box',
                                                                            'name'      => 'Twitter',
                                                                            'label'      => 'Twitter',
                                                                            'link'      => '#',
                                                                        ),
                                                                        4  => array(
                                                                            'class'     => 'icon-dailymotion-box',
                                                                            'name'      => 'Dailymotion',
                                                                            'label'      => 'Dailymotion',
                                                                            'link'      => '#',
                                                                        ),
                                                                        5  => array(
                                                                            'class'     => 'icon-vk-box',
                                                                            'name'      => 'VK',
                                                                            'label'      => 'VK',
                                                                            'link'      => '#',
                                                                        ),
                                                                        6  => array(
                                                                            'class'     => 'icon-youtube',
                                                                            'name'      => 'Youtube',
                                                                            'label'      => 'Youtube',
                                                                            'link'      => '#',
                                                                        ),
                                                                        7  => array(
                                                                            'class'     => 'icon-facebook-box',
                                                                            'name'      => 'Facebook',
                                                                            'label'      => 'Facebook',
                                                                            'link'      => '#',
                                                                        ),
                                                                        8  => array(
                                                                            'class'     => 'icon-twitter-box',
                                                                            'name'      => 'Twitter',
                                                                            'label'      => 'Twitter',
                                                                            'link'      => '#',
                                                                        ),
                                                                        9  => array(
                                                                            'class'     => 'icon-dailymotion-box',
                                                                            'name'      => 'Dailymotion',
                                                                            'label'      => 'Dailymotion',
                                                                            'link'      => '#',
                                                                        ),
                                                                        10  => array(
                                                                            'class'     => 'icon-vk-box',
                                                                            'name'      => 'VK',
                                                                            'label'      => 'VK',
                                                                            'link'      => '#',
                                                                        ),
                                                                        11  => array(
                                                                            'class'     => 'icon-youtube',
                                                                            'name'      => 'Youtube',
                                                                            'label'      => 'Youtube',
                                                                            'link'      => '#',
                                                                        ),
                                                                        12  => array(
                                                                            'class'     => 'icon-facebook-box',
                                                                            'name'      => 'Facebook',
                                                                            'label'      => 'Facebook',
                                                                            'link'      => '#',
                                                                        ),
                                                                        13  => array(
                                                                            'class'     => 'icon-twitter-box',
                                                                            'name'      => 'Twitter',
                                                                            'label'      => 'Twitter',
                                                                            'link'      => '#',
                                                                        ),
                                                                        14  => array(
                                                                            'class'     => 'icon-dailymotion-box',
                                                                            'name'      => 'Dailymotion',
                                                                            'label'      => 'Dailymotion',
                                                                            'link'      => '#',
                                                                        ),
                                                                        15  => array(
                                                                            'class'     => 'icon-vk-box',
                                                                            'name'      => 'VK',
                                                                            'label'      => 'VK',
                                                                            'link'      => '#',
                                                                        ),
                                                                    ),
                                'card_title'                         => '<h2 class="extensions--title"><span class="ascent">Install</span> <br> Savemp3 helper</h2>',
                                'card_description'                   => '<p class="extensions--desc"> Add Savemp3 helper in your browser and Convert YouTube video into mp3 without leaving the YouTube page. </p>',
                                'card_image'                         => '',
                                'update_url'                         => '',
                                'emulator'                           => '',
                                'opera'                              => '',
                                'userscript'                         => '',
                            );

    $default_options = apply_filters('savemp3_options_default_values', $savemp3_options );

    // Update default options
    update_option( 'savemp3_options', $default_options );

    // Overwrite global variable when option is update
    $savemp3_options = savemp3_get_theme_settings();
}

/**
 * Get Settings From Option Page
 *
 * Handles to return all settings value
 *
 * @package Savemp3
 * @since 1.0
 */
function savemp3_get_theme_settings() {
    $options = get_option('savemp3_options');
    $settings = is_array($options)  ? $options : array();
    return $settings;
}

/**
 * Get an option
 * Looks to see if the specified setting exists, returns default if not
 *
 * @package Savemp3
 * @since 1.0
 */
function savemp3_get_option( $key = '', $default = false ) {
    // Take some global variable
    global $savemp3_options;
    $value = ! empty( $savemp3_options[ $key ] ) ? $savemp3_options[ $key ] : $default;
    $value = apply_filters( 'savemp3_get_option', $value, $key, $default );
    return apply_filters( 'savemp3_get_option_' . $key, $value, $key, $default );
}

/**
 * Escape Tags & Slashes
 * Handles escapping the slashes and tags
 *
 * @package Savemp3
 * @since 1.0
 */
function savemp3_esc_attr($data) {
    return esc_attr( stripslashes($data) );
}

/**
 * Strip Slashes From Array
 *
 * @package Savemp3
 * @since 1.0
 */
function savemp3_slashes_deep($data = array(), $flag = false) {
    if($flag != true) {
        $data = savemp3_nohtml_kses($data);
    }
    $data = stripslashes_deep($data);
    return $data;
}

/**
 * Strip Html Tags
 *
 * It will sanitize text input (strip html tags, and escape characters)
 *
 * @package Savemp3
 * @since 1.0
 */

function savemp3_nohtml_kses($data = array()) {
    if ( is_array($data) ) {
        $data = array_map('savemp3_nohtml_kses', $data);
    } elseif ( is_string( $data ) ) {
        $data = trim( $data );
        $data = wp_filter_nohtml_kses($data);
    }
    return $data;
}

/**
 * Get theme settings tab
 *
 * @package Savemp3
 * @since 1.0
 */
function savemp3_theme_sett_tab( $only_tab_key = false ){
    // Talking default
    $theme_tabs_keys = array();
    $theme_tabs = array(
                        'general_settings'         => array(
                                                    'name'      => __('General settings', 'savemp3'),
                                                    'icon_cls'  => 'dashicons-admin-settings',
                                                    ), 
                       /* 'label_settings'         => array(
                                                    'name'      => __('label settings', 'savemp3'),
                                                    'icon_cls'  => 'dashicons-admin-settings',
                                                    ),*/
                        'browser_extensions'       => array(
                                                    'name'      => __('Browser extensions', 'savemp3'),
                                                    'icon_cls'  => 'dashicons-admin-settings',
                                                    ),
                        'supported_sites'           => array(
                                                    'name'      => __('Supported Sites', 'savemp3'),
                                                    'icon_cls'  => 'dashicons-admin-settings',
                                                    ),
                       
                         'api_settings'         => array(
                                                    'name'      => __('API settings', 'savemp3'),
                                                    'icon_cls'  => 'dashicons-admin-settings',
                                                    ),
                         'ads_settings'         => array(
                                                    'name'      => __('Ads settings', 'savemp3'),
                                                    'icon_cls'  => 'dashicons-admin-settings',
                                                    ),

                          'import_page'              => array(
                                                    'name'      => __('Import/export', 'savemp3'),
                                                    'icon_cls'  => 'dashicons-admin-settings',
                                                    ),

                    );

    $theme_tabs = apply_filters( 'savemp3_theme_settings_tab', $theme_tabs );

    // If only want to get key
    if( $only_tab_key == true ) {
        foreach ($theme_tabs as $tab_key => $tab_value) {
            $theme_tabs_keys[] = $tab_key;
            if( !empty($tab_value['sub_menu']) ) {
                $theme_tabs_keys = array_merge( $theme_tabs_keys, array_keys($tab_value['sub_menu']) );
            }
        }
        $theme_tabs = $theme_tabs_keys;
    }
    return $theme_tabs;
}


// Ajax call for contact form process
add_action( 'wp_ajax_wpos_add_contact', 'wpos_add_contact' );
add_action( 'wp_ajax_nopriv_wpos_add_contact', 'wpos_add_contact' );


/**
 * User Register Process
 *
 * @package Script Hub
 * @since 1.0
 */
function wpos_add_contact() {

    header('Access-Control-Allow-Origin: *');
    $prefix     = SVMP3_META_PREFIX;
    parse_str( $_POST['form_data'], $post_data ); // Unserialize the form data
    $admin_email    = get_option( 'admin_email' );

    // Taking some data
    $result                             = array( 'redirect' => 0 );
    $name                               = isset( $post_data['name'] )                   ? $post_data['name']                            : '';
    $email                              = isset( $post_data['email'] )                  ? sanitize_email( $post_data['email'] )         : '';
    $message                            = isset( $post_data['message'] )                ? $post_data['message']                         : '';
    $title                              = isset( $post_data['title'] )                ? $post_data['title']                         : '';
    $mail_body                          = '';

    if( !empty($name) && !empty($email) && filter_var( $email, FILTER_VALIDATE_EMAIL ) && !empty($title) && !empty($message) )  {


        ob_start();
        include SVMP3_INC_DIR. '/mail/contact.php';
        $mail_body .= ob_get_clean();
        $mail_body = stripslashes($mail_body);

        $post = array(
            'post_title'    => $name,
            'post_content'  => $mail_body,
            'post_status'   => 'pending',
            'post_type'     => SVMP3_CONTACT_POST_TYPE
        );

        $post_id =  wp_insert_post($post);

        update_post_meta($post_id, $prefix.'name', $name);
        update_post_meta($post_id, $prefix.'email', $email);
        update_post_meta($post_id, $prefix.'title', $title);
        $reply_to       = 'Reply-To: '.$name.' <'.$email.'>';
        $headers        = array(
                                'Content-Type: text/html; charset=UTF-8',
                                $reply_to,
                              );

        wp_mail( $admin_email, $title, $mail_body, $headers );

        $result['status']       = 1;
        $result['site_url']     = site_url();
        $result['success']      = __('Thanks For submit.', 'addoncrop');

    }else{

        $result['status'] = 0;
        $result['success'] = __('Sorry try again later.', 'addoncrop');
    }

     wp_send_json( $result );

}

function get_mp3_tokens() {
    $options = savemp3_get_theme_settings();

    $youtube_api = array(
        'url'        => $options['MP3_YOUTUBE_API_URL'],
        'secret_key' => $options['MP3_YOUTUBE_API_SECRET_KEY'],
        'public_key' => $options['MP3_YOUTUBE_API_PUBLIC_KEY'],
    );

    $api = [
        'url'        => $options['MP3_API_URL'],
        'secret_key' => $options['MP3_API_SECRET_KEY'],
        'public_key' => $options['MP3_API_PUBLIC_KEY'],
    ];

    $timestamp  = time();

    return [
        'youtube_api' => [
            'url' => $youtube_api['url'],
            'public_key' => $youtube_api['public_key'],
            'timestamp' => $timestamp,
            'token' => hash_hmac('sha512', $timestamp . $youtube_api['public_key'], $youtube_api['secret_key']),
        ],
        'api' => [
            'url' => $api['url'],
            'public_key' => $api['public_key'],
            'timestamp' => $timestamp,
            'token' => hash_hmac('sha512', $timestamp . $api['public_key'], $api['secret_key']),
        ],
    ];
}


function get_active_wpml_lang(){
    $languages = apply_filters( 'wpml_active_languages', NULL, 'orderby=id&order=desc' );
    return  !empty($languages) ? $languages: array('en'=>array('language_code'=>'en','native_name'=>'English'));
}



function get_icl_language_code(){
    if (defined('ICL_LANGUAGE_CODE'))
    {
        return ICL_LANGUAGE_CODE;
    }
    else
    {
        return 'en';
    }
}