<body style="margin: 0; padding-top: 100px; padding-bottom: 50px; background: #f7f7f7; font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, 'Helvetica Neue', Arial, sans-serif;">
   <div style="background: #fff; padding: 20px 10px; width: 80%; z-index: 5; margin: auto; border: 1px solid #e7e7e7">
      <table style="background: #fff; margin: auto;" width="80%">
         <tr>
            <td colspan="2">
               <h3 style="font-weight: 500;"><?php echo $title; ?></h3>
               <p  style="font-size: 16px; line-height: 1.7; font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, 'Helvetica Neue', Arial, sans-serif;">
                 <?php echo $message; ?>
               </p>
               <br />
               <table style="border-spacing: 0em;">
                  <tr>
                     <td style="font-weight: 500; border-bottom: 1px solid #e7e7e7; padding: 10px 0;">Name:</td>
                     <td style="border-bottom: 1px solid #e7e7e7; padding: 10px 0"><a href="mailto:<?php echo $email; ?>"><?php echo $name; ?></a>
                     </td>
                  </tr> 
                  <tr>
                     <td style="font-weight: 500; border-bottom: 1px solid #e7e7e7; padding: 10px 0;">Email:</td>
                     <td style="border-bottom: 1px solid #e7e7e7; padding: 10px 0"><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a>
                     </td>
                  </tr>
               </table>
               <br />
            </td>
         </tr>
      </table>
   </div>
</body>