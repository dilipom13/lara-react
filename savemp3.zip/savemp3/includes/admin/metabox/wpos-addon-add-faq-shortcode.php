<?php
/**
 * Handles Post Setting metabox HTML
 *
 * @package Savemp3
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Take some variable
global $post;
$prefix = SVMP3_META_PREFIX; // Metabox prefix


?>
<!-- Addon configuration -->
<div class="faq-control-wrap">
	<div class="sh-add-pdt-file-rpt-row">
		<h2> <strong> <?php echo '[savemp3_faq_display id="'.$post->ID.'"]'; ?> </strong> </h2>
	</div>
</div>
