<?php
/**
 * Handles Post Setting metabox HTML
 *
 * @package Savemp3
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
// Take some variable
global $post;
$prefix 				= SVMP3_META_PREFIX; // Metabox prefix

$input_placeholder 		= get_post_meta( $post->ID, $prefix.'input_placeholder', true );
$download_video_url     = get_post_meta( $post->ID, $prefix.'download_video_url', true );
$show_extensions_card   = get_post_meta( $post->ID, $prefix.'show_extensions_card', true );
$related_articles     	= get_post_meta( $post->ID, $prefix.'related_articles', true );

?>

<table class="form-table">
	<tbody>			
		
		<tr valign="top">
			<th scope="row">
				<label for="input_placeholder"><?php _e('Input placeholder', 'savemp3'); ?></label>
			</th>
			<td>
			<input type="text" id="input_placeholder" value="<?php echo $input_placeholder; ?>" class="large-text" name="<?php echo $prefix.'input_placeholder'; ?>">
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="download_video_url"><?php _e('How to download (Video URL)', 'savemp3'); ?></label>
			</th>
			<td>
			<input type="text" id="download_video_url" value="<?php echo $download_video_url; ?>" class="large-text" name="<?php echo $prefix.'download_video_url'; ?>">
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="show_extensions_card"><?php _e('Show extensions card', 'savemp3'); ?></label>
			</th>
			<td>
			<input value="1" <?php echo ($show_extensions_card == 1)?'checked': ''; ?> type="checkbox" id="show_extensions_card"  name="<?php echo $prefix.'show_extensions_card'; ?>">
			</td>
		</tr>
		<tr valign="top">
			<th scope="row">
				<label for="related_articles"><?php _e('Related articles', 'savemp3'); ?></label>
			</th>
			<td>
				<?php 
					$args = array ( 
			                        //'post_type'             => SVMP3_WEBSITE_POST_TYPE,
			                        'post_type'             => 'page',
			                        'post_status'           => array('publish'),
			                        'posts_per_page'        => -1,
			                        'suppress_filters' 		=> 0
			                      );

			    $post_lists      = get_posts($args);
			    ?>
			    <select multiple name="<?php echo $prefix; ?>related_articles[]">

			    <?php   if ( !empty($post_lists) ) {             
			    foreach( $post_lists as $post_list ){

			    	$title 				= wp_strip_all_tags( $post_list->post_title );
			    	
			    	$template_slug      = get_page_template_slug($post_list->ID);

			    	if( $template_slug == 'page-templates/converter-page.php' ){



			    	//<option value="2"> Turn yourVideointo MP3page-templates/home-page.php</option>

			    	?>
			        <option <?php echo ( is_array( $related_articles ) && in_array( $post_list->ID, $related_articles )  )?'selected':''; ?> value="<?php echo $post_list->ID; ?>"> <?php echo $title;  ?></option>
			    <?php } } } ?>
			    </select>
			</td>
		</tr>
	</tbody>
</table>
