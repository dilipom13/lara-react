<?php
/**
 * Register Contact type functionality
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to register post type
 * 
 * @package Savemp3
 * @since 1.0.0
 */
function savemp3_contact_register_post_type() {
  	// Contact Post type
	$savemp3_contact_labels = array(
		'name'                 	=> __('Contact', 'savemp3'),
		'singular_name'        	=> __('Contact', 'savemp3'),
		'all_items' 			=> 'Contacts <span class="contact_count"></span>',
		'add_new'              	=> __('Add New', 'savemp3'),
		'add_new_item'         	=> __('Add New', 'savemp3'),
		'edit_item'            	=> __('Edit Contact', 'savemp3'),
		'new_item'             	=> __('New Contact', 'savemp3'),
		'view_item'            	=> __('View Contact', 'savemp3'),
		'search_items'         	=> __('Search Contact', 'savemp3'),
		'not_found'            	=> __('No Contact Items found', 'savemp3'),
		'not_found_in_trash'   	=> __('No Contact Items found in Trash', 'savemp3'),
		'parent_item_colon'    	=> '',
		'menu_name'            	=> __('Contact', 'savemp3'),
		'featured_image'		=> __('Contact Image', 'savemp3'),
		'set_featured_image'	=> __('Set Contact Image', 'savemp3'),
		'remove_featured_image'	=> __('Remove contact image', 'savemp3'),
		'use_featured_image'	=> __('Use as contact image', 'savemp3'),
	);

	$savemp3_contact_args = array(

		'labels'              => $savemp3_contact_labels,
		'public'              => false,
		'publicly_queryable'  => false,
		'exclude_from_search' => false,
		'show_ui'             => true,
		'show_in_menu'        => true, 
		//'show_in_menu'        => 'edit.php?post_type=feature_request', 
		'query_var'           => false,
		'capability_type'     => 'post',
		'has_archive'         => false,
		'hierarchical'        => false,
		'menu_position'       => 9,
		'rewrite' 			  => false,
		'menu_icon'   		  => 'dashicons-feedback',
		'supports'            => apply_filters('savemp3_contact_contact_post_supports', array('title','editor'))
		
	);
	
	// Register contact post type
	register_post_type( SVMP3_CONTACT_POST_TYPE, apply_filters('savemp3_contact_register_post_type_contact', $savemp3_contact_args) );
}

// Action to register plugin post type
add_action('init', 'savemp3_contact_register_post_type');



//////===============CONTACT START=================


// Testimonial post columns Processes
add_filter( 'manage_edit-savemp3_contact_columns', 'register_custom_column_headings');
add_action( 'manage_posts_custom_column',   'register_custom_columns' );

/**
 * Function to Custom coloumn headings
 * 
 * @package WP Testimonials with rotator widget
 * @since 2.2.8
 */
function register_custom_column_headings ( $defaults ) {
	$new_columns = array( 
						'title'     => __( 'Name',  'wp-testimonial-with-widget' ), 
						'reason' 	=> __( 'Reason',  'wp-testimonial-with-widget' ), 
						'subject' 	=> __( 'Subject', 'wp-testimonial-with-widget' ), 
						'message' 	=> __( 'Message', 'wp-testimonial-with-widget' ), 
					);
		$last_item = '';
		if ( isset( $defaults['date'] ) ) { unset( $defaults['date'] ); }
		$defaults = array_merge( $defaults, $new_columns );
		return $defaults;
}

/**
 * Function to Custom coloumns
 * 
 * @package WP Testimonials with rotator widget
 * @since 2.2.8
 */
function register_custom_columns ( $column_name ) {
	global $wpdb, $post;
	 $prefix                 = SVMP3_META_PREFIX; // Metabox prefix
	switch ( $column_name ) {
		case 'reason':
			  echo get_post_meta( $post->ID, $prefix.'reason', true );   
			  break;
		case 'subject':
			  echo get_post_meta( $post->ID, $prefix.'subject', true );   
			  break;
		case 'message':
			  echo get_post_meta( $post->ID, $prefix.'message', true );   
			  break;					
		break;
		default:
		break;
	}
}
//////===============CONTACT END=================

