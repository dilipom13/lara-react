<?php
/**
 * Register Post type functionality
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to register post type
 * 
 * @package Savemp3
 * @since 1.0.0
 */
function savemp3_faq_register_post_type() {
  	// FAQ Post type
	$savemp3_faq_labels = array(
		'name'                 	=> __('FAQs', 'savemp3'),
		'menu_name'            	=> __('FAQs', 'savemp3'),
		'all_items' 			=> __('All', 'savemp3'),
		'singular_name'        	=> __('FAQ', 'savemp3'),
		'add_new'              	=> __('Add New', 'savemp3'),
		'add_new_item'         	=> __('Add New', 'savemp3'),
		'edit_item'            	=> __('Edit FAQ', 'savemp3'),
		'new_item'             	=> __('New FAQ', 'savemp3'),
		'view_item'            	=> __('View FAQ', 'savemp3'),
		'search_items'         	=> __('Search FAQ', 'savemp3'),
		'not_found'            	=>  __('No FAQ Items found', 'savemp3'),
		'not_found_in_trash'   	=> __('No FAQ Items found in Trash', 'savemp3'),
		'parent_item_colon'    	=> '',
		'featured_image'		=> __('FAQ Image', 'savemp3'),
		'set_featured_image'	=> __('Set FAQ Image', 'savemp3'),
		'remove_featured_image'	=> __('Remove blog image', 'savemp3'),
		'use_featured_image'	=> __('Use as blog image', 'savemp3'),
	);

	$savemp3_faq_args = array(
		'labels'              => $savemp3_faq_labels,
		'public'              => false,
		'publicly_queryable'  => false,
		'exclude_from_search' => true,
		'show_ui'             => true,
		'show_in_rest'        => true,
		'show_in_menu'        => true, 
		'query_var'           => false,
		'capability_type'     	=> 'post',
		'has_archive'         	=> false,
		'hierarchical'        	=> false,
		'menu_position'       	=> 8,
		'menu_icon'   			=> 'dashicons-editor-ol',
		'supports'            	=> apply_filters('savemp3_faq_blog_post_supports', array('title', 'publicize')),
		
	);
	
	// Register blog post type
	register_post_type( SVMP3_FAQ_POST_TYPE, apply_filters('savemp3_faq_register_post_type_blog', $savemp3_faq_args) );
}

// Action to register plugin post type
add_action('init', 'savemp3_faq_register_post_type');



/**
 * Function to update post message for blog post type
 * 
 * @package Savemp3
 * @since 2.0.2
 */
function savemp3_faq_post_updated_messages( $messages ) {
	global $post, $post_ID;
	$messages[SVMP3_FAQ_POST_TYPE] = array(
		0 => '', // Unused. Messages start at index 1.
		1 => sprintf( __( 'FAQ updated. <a href="%s">View FAQ</a>', 'savemp3' ), esc_url( get_permalink( $post_ID ) ) ),
		2 => __( 'Custom field updated.', 'savemp3' ),
		3 => __( 'Custom field deleted.', 'savemp3' ),
		4 => __( 'FAQ updated.', 'savemp3' ),
		5 => isset( $_GET['revision'] ) ? sprintf( __( 'FAQ restored to revision from %s', 'savemp3' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __( 'FAQ published. <a href="%s">View FAQ</a>', 'savemp3' ), esc_url( get_permalink( $post_ID ) ) ),
		7 => __( 'FAQ saved.', 'savemp3' ),
		8 => sprintf( __( 'FAQ submitted. <a target="_blank" href="%s">Preview FAQ</a>', 'savemp3' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
		9 => sprintf( __( 'FAQ scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview FAQ</a>', 'savemp3' ),
		  date_i18n( 'M j, Y @ G:i', strtotime( $post->post_date ) ), esc_url( get_permalink( $post_ID ) ) ),
		10 => sprintf( __( 'FAQ draft updated. <a target="_blank" href="%s">Preview FAQ</a>', 'savemp3' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
	);
	return $messages;
}
// Filter to update blog post message
add_filter( 'post_updated_messages', 'savemp3_faq_post_updated_messages' );
