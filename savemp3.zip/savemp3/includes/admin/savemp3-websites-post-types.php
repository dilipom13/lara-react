<?php
/**
 * Register Post type functionality
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Function to register post type
 * 
 * @package Savemp3
 * @since 1.0.0
 */
function savemp3_website_register_post_type() {
  	// Website Post type
	$savemp3_website_labels = array(
		'name'                 	=> __('Website', 'savemp3'),
		'all_items' 			=> __('All', 'savemp3'),
		'singular_name'        	=> __('Website', 'savemp3'),
		'add_new'              	=> __('Add New', 'savemp3'),
		'add_new_item'         	=> __('Add New', 'savemp3'),
		'edit_item'            	=> __('Edit Website', 'savemp3'),
		'new_item'             	=> __('New Website', 'savemp3'),
		'view_item'            	=> __('View Website', 'savemp3'),
		'search_items'         	=> __('Search Website', 'savemp3'),
		'not_found'            	=>  __('No Website Items found', 'savemp3'),
		'not_found_in_trash'   	=> __('No Website Items found in Trash', 'savemp3'),
		'parent_item_colon'    	=> '',
		'menu_name'            	=> __('Website', 'savemp3'),
		'featured_image'		=> __('Website Image', 'savemp3'),
		'set_featured_image'	=> __('Set Website Image', 'savemp3'),
		'remove_featured_image'	=> __('Remove blog image', 'savemp3'),
		'use_featured_image'	=> __('Use as blog image', 'savemp3'),
	);

	$savemp3_website_args = array(
		'labels'              => $savemp3_website_labels,
		'public'              => true,
		'publicly_queryable'  => true,
		'exclude_from_search' => false,
		'show_ui'             => true,
		'show_in_rest'        => true,
		'show_in_menu'        => true, 
		'query_var'           => true,
		'rewrite' 				=> array( 'with_front' => false ),						
		'capability_type'     	=> 'post',
		'has_archive'         	=> false,
		'hierarchical'        	=> false,
		'menu_position'       	=> 8,
		'menu_icon'   			=> 'dashicons-editor-help',
		'supports'            	=> apply_filters('savemp3_website_blog_post_supports', array('title', 'editor', 'thumbnail', 'excerpt', 'comments', 'author', 'page-attributes', 'publicize')),
		'taxonomies'          	=> array(SVMP3_WEBSITE_TAG)
	);
	
	// Register blog post type
	register_post_type( SVMP3_WEBSITE_POST_TYPE, apply_filters('savemp3_website_register_post_type_blog', $savemp3_website_args) );
}

// Action to register plugin post type
add_action('init', 'savemp3_website_register_post_type');

/**
 * Function to register taxonomy
 * 
 * @package Savemp3
 * @since 1.0.0
 */
function savemp3_website_register_taxonomies() {
	
    $labels = array(
        'name'              => __( 'Category', 'savemp3' ),
        'singular_name'     => __( 'Category', 'savemp3' ),
        'search_items'      => __( 'Search Category', 'savemp3' ),
        'all_items'         => __( 'All Category', 'savemp3' ),
        'parent_item'       => __( 'Parent Category', 'savemp3' ),
        'parent_item_colon' => __( 'Parent Category:', 'savemp3' ),
        'edit_item'         => __( 'Edit Category', 'savemp3' ),
        'update_item'       => __( 'Update Category', 'savemp3' ),
        'add_new_item'      => __( 'Add New Category', 'savemp3' ),
        'new_item_name'     => __( 'New Category Name', 'savemp3' ),
        'menu_name'         => __( 'Categories', 'savemp3' ),
    );
    
    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'show_in_rest' 		=> true,
        'rewrite'           => array( 'slug' => apply_filters('savemp3_website_blog_cat_slug', SVMP3_WEBSITE_CAT) ),
    );

    /*register_taxonomy( SVMP3_WEBSITE_CAT, array( SVMP3_WEBSITE_POST_TYPE ), apply_filters('savemp3_website_register_cat_blog', $args) );
    register_taxonomy( 
						SVMP3_WEBSITE_TAG, //taxonomy 
						SVMP3_WEBSITE_POST_TYPE, //post-type
						array( 
						    'hierarchical'  => false, 
						    'label'         => __( 'Tags','savemp3'), 
						    'singular_name' => __( 'Tag', 'savemp3' ), 
						    'rewrite'       => true, 
						    'query_var'     => true, 
						    'show_in_rest'  => true,
					 ));*/

}

// Action to register plugin taxonomies
add_action( 'init', 'savemp3_website_register_taxonomies');

/**
 * Function to update post message for blog post type
 * 
 * @package Savemp3
 * @since 2.0.2
 */
function savemp3_website_post_updated_messages( $messages ) {
	global $post, $post_ID;
	$messages[SVMP3_WEBSITE_POST_TYPE] = array(
		0 => '', // Unused. Messages start at index 1.
		1 => sprintf( __( 'Website updated. <a href="%s">View Website</a>', 'savemp3' ), esc_url( get_permalink( $post_ID ) ) ),
		2 => __( 'Custom field updated.', 'savemp3' ),
		3 => __( 'Custom field deleted.', 'savemp3' ),
		4 => __( 'Website updated.', 'savemp3' ),
		5 => isset( $_GET['revision'] ) ? sprintf( __( 'Website restored to revision from %s', 'savemp3' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __( 'Website published. <a href="%s">View Website</a>', 'savemp3' ), esc_url( get_permalink( $post_ID ) ) ),
		7 => __( 'Website saved.', 'savemp3' ),
		8 => sprintf( __( 'Website submitted. <a target="_blank" href="%s">Preview Website</a>', 'savemp3' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
		9 => sprintf( __( 'Website scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Website</a>', 'savemp3' ),
		  date_i18n( 'M j, Y @ G:i', strtotime( $post->post_date ) ), esc_url( get_permalink( $post_ID ) ) ),
		10 => sprintf( __( 'Website draft updated. <a target="_blank" href="%s">Preview Website</a>', 'savemp3' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
	);
	return $messages;
}
// Filter to update blog post message
add_filter( 'post_updated_messages', 'savemp3_website_post_updated_messages' );
