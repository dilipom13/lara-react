<?php
/**
 * Admin Class
 *
 * Handles the Admin side functionality of theme
 *
 * @package Savemp3 
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class SVMP3_Admin {
	function __construct() {
		// Action to add metabox
		add_action( 'add_meta_boxes', array($this, 'savemp3_add_meta_box') );
		// Action to save metabox
		add_action( 'save_post', array($this, 'savemp3_save_metabox_value') );

		// Action to register admin menu
		add_action( 'admin_menu', array($this, 'wpos_register_menu') );

		// Ajax call to update option
		add_action( 'wp_ajax_savemp3_update_theme_options', array($this, 'savemp3_update_theme_options'));
		
		// Ajax call to update option
		add_action( 'wp_ajax_savemp3_update_theme_options_import', array($this, 'savemp3_update_theme_options_import'));

	}


	/**
	 * Function to register admin menus
	 * 
	 * @package Savemp3
	 * @since 1.0
	 */
	function wpos_register_menu() {
		add_theme_page( 
			'Theme Settings', 
			'Theme Settings', 
			'manage_options', 
			'savemp3', 
			array($this, 'savemp3_theme_settings_page'), 
			4 
		);
	}


	/**
	 * Update Settings Options (Custom Way)
	 * 
	 * @package Savemp3
	 * @since 1.0.0
	 */
	function savemp3_update_theme_options() {
		// Taking some default
		$result = array();
		if( !empty($_POST['form_data']) ) {
			$output_arr 	= array();
			$form_data 		= parse_str( $_POST['form_data'], $output_arr );
			$setting_data 	= $output_arr['savemp3_options'];
			$setting_data 	= stripslashes_deep($setting_data);
			if( !empty($output_arr['savemp3_options']) ) {
				// Update option
				update_option( 'savemp3_options',  $setting_data);
				$result['success'] = 1;
			}

		}
		echo json_encode($result);
		die();
	}

	/**
	 * IMPORT Settings Options (Custom Way)
	 * 
	 * @package Savemp3
	 * @since 1.0.0
	 */
	function savemp3_update_theme_options_import() {
		//header('Content-Type: application/json');
		$result 		= array();
		$form_data 		= $_POST['form_data'];
		$form_data 		= stripslashes( $form_data ) ;
		$form_data 	    = json_decode( $form_data );
		$form_data 	    = json_decode( $form_data , true);
		if( !empty($form_data) ) {
			// Update option
			update_option( 'savemp3_options', $form_data );
			$result['success'] = 1;
		}
		echo json_encode($result);
		die();
	}

	/**
	 * Settings HTML
	 * 
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_theme_settings_page() {
		include_once( SVMP3_INC_DIR . '/admin/settings/wpos-settings.php' );
	}

	/**
	 * Post Metabox
	 * 
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_add_meta_box() {
		global $post;
	
		add_meta_box( 'savemp3-post-settings', __('Settings', 'savemp3'), array($this, 'savemp3_post_settings'), array(SVMP3_WEBSITE_POST_TYPE,SVMP3_PAGE_POST_TYPE), 'normal', 'high' );
		add_meta_box( 'savemp3-add-faq', __('FAQs', 'savemp3'), array($this, 'savemp3_add_faq'), array(SVMP3_FAQ_POST_TYPE), 'normal', 'high' );
		add_meta_box( 'savemp3-add-faq-shortcode', __('FAQs Shortcode', 'savemp3'), array($this, 'savemp3_add_faq_shortcode'), array(SVMP3_FAQ_POST_TYPE), 'normal', 'high' );
	}

	/**
	 * Post Metabox addoninfo HTML
	 * 
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_add_faq(){
		include_once( SVMP3_INC_DIR .'/admin/metabox/wpos-addon-add-faq.php');
	}

	/**
	 * Post Metabox faq HTML
	 * 
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_add_faq_shortcode(){
		include_once( SVMP3_INC_DIR .'/admin/metabox/wpos-addon-add-faq-shortcode.php');
	}


	/**
	 * Post Metabox settings HTML
	 * 
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_post_settings() {		
		include_once( SVMP3_INC_DIR .'/admin/metabox/savemp3-settings.php');
	}

	/**
	 * Function to save metabox values
	 * 
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_save_metabox_value( $post_id ) {
		global $post_type;

		//$registered_posts = array(SVMP3_DEFAULT_POST_TYPE,SVMP3_WEBSITE_POST_TYPE); // Getting registered post types

		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )                	// Check Autosave
		|| ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] )  	// Check Revision
		|| ( !current_user_can('edit_post', $post_id) )        			// Check if user can edit the post.
		) {
		  return $post_id;
		}

		$prefix = SVMP3_META_PREFIX; // Taking metabox prefix

		if( SVMP3_WEBSITE_POST_TYPE == $post_type || SVMP3_PAGE_POST_TYPE == $post_type){
			// Taking variables
			$input_placeholder 			= isset($_POST[$prefix.'input_placeholder']) ? $_POST[$prefix.'input_placeholder'] : '';	
			$download_video_url 		= isset($_POST[$prefix.'download_video_url']) ? $_POST[$prefix.'download_video_url'] : '';	
			$show_extensions_card 		= isset($_POST[$prefix.'show_extensions_card']) ? $_POST[$prefix.'show_extensions_card'] : '';	
			$related_articles 			= isset($_POST[$prefix.'related_articles']) ? $_POST[$prefix.'related_articles'] : '';	
		

			update_post_meta($post_id, $prefix.'input_placeholder', $input_placeholder);				
			update_post_meta($post_id, $prefix.'download_video_url', $download_video_url);				
			update_post_meta($post_id, $prefix.'show_extensions_card', $show_extensions_card);				
			update_post_meta($post_id, $prefix.'related_articles', $related_articles);				
			
						
		}

		if(SVMP3_FAQ_POST_TYPE == $post_type){
			// Taking variables
			$faq_control 			= isset($_POST[$prefix.'faq_control']) ? $_POST[$prefix.'faq_control'] : '';	
			update_post_meta($post_id, $prefix.'faq_control', $faq_control);				
		}
		
	}
}
$savemp3_admin = new SVMP3_Admin();
