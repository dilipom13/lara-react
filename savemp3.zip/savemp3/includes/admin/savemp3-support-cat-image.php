<?php


if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}

// Action to register plugin settings
add_action( 'admin_init', 'wpos_cat_img_admin_init_process' );
function wpos_cat_img_admin_init_process() {
        // Taxonomy Actions
        $taxonomies = array(SVMP3_SUPPORT_CAT);
        if( !empty($taxonomies) ) {
            foreach ((array) $taxonomies as $taxonomy) {
                wpos_cat_img_taxonomy_hooks( $taxonomy );
            }
        }
    }

    /**
     * Add custom column field
     * 
     * @package Venue Category Image
     * @since 1.0.0
     */
    function wpos_cat_img_taxonomy_hooks( $taxonomy ) {

        add_action( "{$taxonomy}_add_form_fields", 'wpos_cat_img_add_taxonomy_field' );
        add_action( "{$taxonomy}_edit_form_fields", 'wpos_cat_img_edit_taxonomy_field', 10, 2 );

        // Save taxonomy fields
        add_action( 'edited_'.$taxonomy, 'wpos_cat_img_save_taxonomy_meta' );
        add_action( 'create_'.$taxonomy, 'wpos_cat_img_save_taxonomy_meta' );

       
    }

    /**
     * Add form field on taxonomy page
     * 
     * @package Venue Category Image
     * @since 1.0.0
     */
    function wpos_cat_img_add_taxonomy_field( $taxonomy ) {
        include_once( SVMP3_INC_DIR . '/admin/form-field/add-form.php' );
    }

    /**
     * Add form field on edit-taxonomy page
     * 
     * @package Venue Category Image
     * @since 1.0.0
     */
    function wpos_cat_img_edit_taxonomy_field( $term, $taxonomy ) {
        include_once( SVMP3_INC_DIR . '/admin/form-field/edit-form.php' );
    }

    /**
     * Function to add term field on edit screen
     * 
     * @package Venue Category Image
     * @since 1.0.0
     */
    function wpos_cat_img_save_taxonomy_meta( $term_id ) {
        $prefix         = SVMP3_META_PREFIX; // Taking metabox prefix
        $custom_link    = !empty( $_POST[$prefix.'custom_link'] )   ?  $_POST[$prefix.'custom_link']     : '';
        $support_post    = !empty( $_POST[$prefix.'support_post'] )   ?  $_POST[$prefix.'support_post']     : '';
        $cat_order    = !empty( $_POST[$prefix.'cat_order'] )   ?  $_POST[$prefix.'cat_order']     : '';
        $section_control    = !empty( $_POST[$prefix.'section_control'] )   ?  $_POST[$prefix.'section_control']     : '';
        update_term_meta( $term_id, $prefix.'custom_link', $custom_link );    
        update_term_meta( $term_id, $prefix.'support_post', $support_post );    
        update_term_meta( $term_id, $prefix.'cat_order', $cat_order );    
        update_term_meta( $term_id, $prefix.'section_control', $section_control );    

    }

    

    /**
 * Clean variables using sanitize_text_field. Arrays are cleaned recursively.
 * Non-scalar values are ignored.
 * 
 * @package Venue Category Image
 * @since 1.3
 */
function wpos_cat_img_clean( $var ) {
    if ( is_array( $var ) ) {
        return array_map( 'wpos_cat_img_clean', $var );
    } else {
        $data = is_scalar( $var ) ? sanitize_text_field( $var ) : $var;
        return wp_unslash($data);
    }
}

/**
 * Escape Tags & Slashes
 *
 * Handles escapping the slashes and tags
 *
 * @package Venue Category Image
 * @since 1.0.0
 */
function wpos_cat_img_escape_attr($data) {
    return esc_attr( stripslashes($data) );
}
