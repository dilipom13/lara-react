<?php
/**
 * Home Page settings
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'savemp3_tab_content_api_settings', 'savemp3_tab_content_api_settings' );

/**
 * Function to Home Page settings
 *
 * @package Savemp3
 * @since 1.0
 */
function savemp3_tab_content_api_settings() {
	// Take some variable
	global $savemp3_options;

	$MP3_API_URL 		   					= !empty( $savemp3_options['MP3_API_URL'] )?$savemp3_options['MP3_API_URL'] : '';
	$MP3_API_PUBLIC_KEY 		   			= !empty( $savemp3_options['MP3_API_PUBLIC_KEY'] )?$savemp3_options['MP3_API_PUBLIC_KEY'] : '';
	$MP3_API_SECRET_KEY 		   			= !empty( $savemp3_options['MP3_API_SECRET_KEY'] )?$savemp3_options['MP3_API_SECRET_KEY'] : '';
	$MP3_YOUTUBE_API_URL 		   			= !empty( $savemp3_options['MP3_YOUTUBE_API_URL'] )?$savemp3_options['MP3_YOUTUBE_API_URL'] : '';
	$MP3_YOUTUBE_API_PUBLIC_KEY 		   	= !empty( $savemp3_options['MP3_YOUTUBE_API_PUBLIC_KEY'] )?$savemp3_options['MP3_YOUTUBE_API_PUBLIC_KEY'] : '';
	$MP3_YOUTUBE_API_SECRET_KEY 		   	= !empty( $savemp3_options['MP3_YOUTUBE_API_SECRET_KEY'] )?$savemp3_options['MP3_YOUTUBE_API_SECRET_KEY'] : '';

	?>
	<div class="wpos-portlet-wrap">
		<h2><?php _e('API settings', 'savemp3'); ?></h2>
		<table class="form-table">


			<tr>
				<th>
					<label for="MP3_API_URL"><?php _e('MP3 API URL', 'scripthub'); ?></label>
				</th>
				<td>
					<input type="text" id="MP3_API_URL" name="savemp3_options[MP3_API_URL]" class="large-text" value="<?php echo $MP3_API_URL; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="MP3_API_PUBLIC_KEY"><?php _e('MP3 API Public Key', 'scripthub'); ?></label>
				</th>
				<td>
					<input type="text" id="MP3_API_PUBLIC_KEY" name="savemp3_options[MP3_API_PUBLIC_KEY]" class="large-text" value="<?php echo $MP3_API_PUBLIC_KEY; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="MP3_API_SECRET_KEY"><?php _e('MP3 API Secret Key', 'scripthub'); ?></label>
				</th>
				<td>
					<input type="text" id="MP3_API_SECRET_KEY" name="savemp3_options[MP3_API_SECRET_KEY]" class="large-text" value="<?php echo $MP3_API_SECRET_KEY; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="MP3_YOUTUBE_API_URL"><?php _e('MP3 YouTube API URL', 'scripthub'); ?></label>
				</th>
				<td>
					<input type="text" id="MP3_YOUTUBE_API_URL" name="savemp3_options[MP3_YOUTUBE_API_URL]" class="large-text" value="<?php echo $MP3_YOUTUBE_API_URL; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="MP3_YOUTUBE_API_PUBLIC_KEY"><?php _e('MP3 YouTube API Public Key', 'scripthub'); ?></label>
				</th>
				<td>
					<input type="text" id="MP3_YOUTUBE_API_PUBLIC_KEY" name="savemp3_options[MP3_YOUTUBE_API_PUBLIC_KEY]" class="large-text" value="<?php echo $MP3_YOUTUBE_API_PUBLIC_KEY; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="MP3_YOUTUBE_API_SECRET_KEY"><?php _e('MP3 YouTube API Secret Key', 'scripthub'); ?></label>
				</th>
				<td>
					<input type="text" id="MP3_YOUTUBE_API_SECRET_KEY" name="savemp3_options[MP3_YOUTUBE_API_SECRET_KEY]" class="large-text" value="<?php echo $MP3_YOUTUBE_API_SECRET_KEY; ?>">
				</td>
			</tr>



		</table>
	</div>
<?php }
