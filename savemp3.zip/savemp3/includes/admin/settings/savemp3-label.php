<?php
/**
 * Home Page settings
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'savemp3_tab_content_label_settings', 'savemp3_tab_content_label_settings' );

/**
 * Function to Home Page settings
 * 
 * @package Savemp3
 * @since 1.0
 */
function savemp3_tab_content_label_settings() {
	// Take some variable
	global $savemp3_options;	




	/*echo "<pre>";
	print_r($savemp3_options);
	echo "</pre>";*/
	
	$supported_sites_title 		   	= !empty( $savemp3_options['supported_sites_title'] )?$savemp3_options['supported_sites_title'] : '';
	$try_these_savemp3_title 		= !empty( $savemp3_options['try_these_savemp3_title'] )?$savemp3_options['try_these_savemp3_title'] : '';
	$how_to_use_title 		   		= !empty( $savemp3_options['how_to_use_title'] )?$savemp3_options['how_to_use_title'] : '';
	$url_error 		   				= !empty( $savemp3_options['url_error'] )?$savemp3_options['url_error'] : '';
	$paste_link 		   			= !empty( $savemp3_options['paste_link'] )?$savemp3_options['paste_link'] : '';
	$error_1 		   				= !empty( $savemp3_options['error_1'] )?$savemp3_options['error_1'] : '';
	$error_2 		   				= !empty( $savemp3_options['error_2'] )?$savemp3_options['error_2'] : '';
	$error_3 		   				= !empty( $savemp3_options['error_3'] )?$savemp3_options['error_3'] : '';
	$error_4 		   				= !empty( $savemp3_options['error_4'] )?$savemp3_options['error_4'] : '';
	$preparing 		   				= !empty( $savemp3_options['preparing'] )?$savemp3_options['preparing'] : '';
	$darkmode_label 		   		= !empty( $savemp3_options['darkmode_label'] )?$savemp3_options['darkmode_label'] : '';
	$quality_label 		   			= !empty( $savemp3_options['quality_label'] )?$savemp3_options['quality_label'] : '';
	$settings_label 		   		= !empty( $savemp3_options['settings_label'] )?$savemp3_options['settings_label'] : '';
	$view_all_label 		   		= !empty( $savemp3_options['view_all_label'] )?$savemp3_options['view_all_label'] : '';
	$copy_right 		   			= !empty( $savemp3_options['copy_right'] )?$savemp3_options['copy_right'] : '';


	?>
	<div class="wpos-portlet-wrap">
		<h2><?php _e('label settings', 'savemp3'); ?></h2>
		<table class="form-table">
			<tr>
				<th>
					<label for="how_to_use_title"><?php _e('How to use ( title )', 'scripthub'); ?></label>
				</th>
				<td  class="how_to_use_title">
					<input type="text" id="how_to_use_title" name="savemp3_options[how_to_use_title]" class="large-text" value="<?php echo $how_to_use_title; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="supported_sites_title"><?php _e('Supported sites ( title )', 'scripthub'); ?></label>
				</th>
				<td  class="supported_sites_title">
					<input type="text" id="supported_sites_title" name="savemp3_options[supported_sites_title]" class="large-text" value="<?php echo $supported_sites_title; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="try_these_savemp3_title"><?php _e('Try these savemp3 ( title )', 'scripthub'); ?></label>
				</th>
				<td  class="try_these_savemp3_title">
					<input type="text" id="try_these_savemp3_title" name="savemp3_options[try_these_savemp3_title]" class="large-text" value="<?php echo $try_these_savemp3_title; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="settings_label"><?php _e('User Settings label', 'scripthub'); ?></label>
				</th>
				<td  class="settings_label">
					<input type="text" id="settings_label" name="savemp3_options[settings_label]" class="large-text" value="<?php echo $settings_label; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="quality_label"><?php _e('Quality label', 'scripthub'); ?></label>
				</th>
				<td  class="quality_label">
					<input type="text" id="quality_label" name="savemp3_options[quality_label]" class="large-text" value="<?php echo $quality_label; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="darkmode_label"><?php _e('Dark mode label', 'scripthub'); ?></label>
				</th>
				<td  class="darkmode_label">
					<input type="text" id="darkmode_label" name="savemp3_options[darkmode_label]" class="large-text" value="<?php echo $darkmode_label; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="paste_link"><?php _e('Paste link', 'scripthub'); ?></label>
				</th>
				<td  class="paste_link">
					<input type="text" id="paste_link" name="savemp3_options[paste_link]" class="large-text" value="<?php echo $paste_link; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="preparing"><?php _e('Preparing', 'scripthub'); ?></label>
				</th>
				<td  class="preparing">
					<input type="text" id="preparing" name="savemp3_options[preparing]" class="large-text" value="<?php echo $preparing; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="url_error"><?php _e('URL Error', 'scripthub'); ?></label>
				</th>
				<td  class="url_error">
					<input type="text" id="url_error" name="savemp3_options[url_error]" class="large-text" value="<?php echo $url_error; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="error_1"><?php _e('Error 1', 'scripthub'); ?></label>
				</th>
				<td  class="error_1">
					<input type="text" id="error_1" name="savemp3_options[error_1]" class="large-text" value="<?php echo $error_1; ?>">
				</td>
			</tr>
			<tr>
				<th>
					<label for="error_2"><?php _e('Error 2', 'scripthub'); ?></label>
				</th>
				<td  class="error_2">
					<input type="text" id="error_2" name="savemp3_options[error_2]" class="large-text" value="<?php echo $error_2; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="error_3"><?php _e('Error 3', 'scripthub'); ?></label>
				</th>
				<td  class="error_3">
					<input type="text" id="error_3" name="savemp3_options[error_3]" class="large-text" value="<?php echo $error_3; ?>">
				</td>
			</tr>
			<tr>
				<th>
					<label for="error_4"><?php _e('Error 4', 'scripthub'); ?></label>
				</th>
				<td  class="error_4">
					<input type="text" id="error_4" name="savemp3_options[error_4]" class="large-text" value="<?php echo $error_4; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="view_all_label"><?php _e('View All Sites', 'scripthub'); ?></label>
				</th>
				<td  class="error_4">
					<input type="text" id="view_all_label" name="savemp3_options[view_all_label]" class="large-text" value="<?php echo $view_all_label; ?>">
				</td>
			</tr>

			<tr>
				<th>
					<label for="copy_right"><?php _e('Copy right', 'scripthub'); ?></label>
				</th>
				<td  class="error_4">
					<input type="text" id="copy_right" name="savemp3_options[copy_right]" class="large-text" value="<?php echo $copy_right; ?>">
				</td>
			</tr>
		</table>
	</div>
<?php }