<?php

if ( ! defined( 'ABSPATH' ) ) {
	die();
}

$args = array ( 
                    'post_type'             => array('page','post'),
                    'post_status'           => array('publish'),
                    'posts_per_page'        => -1,
                    'suppress_filters' 		=> 0
              );

$post_lists      = get_posts($args);
$languages 		 = get_active_wpml_lang();

?>
<style type="text/css">
label.savemp3-checkbox-label {
    margin-right: 20px;
}
.current_slug_result{
	padding-top: 19px;
    padding-bottom: 26px;
    color: green;
}

.current_slug_result {
    -webkit-touch-callout: all;
    -webkit-user-select: all;
    -khtml-user-select: all;
    -moz-user-select: all;
    -ms-user-select: all;
    user-select: all;
    background-color: #e7e7e7;
    font-weight: 600;
    padding: 2px 5px;
    display: inline-block;
    margin: 0 0 2px 0;
}
.savemp3-result-row{display: none;}
.savemp3-result-copied{ color: green;display: none; }
</style>
<div class="wrap">
	   <h1>Bulk Post/Page Slug Editor</h1>
		<table class="form-table">
			<tr>
				<td  class="default_placeholder">
					<select  name="savemp3_post_slug_list" class="savemp3_post_slug_list savemp3_select2" id="savemp3_post_slug_list">
				    <option data-slug="" value="">------------------------select------------------------</option>
				    <?php   if ( !empty($post_lists) ) {             
				    foreach( $post_lists as $post_list ){
				    	$title 				= wp_strip_all_tags( $post_list->post_title );
				    	?>
				        <option data-slug="<?php echo $post_list->post_name; ?>" value="<?php echo $post_list->ID; ?>"> <?php echo $title;  ?></option>
				    <?php  } } ?>
				    </select>
				</td>
			</tr>
			<tr>
				<td  class="savemp3_current_slug">
					<input type="text" class="large-text savemp3_current_slug savemp3_current_new_val" name="savemp3_current_slug">
				</td>
			</tr>

			<tr>
				<td  class="current_slug">
					
					<label class="savemp3-checkbox-label"><input type="checkbox" class="sel_all" name="selected_slug[]"  value="all">All</label>
					<?php 
					if( !empty($languages)){
						foreach ($languages as $key => $language) { ?>
							<label class="savemp3-checkbox-label"><input type="checkbox"  name="selected_slug[]"  class="sel_<?php echo $key; ?> selected_single common_selected_single" value="<?php echo $key; ?>"> <?php echo $language['native_name']; ?> </label>			
					    <?php	}
					}
					?>
				</td>
			</tr>

			<tr>
				<td  class="current_slug">
					<input type="button" name="slug_change" id="sh-submit" class="button button-primary slug_change" value="Start">
				</td>
			</tr>

			<tr class="savemp3-result-row">
				<td  class="current_slug_result_wrap">
					<h3>Result  <span class="savemp3-result-copied">copied</span> </h3>
					<div class="current_slug_result">
						
					</div>
				</td>
			</tr>
		</table>
</div>
