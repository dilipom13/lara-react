<?php
/**
 * Home Page settings
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'savemp3_tab_content_general_settings', 'savemp3_tab_content_general_settings' );

/**
 * Function to Home Page settings
 * 
 * @package Savemp3
 * @since 1.0
 */
function savemp3_tab_content_general_settings() {
	// Take some variable
	global $savemp3_options;	
	$default_placeholder 		   	= !empty( $savemp3_options['default_placeholder'] )?$savemp3_options['default_placeholder'] : '';
	$max_results_show 		   		= !empty( $savemp3_options['max_results_show'] )?$savemp3_options['max_results_show'] : '';
	$home_page 		   				= !empty( $savemp3_options['home_page'] )?$savemp3_options['home_page'] : '';
	$enable_google_drive 		    = !empty( $savemp3_options['enable_google_drive'] )?1 : 0;
	$enable_dropbox_drive 		    = !empty( $savemp3_options['enable_dropbox_drive'] )?1 : 0;


	$args = array ( 
                    //'post_type'             => SVMP3_WEBSITE_POST_TYPE,
                    'post_type'             => 'page',
                    'post_status'           => array('publish'),
                    'posts_per_page'        => -1,
                    'suppress_filters' 		=> 0
                  );

	$post_lists      = get_posts($args);

	
	?>
	<div class="wpos-portlet-wrap">
		<h2><?php _e('General settings', 'savemp3'); ?></h2>
		<table class="form-table">
			<tr>
				<th>
					<label for="default_placeholder"><?php _e('Home page', 'scripthub'); ?></label>
				</th>
				<td  class="default_placeholder">
					<select  name="savemp3_options[home_page]">

				    <?php   if ( !empty($post_lists) ) {             
				    foreach( $post_lists as $post_list ){
				    	$title 				= wp_strip_all_tags( $post_list->post_title );
				    	$template_slug      = get_page_template_slug($post_list->ID);
				    	?>
				        <option <?php echo ( $post_list->ID == $home_page  )?'selected':''; ?> value="<?php echo $post_list->ID; ?>"> <?php echo $title;  ?></option>
				    <?php  } } ?>
				    </select>
				</td>
			</tr>

			<tr>
				<th>
					<label for="default_placeholder"><?php _e('Default placeholder', 'scripthub'); ?></label>
				</th>
				<td  class="default_placeholder">
					<input type="text" id="default_placeholder" name="savemp3_options[default_placeholder]" class="large-text" value="<?php echo $default_placeholder; ?>">
				</td>
			</tr>


			

			<tr>
				<th>
					<label for="max_results_show"><?php _e('Playlist max results show', 'scripthub'); ?></label>
				</th>
				<td  class="max_results_show">
					<input type="number" id="max_results_show" name="savemp3_options[max_results_show]" class="large-text" value="<?php echo $max_results_show; ?>">
				</td>
			</tr>
			<tr>
				<th>
					<label for="enable_google_drive"><?php _e('Enable google drive', 'scripthub'); ?></label>
				</th>
				<td  class="enable_google_drive">
					<input type="checkbox" <?php echo !empty($enable_google_drive)?'checked':''; ?> id="enable_google_drive" name="savemp3_options[enable_google_drive]" class="" value="1"> 
				</td>
			</tr>

			<tr>
				<th>
					<label for="enable_dropbox_drive"><?php _e('Enable dropbox drive', 'scripthub'); ?></label>
				</th>
				<td  class="enable_dropbox_drive">
					<input type="checkbox" <?php echo !empty($enable_dropbox_drive)?'checked':''; ?> id="enable_dropbox_drive" name="savemp3_options[enable_dropbox_drive]" class="" value="1"> 
				</td>
			</tr>
			
		</table>
	</div>
<?php }