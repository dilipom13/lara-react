<?php
/**
 * Home Page settings
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'savemp3_tab_content_browser_extensions', 'savemp3_tab_content_browser_extensions' );

/**
 * Function to Home Page settings
 * 
 * @package Savemp3
 * @since 1.0
 */
function savemp3_tab_content_browser_extensions() {
	// Take some variable
	global $savemp3_options;
	
	/*$gallery_imgs 		   		= !empty( $savemp3_options['screen_shot_ids'] )?$savemp3_options['screen_shot_ids'] : '';
	$no_img_cls					= !empty($gallery_imgs) 			? 'wpos-hide' 		: '';
	$title 		   				= !empty( $savemp3_options['title'] )?$savemp3_options['title'] : '';
	$description 		   		= !empty( $savemp3_options['description'] )?$savemp3_options['description'] : '';
	$image 		   				= !empty( $savemp3_options['image'] )?$savemp3_options['image'] : '';
	$icon_scr 					= !empty($image['icon_scr'])?$image['icon_scr']:'';
	$icon_id 					= !empty($image['icon_id'])?$image['icon_id']:'';
	*/

	$card_title 		   	= !empty( $savemp3_options['card_title'] )?$savemp3_options['card_title'] : '';
	$card_description 		= !empty( $savemp3_options['card_description'] )?$savemp3_options['card_description'] : '';
	$card_image 			= !empty( $savemp3_options['card_image'] )?$savemp3_options['card_image'] : '';
	$icon_scr 				= !empty($card_image['icon_scr'])?$card_image['icon_scr']:'';
	$icon_id 				= !empty($card_image['icon_id'])?$card_image['icon_id']:'';

	$update_url 		   		= !empty( $savemp3_options['update_url'] )?$savemp3_options['update_url'] : '';
	$emulator 		   			= !empty( $savemp3_options['emulator'] )?$savemp3_options['emulator'] : '';
	$opera 		   				= !empty( $savemp3_options['opera'] )?$savemp3_options['opera'] : '';
	$userscript 		   		= !empty( $savemp3_options['userscript'] )?$savemp3_options['userscript'] : '';

	?>

	<div class="wpos-portlet-wrap" id="wpos-portlet-wrap">
		<h2><?php _e('Browser extensions', 'addoncrop'); ?></h2>
		<table class="form-table">
		<tr >
			<th scope="row">
				<label for="card_title"><?php _e('Title', 'savemp3'); ?></label>
			</th>
			<td>
				<textarea id="card_title" class="large-text" name="savemp3_options[card_title]"><?php echo  $card_title; ?></textarea>
			</td>
		</tr>
		<tr >
			<th scope="row">
				<label for="card_description"><?php _e('Description', 'savemp3'); ?></label>
			</th>
			<td>
				<textarea id="card_description" class="large-text" name="savemp3_options[card_description]"><?php echo  $card_description; ?></textarea>
			</td>
		</tr>
		<tr >
			<th scope="row">
				<label for="card_image"><?php _e('Cart Image', 'savemp3'); ?></label>
			</th>
			<td>
				<div class="wpos-overview-img wpos-row">
			        <div class="center">
			            <input type="text" autocomplete="off" name="savemp3_options[card_image][icon_scr]" value="<?php echo $icon_scr;?>" class="regular-text wpos-icon wpos_overview_thumb_cls" />
			            <input type="hidden" name="savemp3_options[card_image][icon_id]" value="<?php echo $icon_id;?>" class="wpos_overview_thumb_id" />
			            <input type="button" name="wpos_icon_thumb" class="button-secondary wpos-overview-image-upload" value="<?php _e( 'Upload Image', 'savemp3'); ?>" data-uploader-title="<?php _e('Choose Image', 'savemp3'); ?>" data-uploader-button-text="<?php _e('Insert Image', 'savemp3'); ?>" />
			            <input type="button" name="wpos_image_clear" id="wpos-image-clear" class="button button-secondary wpos-image-clear" value="<?php _e( 'Clear', 'savemp3'); ?>" /> <br />
			        </div>
			        <?php
			            $default_img = '';
			            if( !empty($icon_scr) ) { 
			                $default_img = '<img src="'.$icon_scr.'" alt="" />';
			            } ?>
			        <div class="wpos_img_view"><?php echo $default_img; ?></div>
			    </div>
			</td>
		</tr>

		<tr>
			<th>
				<label for="update_url"><?php _e('Update URL', 'scripthub'); ?></label>
			</th>
			<td  class="update_url">
				<input type="text" id="update_url" name="savemp3_options[update_url]" class="large-text" value="<?php echo $update_url; ?>">
			</td>
		</tr>

		<tr>
			<th>
				<label for="emulator"><?php _e('Emulator', 'scripthub'); ?></label>
			</th>
			<td  class="emulator">
				<input type="text" id="emulator" name="savemp3_options[emulator]" class="large-text" value="<?php echo $emulator; ?>">
			</td>
		</tr>

		<tr>
			<th>
				<label for="opera"><?php _e('Opera', 'scripthub'); ?></label>
			</th>
			<td  class="opera">
				<input type="text" id="opera" name="savemp3_options[opera]" class="large-text" value="<?php echo $opera; ?>">
			</td>
		</tr>

		<tr>
			<th>
				<label for="userscript"><?php _e('User Script', 'scripthub'); ?></label>
			</th>
			<td  class="userscript">
				<input type="text" id="userscript" name="savemp3_options[userscript]" class="large-text" value="<?php echo $userscript; ?>">
			</td>
		</tr>

			
		</table>
	</div>
<?php }
