<?php
/**
 * Home Page settings
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'savemp3_tab_content_ads_settings', 'savemp3_tab_content_ads_settings' );

/**
 * Function to Home Page settings
 * 
 * @package Savemp3
 * @since 1.0
 */
function savemp3_tab_content_ads_settings() {
	// Take some variable
	global $savemp3_options;
	
	$ads_type 		   	= !empty( $savemp3_options['ads_type'] )?$savemp3_options['ads_type'] : '';
	$ads_html 		   	= !empty( $savemp3_options['ads_html'] )?$savemp3_options['ads_html'] : '';
	$ads_url 		   	= !empty( $savemp3_options['ads_url'] )?$savemp3_options['ads_url'] : '';
	

	?>

	<div class="wpos-portlet-wrap" id="wpos-portlet-wrap">
		<h2><?php _e('Ads settings', 'addoncrop'); ?></h2>
		<table class="form-table">
		<tr >
			<th scope="row">
				<label for="ads_html"><?php _e('HTML Code', 'savemp3'); ?></label>
			</th>
			<td><input type="radio" <?php echo ( $ads_type  == 'ads_html' )?'checked':''; ?> name="savemp3_options[ads_type]" value="ads_html"></td>
			<td>
				 <textarea id="ads_html" class="large-text" name="savemp3_options[ads_html]"><?php echo  $ads_html; ?></textarea>
			</td>
		</tr>
		

		<tr>
			<th>
				<label for="ads_url"><?php _e('URL', 'scripthub'); ?></label>
			</th>
			<td><input type="radio" <?php echo ( $ads_type  == 'ads_url' )?'checked':''; ?> name="savemp3_options[ads_type]" value="ads_url"></td>
			<td  class="ads_url">
				 <input type="text" id="ads_url" name="savemp3_options[ads_url]" class="large-text" value="<?php echo $ads_url; ?>">
			</td>
		</tr>
			
		</table>
	</div>
<?php }
