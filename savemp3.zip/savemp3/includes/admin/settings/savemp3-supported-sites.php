<?php
/**
 * Home Page settings
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'savemp3_tab_content_supported_sites', 'savemp3_tab_content_supported_sites' );

/**
 * Function to Home Page settings
 *
 * @package Savemp3
 * @since 1.0
 */
function savemp3_tab_content_supported_sites() {
	// Take some variable
	global $savemp3_options;

	$default_array      = array(
			    				1  => array(
									'class' 	=> 'icon-youtube',
									'name' 		=> 'Youtube',
									'label' 	=> 'Youtube',
									'link' 		=> '#',

								),
			                );

	$supported_sites 			= !empty( $savemp3_options['supported-site'] )?$savemp3_options['supported-site'] : $default_array;

	$args = array ( 
							                        //'post_type'             => SVMP3_WEBSITE_POST_TYPE,
							                        'post_type'             => 'page',
							                        'post_status'           => array('publish'),
							                        'posts_per_page'        => -1,
							                        'suppress_filters' 		=> 0
							                      );

							    $post_lists      = get_posts($args);

	?>

	<div class="wpos-portlet-wrap" id="wpos-portlet-wrap">
		<h2><?php _e('Addon Languages', 'addoncrop'); ?></h2>
		<table class="form-table">
			<tr id="supported_sites_options">
				<th>
					<label for="savemp3_class"><?php _e('Supported Sites ', 'savemp3'); ?></label>
				</th>

				<td  class="rpt-supported-site-item-wrap">
					<?php
					if( !empty( $supported_sites ) ){

					foreach ( $supported_sites as $supported_sites_key => $supported_sites_value ) {

						$class 	= !empty($supported_sites_value['class'])?$supported_sites_value['class']:'';
						$name 	= !empty($supported_sites_value['name'])?$supported_sites_value['name']:'';
						$label 	= !empty($supported_sites_value['label'])?$supported_sites_value['label']:'';
						echo $link 	= !empty($supported_sites_value['link'])?$supported_sites_value['link']:'';

						?>

					<div class="rpt-supported-site-item" data-key="<?php echo $supported_sites_key;?>">

						<div class="input-group">
                            <label for="icon">Icon</label>
                            <input placeholder="Class" type="text" class="regular-text savemp3_class" name="savemp3_options[supported-site][<?php echo $supported_sites_key; ?>][class]" value="<?php  echo $class; ?>">
                        </div>

                        <div class="input-group">
                            <label for="title">Site title</label>
                            <input placeholder="Name" type="text" class="regular-text savemp3_name" name="savemp3_options[supported-site][<?php echo $supported_sites_key; ?>][name]" value="<?php  echo $name; ?>">
                        </div>

                        <div class="input-group">
                            <label for="label">Label</label>
                            <input placeholder="Label" type="text" class="regular-text savemp3_label" name="savemp3_options[supported-site][<?php echo $supported_sites_key; ?>][label]" value="<?php  echo $label; ?>">
                        </div>

                        <div class="input-group">
                            <label for="link">Link</label>

                            <?php 
								
							    ?>
							    <select  name="savemp3_options[supported-site][<?php echo $supported_sites_key; ?>][link]">

							    <?php   if ( !empty($post_lists) ) {             
							    foreach( $post_lists as $post_list ){

							    	$title 				= wp_strip_all_tags( $post_list->post_title );
							    	
							    	$template_slug      = get_page_template_slug($post_list->ID);

							    	if( $template_slug == 'page-templates/converter-page.php' ){
							    	?>
							        <option <?php echo ( $post_list->ID == $link  )?'selected':''; ?> value="<?php echo $post_list->ID; ?>"> <?php echo $title;  ?></option>
							    <?php } } } ?>
							    </select>
                                
                        </div>


						<span style="color: red;cursor: pointer;" class="delete dashicons dashicons-no-alt"></span>

					</div>
					<?php } } ?>
				</td>
			</tr>
			<tr >
				<th> </th>
				<td>
					<button type="button" class="button-secondary add_supported_sites_item">Add New Languages</button>
				</td>
			</tr>
		</table>
	</div>
<?php }
