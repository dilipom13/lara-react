<?php
/**
 * Settings File
 *
 * Handles the settings HTML functionality of theme
 *
 * @package WP Clean Responsive
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
$theme_tabs 		= savemp3_theme_sett_tab(); // Getting theme tabs
$theme_tabs_keys 	= savemp3_theme_sett_tab(true); // Getting theme tabs ?>

<div class="wrap">
	<h2><?php _e('Theme Settings', 'savemp3'); ?></h2>
	<?php
	// Reset theme settings
	if( isset($_POST['wpos_settings_reset']) && !empty($_POST['wpos_settings_reset']) ) {
		savemp3_default_settings(); // set default settings
		// Reset message
		echo '<div id="message" class="updated notice notice-success is-dismissible">
				<p>' . __( 'All settings reset successfully.', 'savemp3') . '</p>
			 </div>';
	} ?>

	<div class="wpos-sett-wrp wpos-clearfix">
		<form action="" method="post" id="wpos-reset-sett-form">
			<div class="wpos-reset-sett-wrp wpos-clearfix">				
				<input type="submit" value="<?php _e('Reset All Theme Options', 'savemp3') ?>" class="wpos-settings-reset button button-primary right" name="wpos_settings_reset" id="wpos-settings-reset" />
				<div class="savemp3-success-msg savemp3-success wpos-hide" id="savemp3-success-msg"><i class="dashicons dashicons-yes"></i> <?php _e('Settings Saved Successfully', 'savemp3') ?></div>
			</div><!-- end .wpos-reset-sett-wrp -->
		</form>

		<form action="options.php" method="post" class="savemp3-settings-form" id="savemp3-settings-form">
		<?php settings_fields( 'wpos_theme_options_sett' );	global $wpos_options; ?>

			<div class="wpos-sett-header">
				<div class="wpos-sett-title"><?php _e('Theme Options', 'savemp3') ?></div>	
			</div>

			<div class="wpos-sett-content-wrp wpos-clearfix">			    
				<ul id="wpos-tab-nav" class="wpos-tab-nav wpos-tab-nav-wrp">
					<?php
					if( !empty($theme_tabs) ) {
						$i 			= 0;
						$tab_html 	= '';
						foreach ($theme_tabs as $theme_tab_key => $theme_tab_val) {								
							$tab_name			= isset($theme_tab_val['name']) 	? $theme_tab_val['name'] 		: '';
							$tab_icon_cls		= isset($theme_tab_val['icon_cls']) ? $theme_tab_val['icon_cls'] 	: 'dashicons-admin-generic';
							$sub_menu			= !empty($theme_tab_val['sub_menu'])? $theme_tab_val['sub_menu']	: array();
							$active_li 			= '';
							$tab_nav_active_cls = '';
							$sub_nav_cls 		= 'wpos-hide';
							if( $i == 0 ){
								$tab_nav_active_cls = 'wpos-tab-nav-active';
								$active_li 			= 'wpos-tab-nav-li-active';
								$sub_nav_cls 		= '';
							}
							$tab_html .= "<li class='wpos-tab-nav-li {$active_li}'>";
							$tab_html .= "<a class='{$tab_nav_active_cls}' href='#{$theme_tab_key}'><i class='dashicons {$tab_icon_cls}'></i> {$tab_name}</a>";

							// Sub menu
							if( is_array($sub_menu) && !empty($sub_menu) ) {
								$tab_html .= "<ul class='wpos-sub-tab-nav {$sub_nav_cls}'>";
								foreach ($sub_menu as $sub_menu_key => $sub_menu_val) {
									$tab_html .= "<li class='wpos-sub-tab-nav-li'>";
									$tab_html .= "<a href='#{$sub_menu_key}' data-link='sub-menu'>{$sub_menu_val}</a>";
									$tab_html .= "</li>";
								}
								$tab_html .= "</ul>";
							}
							$tab_html .= "</li>";
							$i++;
						} // End main for each
						echo $tab_html;
					} ?>
				</ul>
				
				<div class="wpos-tabs-cnt-wrp">
				<!-- Top Save Button -->
					<div>
						<input type="submit" value="<?php _e('Save Changes', 'savemp3') ?>" class="wpos-settings-submit button button-primary right" name="wpos-settings-submit" id="wpos-settings-submit" />
						<span class="spinner"></span>
					</div>
					<?php
						if( !empty($theme_tabs_keys) ) {
							$i = 0;
							foreach ($theme_tabs_keys as $theme_tab_key => $theme_tab_val) {
								$tab_cnt_active_cls = ($i == 0) ? '' : 'wpos-hide';	?>
								<div id="<?php echo $theme_tab_val; ?>" class="wpos-tab-cnt <?php echo $tab_cnt_active_cls; ?>">
									<?php do_action('savemp3_tab_content_'.$theme_tab_val); ?>
								</div><?php
								$i++;
							}
						} ?>
				</div><!-- end .wpos-tabs-cnt-wrp -->
			</div><!-- end wpos-sett-content-wrp -->

			<div class="wpos-sett-footer wpos-clearfix">
				<input type="submit" value="<?php _e('Save Changes', 'savemp3') ?>" class="wpos-settings-submit button button-primary right" name="wpos-settings-submit" id="wpos-settings-submit" />
				<span class="spinner"></span>
			</div><!-- end .wpos-sett-footer -->
		</form><!-- end .savemp3-settings-form -->
	</div><!-- end .wpos-sett-wrp -->
</div><!-- end .wrap -->
