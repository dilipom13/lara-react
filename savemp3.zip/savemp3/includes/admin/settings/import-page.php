<?php
/**
 * Home Page settings
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// Action to add Home Page settings
add_action( 'savemp3_tab_content_import_page', 'savemp3_tab_content_import_page' );

/**
 * Function to Home Page settings
 * 
 * @package Savemp3
 * @since 1.0
 */
function savemp3_tab_content_import_page() {
	// Take some variable
	 global $savemp3_options;	
	

	
	?>
	 <div class="wpos-portlet-wrap" id="wpos-portlet-wrap">
		<h2><?php _e('Import/Export', 'savemp3'); ?></h2>
		<table class="form-table">
		<tr>
			<th>
				<label>Export </label>
			</th>
			<td>
				<textarea readonly="" class="large-text" id="theme_setting_export"><?php echo json_encode($savemp3_options); ?></textarea>
			</td>
		</tr>
		<tr>
			<th>
				<label>Import </label>
			</th>
			<td>
				<textarea class="large-text" id="theme_setting_import"></textarea>
				<input type="button" value="Import Settings" class="theme_setting_import_btn button button-primary right" id="theme_setting_import_btn">
			</td>
		</tr>
      </table>
	</div><!-- end .wpos-portlet-wrap -->
<?php }
