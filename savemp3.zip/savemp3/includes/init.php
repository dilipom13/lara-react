<?php
/**
 * Call Function on init function
 *
 * @package Savemp3
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

if( !defined( 'SVMP3_INC_DIR' ) ) {
    define( 'SVMP3_INC_DIR', dirname( __FILE__ ) ); // inc dir
}
if( !defined( 'SVMP3_INC_URL' ) ) {
    define( 'SVMP3_INC_URL', get_template_directory_uri().'/includes/'); // inc url
}

//include class to detect browser
require SVMP3_INC_DIR. '/vendor/autoload.php';

// Global variables
global $savemp3_options,$browser;

//include functions
require SVMP3_INC_DIR. '/savemp3-functions.php';
require SVMP3_INC_DIR. '/api.php';

$savemp3_options = savemp3_get_theme_settings();
$browser         = savemp3_get_curent_browserinfo();

//include style and script
require SVMP3_INC_DIR. '/class-savemp3-script.php';

//include register faq post type
require SVMP3_INC_DIR. '/admin/savemp3-faq-post-types.php';

//include register contact post type
require SVMP3_INC_DIR. '/admin/savemp3-contact-post-types.php';

//include register contact post type
//require SVMP3_INC_DIR. '/admin/savemp3-websites-post-types.php';

//include admin function
require SVMP3_INC_DIR. '/admin/class-savemp3-admin.php';

//include shortcode
require SVMP3_INC_DIR. '/shortcodes/faq-shortcode.php';

//include admin files
require SVMP3_INC_DIR. '/admin/settings/savemp3-general-settings.php';
//require SVMP3_INC_DIR. '/admin/settings/savemp3-label.php';
require SVMP3_INC_DIR. '/admin/settings/import-page.php';
require SVMP3_INC_DIR. '/admin/settings/savemp3-supported-sites.php';
require SVMP3_INC_DIR. '/admin/settings/savemp3-browser-extensions.php';
require SVMP3_INC_DIR. '/admin/settings/savemp3-api-settings.php';
require SVMP3_INC_DIR. '/admin/settings/savemp3-ads-settings.php';


//slug manager
require SVMP3_INC_DIR. '/savemp3-slug-manager.php';
