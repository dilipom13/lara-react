<?php 


function savemp3_slug_change() {
    
    
    header('Access-Control-Allow-Origin: *');
    $post_id        = !empty($_POST['post_id'])     ? $_POST['post_id']     : '';
    $new_slug       = !empty($_POST['new_slug'])    ? $_POST['new_slug']    : '';
    $lang_list      = !empty($_POST['lang_list'])   ? $_POST['lang_list']   : '';
    $changed_post   =  array();
    $changed_slg   =  '';

    $result =  array();   

    if( !empty($lang_list) && !empty($post_id) && !empty($new_slug) ){

        foreach ( $lang_list as $key => $lg ) {
            $post_type      = get_post_type($post_id);
            if( !empty($post_type) ){
                $lang_post_id   = apply_filters( 'wpml_object_id', $post_id, $post_type, true, $lg );
                $new_slug       = sanitize_title( $new_slug );
                 wp_update_post(
                            array (
                                'ID'        => $lang_post_id,
                                'post_name' => $new_slug
                            )
                 );

                 $changed_slg .= get_permalink($lang_post_id);  
                 $changed_slg .= '<br>';  
                } 
            
        }

        $result['html']   =  $changed_slg;
        $result['status'] = 1;   
    }

    wp_send_json( $result );
    die();
   

}

add_action( 'wp_ajax_savemp3_slug_change','savemp3_slug_change' );


function post_slug_options() {
    include_once( SVMP3_DIR. '/includes/admin/settings/slug-settings.php' );
}

function sh_add_menu_related_post_cache() {
    add_management_page(
        'Bulk Post/Page Slug Editor',
        'Bulk Post/Page Slug Editor',
        'manage_options',
        'slug-settings',
        'post_slug_options',
    );
}

add_action( 'admin_menu','sh_add_menu_related_post_cache' );

