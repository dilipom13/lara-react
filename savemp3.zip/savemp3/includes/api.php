<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function send_request( array $data, $path = '' ) {
	$client = new \GuzzleHttp\Client();

	$response = $client->post(
		'https://ytmp3.savevids.net/api/json' . $path,
		array(
			'headers'                        => array(
				'Content-Type' => 'application/json',
				'Accept'       => 'application/json',
			),
			\GuzzleHttp\RequestOptions::JSON => $data,
		),
	);

	return json_decode( $response->getBody()->getContents() );
}

function get_video_info( WP_REST_Request $request ) {
	return send_request(
		array(
			'ftype' => 'mp3',
			'url'   => $request['url'],
		),
	);
}

function download( WP_REST_Request $request ) {
	$from          = $request['from'];
	$to            = $request['to'];
	$length        = $request['length'];
	$output_length = $length;

	if ( $from && $to ) {
		$output_length = $to - $from;
	} elseif ( $from ) {
		$output_length = $length - $from;
	} elseif ( $to ) {
		$output_length = $to;
	}

	$output_length_hours = $output_length / ( 60 * 60 );

	if ( $output_length_hours > 2 ) {
		return new WP_REST_Response(
			array(
				'error'    => true,
				'code'     => 401,
				'errorMsg' => 'Bad Request',
				'message'  => 'Maximum duration of 120 minutes is allowed for MP3 downloads.',
			),
			401,
		);
	}

	return send_request(
		array(
			'hash' => $request['hash'],
			'from' => $request['from'],
			'to'   => $request['to'],
		),
	);
}

function status( WP_REST_Request $request ) {
	return send_request( array( 'taskId' => $request['taskId'] ), '/task' );
}

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'api/v1',
			'get_video_info',
			array(
				'methods'  => 'POST',
				'callback' => 'get_video_info',
			),
		);

		register_rest_route(
			'api/v1',
			'download',
			array(
				'methods'  => 'POST',
				'callback' => 'download',
			),
		);

		register_rest_route(
			'api/v1',
			'status',
			array(
				'methods'  => 'POST',
				'callback' => 'status',
			),
		);
	},
);
