<?php
/**
 * Script Class
 *
 * Handles the script and style functionality of plugin
 *
 * @package Savemp3
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

class Savemp3_Script {

	function __construct() {

		// Action to add style in front end
		add_action( 'wp_enqueue_scripts', array($this, 'savemp3_front_styles'), 1 );

		// Action to add script in front end
		add_action( 'wp_enqueue_scripts', array($this, 'savemp3_front_scripts'), 1 );

		// Action to add style in backend
		 add_action( 'admin_enqueue_scripts', array($this, 'savemp3_admin_style') );

		// Action to add script at admin side
		 add_action( 'admin_enqueue_scripts', array($this, 'savemp3_admin_script') );

	}

	/**
	 * Function to add script at admin side
	 *
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_admin_script( $hook ) {


		// Take some variable
		global $wp_version, $wp_query, $post_type;

		$registered_posts 	= array('post','page','profile.php','widgets.php','user-edit.php','edit-tags.php','term.php','appearance_page_savemp3','appearance_page_savemp3-report','toplevel_page_wpos-settings','toplevel_page_dmc-setting','appearance_page_addoncrop'); // Getting registered post types
		$new_ui 			= $wp_version >= '3.5' ? '1' : '0'; // Check wordpress version for older scripts

		//if( in_array($post_type, $registered_posts) || in_array($hook, $registered_posts) ) {

			wp_enqueue_script( 'jquery-ui-datepicker' );
			wp_enqueue_script( 'jquery-ui-sortable' );
			//wp_enqueue_script( 'jquery' );
			// Enqueu and localize admin JS
			wp_register_script( 'savemp3-admin-script', SVMP3_URL.'/js/custom-admin.js', array('jquery'), SVMP3_VERSION, true );
			wp_localize_script( 'savemp3-admin-script', 'savemp3admin', array(
																	'new_ui' 				=>	$new_ui,
																	'img_edit_popup_text'	=> __('Edit screenshot in Popup', 'savemp3'),
																	'attachment_edit_text'	=> __('Edit screenshot', 'savemp3'),
																	'img_delete_text'		=> __('Remove screenshot', 'savemp3'),
																	'all_img_delete_text'	=> __('Are you sure to remove all screenshot!', 'savemp3'),
																	'sry_delete_msg'		=> __('Sorry, One entry should be there.', 'savemp3'),
																));

			wp_enqueue_script( 'savemp3-admin-script' );

			
			if($hook == 'tools_page_slug-settings'){

				wp_register_script( 'sh-select2-script', SVMP3_URL.'/js/select2.min.js', array('jquery'), SVMP3_VERSION, true );
				wp_enqueue_script( 'sh-select2-script' );
				wp_enqueue_style( 'sh-select2-css', SVMP3_URL.'/css/select2.min.css', null, SVMP3_VERSION );
			}

			// For media uploader
			wp_enqueue_media();
			//}

	}

	/**
	 * Enqueue admin styles
	 *
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_admin_style( $hook ) {

		global $post_type;
		$registered_posts = array('post','page','profile.php','user-edit.php','edit-tags.php','term.php','appearance_page_savemp3','appearance_page_savemp3-report','toplevel_page_wpos-settings','appearance_page_addoncrop');
		// If page is plugin setting page then enqueue script
		//if( in_array($post_type, $registered_posts) || in_array($hook, $registered_posts)) {
			// Registring admin script
			wp_register_style( 'savemp3-admin-style', SVMP3_URL.'/css/custom-admin.css', null, SVMP3_VERSION );
			wp_enqueue_style( 'savemp3-admin-style' );

			wp_register_style('jquery-ui', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css');
  			wp_enqueue_style( 'jquery-ui' );
		//}


	}
	/**
	 * Enqueue styles for front-end
	 *
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_front_styles() {
		global $wp_styles;
		wp_enqueue_style( 'savemp3-style', get_stylesheet_uri(), array(), SVMP3_VERSION);
		wp_enqueue_style( 'main-css', SVMP3_URL . '/css/main.css', array(), SVMP3_VERSION);

	}

	/**
	 * Enqueue scripts for front-end
	 *
	 * @package Savemp3
	 * @since 1.0
	 */
	function savemp3_front_scripts() {

		global $browser, $post, $savemp3_options;

		$prefix                 = SVMP3_META_PREFIX; // Metabox prefix
		$post_id 				= !empty($post->ID)?$post->ID:'';

		$dropbox_upload_cookie  =  !empty( $_COOKIE['dropbox_upload'] )?$_COOKIE['dropbox_upload']:'on';
		$gdrive_upload_cookie   =  !empty( $_COOKIE['gdrive_upload'] )?$_COOKIE['gdrive_upload']:'on';
		$select_quality   		=  !empty( $_COOKIE['select_quality'] )?$_COOKIE['select_quality']:'128kbps';
		$dark_mode   			=  !empty( $_COOKIE['dark_mode'] )?$_COOKIE['dark_mode']:'on';

		$dropbox_drive_global   =  !empty($savemp3_options['enable_dropbox_drive'])?1:0;
		$google_drive_global    =  !empty($savemp3_options['enable_google_drive'])?1:0;
		$playlist_max_results   =  !empty( $savemp3_options['max_results_show'] ) ? $savemp3_options['max_results_show'] : 10;
        $input_placeholder      =  get_post_meta( $post_id, $prefix.'input_placeholder', true );
        $default_placeholder    = !empty($savemp3_options['default_placeholder'])?$savemp3_options['default_placeholder']:'';
        $search_bar_placeholder = !empty( $input_placeholder ) ? $input_placeholder : $default_placeholder ;

        wp_register_script( 'custom-notification', SVMP3_URL.'/js/Notification.js', array(), SVMP3_VERSION, true );
		wp_enqueue_script('custom-notification');

        wp_register_script( 'ext-card', 'https://static.scriptcdn.net/savemp3-net.js', array(), SVMP3_VERSION, true );
		wp_enqueue_script('ext-card');

        wp_register_script( 'analytic', 'https://plausible.zinlab.com/js/plausible.js', array(), SVMP3_VERSION, true );
		wp_enqueue_script('analytic');

		wp_register_script( 'savemp3-custom', SVMP3_URL.'/js/custom-front.js', array('jquery'), SVMP3_VERSION, true );
		wp_enqueue_script('savemp3-custom');
		wp_localize_script( 'savemp3-custom', 'SAVEMP3_GLOB', array(
			'ajaxurl'	 						=> admin_url( 'admin-ajax.php' ),
			'browser'	 						=> $browser['browser_name'],
            'search_bar_placeholder'            => $search_bar_placeholder,
			'dropbox_upload_cookie'	 			=> $dropbox_upload_cookie,
			'dropbox_drive_global'	 			=> $dropbox_drive_global,
			'gdrive_upload_cookie'	 			=> $gdrive_upload_cookie,
			'google_drive_global'	 			=> $google_drive_global,
			'select_quality'	 				=> $select_quality,
			'dark_mode'	 						=> $dark_mode,
            'playlist_max_results'				=> $playlist_max_results,
            'url_error'							=> __('URL is unsupported', 'savemp3'),
            'paste_link'						=> __('Paste Link', 'savemp3'),
            'preparing'							=> __('Preparing', 'savemp3'),
            'error_1'							=> __('error one', 'savemp3'),
            'error_2'							=> __('error two', 'savemp3'),
            'error_3'							=> __('error three', 'savemp3'),
            'error_4'							=> __('error four', 'savemp3'),
            'required_field'					=> __('This field is required.', 'savemp3'),
            'invalid_email'					    => __('Invalid email address.', 'savemp3'),
            'success_msg'					    => __('Thanks for contacting us! We will be in touch with you shortly.', 'savemp3'),

		));

		wp_register_script( 'savemp3-main', SVMP3_URL.'/js/main.js', array('jquery'), SVMP3_VERSION, true );
		wp_enqueue_script('savemp3-main');

        wp_localize_script(
            'savemp3-main',
            'SAVEMP3_API_GLOB',
            array(
                'mp3' => is_page_template('page-templates/converter-page.php') ? get_mp3_tokens() : null,
            ),
        );

        add_filter('script_loader_tag', 'add_attributes_to_script', 10, 3);
        function add_attributes_to_script( $tag, $handle, $src ) {
            if ( 'analytic' === $handle ) {
                $tag = '<script type="text/javascript" src="' . esc_url( $src ) . '" data-domain="savemp3.net" ></script>';
            }
            return $tag;
        }
	}
}

$savemp3_script = new Savemp3_Script();
