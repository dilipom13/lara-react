<?php
/**
 * 'savemp3_faq_display' Shortcode
 *
 * @package Savemp3
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
/**
 * Function to handle the `savemp3_faq_display` shortcode
 * 
 * @package Savemp3
 * @since 1.0
 */
function savemp3_faq_display( $atts, $content = null ) {

  extract(shortcode_atts(array(
    "id"                 => '',  
  ), $atts, 'savemp3_faq_display'));
  

  $id      = !empty($id) ? $id : 0;
  ob_start(); 

  $id = apply_filters( 'wpml_object_id', $id , 'post' );

  $prefix = SVMP3_META_PREFIX; // Metabox prefix
  $faq_control = get_post_meta( $id, $prefix.'faq_control', true );

  if( !empty( $id ) && !empty( $faq_control ) ){ ?>
    <div class="faqs" itemscope="itemscope" itemtype="https://schema.org/FAQPage">
     <?php foreach ($faq_control as $v_key => $v_data) { 
            $faq      = !empty($v_data['faq'])?$v_data['faq']:''; 
            $faq_ans    = !empty($v_data['faq_ans'])?$v_data['faq_ans']:''; ?>

            <div class="faq" itemscope="itemscope" itemprop="mainEntity" itemtype="https://schema.org/Question">
              <div class="faq--question">
                  <h3 itemprop="name">
                      <?php echo $faq; ?>
                  </h3>
              </div>
              <div class="faq--answer" itemscope="itemscope" itemprop="acceptedAnswer"
                  itemtype="https://schema.org/Answer">
                  <div class="faq--body" itemprop="text">
                     <?php echo $faq_ans; ?>
                  </div>
              </div>
          </div>
  <?php } ?>
</div>
<?php }  ?>
 <?php  $content .= ob_get_clean();
  return $content;
}

/* savemp3_faq_display' Shortcode */
add_shortcode('savemp3_faq_display', 'savemp3_faq_display');
