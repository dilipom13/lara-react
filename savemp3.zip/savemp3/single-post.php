<?php
/**
 * The template for displaying all single post
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Savemp3
 * @since 1.0
 *
 */


get_header();

global $post;
$prefix                 = SVMP3_META_PREFIX; // Metabox prefix
?>
<main>
    <div class="container">
        <h1 class="page--title"><?php echo get_the_title(); ?></h1>
        <article>
            <?php the_content(); ?>
        </article>
    </div>
</main>
<?php get_footer();
