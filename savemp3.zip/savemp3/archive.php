<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Savemp3
 * @since 1.0
 */

get_header(); ?>
<?php get_search_form(); ?>
<div class="block_addons_go search_addons">
	<div class="container">
		<div class="row">
			<div class="in_to_adons_g">
				<div class="row_item_addong">
				<?php if ( have_posts() ) { ?>
				<?php				
				/* Start the Loop */
				while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'template-parts/addon', 'design' ); ?>
				<?php 	endwhile; 
				}else { ?>
					<h1 style="color: #FFF;text-align: center;">Record Not found</h1>
				<?php } ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
get_footer();