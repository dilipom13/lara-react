<?php

/**
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Savemp3
 * @since 1.0
 */
// Defining Some Variable
if( !defined( 'SVMP3_VERSION' ) ) {
	define('SVMP3_VERSION', '1.1.10'); // Theme Version
}
if( !defined( 'SVMP3_DIR' ) ) {
	define( 'SVMP3_DIR', get_template_directory() ); // Theme dir
}
if( !defined( 'SVMP3_URL' ) ) {
	define( 'SVMP3_URL', get_template_directory_uri() ); // Theme url
}
if( !defined( 'SVMP3_VERSION' ) ) {
    define( 'SVMP3_VERSION', '1.0' ); // inc dir
}

if( !defined( 'SVMP3_FAQ_POST_TYPE' ) ) {
    define( 'SVMP3_FAQ_POST_TYPE', 'svmp3_faq' ); // inc dir
}

if( !defined( 'SVMP3_DEFAULT_POST_TYPE' ) ) {
    define( 'SVMP3_DEFAULT_POST_TYPE', 'post' ); // inc dir
}

if( !defined( 'SVMP3_PAGE_POST_TYPE' ) ) {
    define( 'SVMP3_PAGE_POST_TYPE', 'page' ); // inc dir
}

if( !defined( 'SVMP3_META_PREFIX' ) ) {
    define( 'SVMP3_META_PREFIX', '_svmp3_' ); // inc dir
}

if( !defined( 'SVMP3_CONTACT_POST_TYPE' ) ) {
    define( 'SVMP3_CONTACT_POST_TYPE', 'svmp3_contact' ); // inc dir
}

if( !defined( 'SVMP3_WEBSITE_POST_TYPE' ) ) {
    define( 'SVMP3_WEBSITE_POST_TYPE', 'website' ); // inc dir
}

if( !defined( 'SVMP3_WEBSITE_CAT' ) ) {
    define( 'SVMP3_WEBSITE_CAT', 'website-category' ); // Plugin category name
}
if( !defined( 'SVMP3_WEBSITE_TAG' ) ) {
    define( 'SVMP3_WEBSITE_TAG', 'website-tag' ); // Plugin category name
}

define('ICL_DONT_LOAD_NAVIGATION_CSS', true);
define('ICL_DONT_LOAD_LANGUAGE_SELECTOR_CSS', true);
define('ICL_DONT_LOAD_LANGUAGE_JS', true);

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function savemp3_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Savemp3, use a find and replace
	 * to change 'savemp3' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'savemp3');


	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	add_theme_support( 'widgets' );

        // This theme styles the visual editor with editor-style.css to match the theme style.
	add_editor_style();

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1400, 500, true );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'main-menu' 		=> esc_html__( 'Main Menu', 'savemp3' ),
		'mobile-menu' 		=> esc_html__( 'Mobile Menu', 'savemp3' ),
		'footer-menu' 		=> esc_html__( 'Footer Menu', 'savemp3' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );


	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );


	// Add support for custom logo.
	add_theme_support( 'custom-logo' );

	// Post format.
	add_theme_support( 'post-formats', array('video', 'audio', 'quote', 'gallery'));

	// WordPress 5.0 and Gutenberg support
	// Add support for Block Styles.
	add_theme_support( 'wp-block-styles' );

	// Add support for full and wide align images.
	add_theme_support( 'align-wide' );


}
add_action( 'after_setup_theme', 'savemp3_setup' );

require_once SVMP3_DIR . '/includes/init.php';


function savemp3_menu_classes($classes, $item, $args) {
  if($args->theme_location == 'main-menu' || $args->theme_location =='footer-menu') {
    $classes[] = 'menu--item';
  } else if($args->theme_location == 'mobile-menu') {
    $classes[] = 'mobile--menu-item';
  }
  return $classes;
}
add_filter('nav_menu_css_class', 'savemp3_menu_classes', 1, 3);

add_filter( 'body_class','savemp3_body_classes' );
function savemp3_body_classes( $classes ) {

	$dark_mode  =  !empty( $_COOKIE['dark_mode'] )?$_COOKIE['dark_mode']:'on';

 	if( is_page_template('page-templates/landing-page.php') ){
    	$classes[] = 'landing';
    }

    if(  $dark_mode == 'on' ){
    	$classes[] = 'dark-theme';
    }



    return $classes;
}

function allow_numeric_slug( $slug, $post_ID, $post_status, $post_type, $post_parent, $original_slug ) {
	global $wpdb;

	if ( 'page' !== $post_type || ! is_numeric( $original_slug ) || $slug === $original_slug ) {
		return $slug;
	}

	$post_name_check = $wpdb->get_var(
		$wpdb->prepare(
			"SELECT post_name FROM $wpdb->posts WHERE post_name = %s AND post_type IN ( %s, 'attachment' ) AND ID != %d AND post_parent = %d LIMIT 1",
			$original_slug,
			$post_type,
			$post_ID,
			$post_parent,
		),
	);

	return $post_name_check ? $slug : $original_slug;
}

add_filter( 'wp_unique_post_slug', 'allow_numeric_slug', 9999, 6 );

//manually redirect old to new slug
function old_slug_redirect() {
    wp_old_slug_redirect();
}

add_action( 'wp', 'old_slug_redirect' );
