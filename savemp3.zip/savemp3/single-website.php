<?php
/**
 * The template for displaying all single svmp3_website
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Savemp3
 * @since 1.0
 * 
 */


get_header(); 

global $post,$savemp3_options;

global $post,$savemp3_options,$browser;

$prefix                 = SVMP3_META_PREFIX; // Metabox prefix
$input_placeholder      = get_post_meta( $post->ID, $prefix.'input_placeholder', true );
$download_video_url     = get_post_meta( $post->ID, $prefix.'download_video_url', true );
$show_extensions_card   = get_post_meta( $post->ID, $prefix.'show_extensions_card', true );
$how_to_use_title       = get_post_meta( $post->ID, $prefix.'how_to_use_title', true );
$related_articles       = get_post_meta( $post->ID, $prefix.'related_articles', true );
$card_title             = !empty( $savemp3_options['card_title'] )?$savemp3_options['card_title'] : '';
$card_description       = !empty( $savemp3_options['card_description'] )?$savemp3_options['card_description'] : '';
$card_image             = !empty( $savemp3_options['card_image'] )?$savemp3_options['card_image'] : '';
$icon_scr               = !empty($card_image['icon_scr'])?$card_image['icon_scr']:'';
$icon_id                = !empty($card_image['icon_id'])?$card_image['icon_id']:'';



$default_placeholder    = !empty( $savemp3_options['default_placeholder'] )?$savemp3_options['default_placeholder']:'';
$input_placeholder      = !empty( $input_placeholder )?$input_placeholder:$default_placeholder;

include SVMP3_DIR . '/template-parts/hero.php'; 
include SVMP3_DIR . '/template-parts/extension.php'; 
include SVMP3_DIR . '/template-parts/supported-sites.php'; 
include SVMP3_DIR . '/template-parts/how-to-use.php'; 
include SVMP3_DIR . '/template-parts/related-articles.php';

get_footer(); 