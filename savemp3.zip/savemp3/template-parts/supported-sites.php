<section class="supported-sites section">
    <div class="container">

        <?php 

       

        ?>

       


        <h2 class="section--title">
            <?php 

           echo sprintf(
                '%s <span class="underline">%s</span>',
                esc_html__( 'Supported', 'savemp3' ),
                esc_html__( 'sites', 'savemp3' )
            )


            ?>

         </h2>
        
        <div class="sites" id="supported-sites">

            <?php

             $current_language       = apply_filters( 'wpml_current_language', NULL );
                


            $supported_site = !empty($savemp3_options['supported-site'])?$savemp3_options['supported-site']:'';
            foreach ($supported_site as $key => $value) {

                        $class  = !empty($value['class'])?$value['class']:'';
                        $name   = !empty($value['name'])?$value['name']:'';
                        $link   = !empty($value['link'])?$value['link']:'';
                        $link   = (int)$link;

                        $link    = apply_filters( 'wpml_object_id', $link, 'page', true, $current_language );


            ?>

            <a href="<?php echo get_permalink( $link ); ?>" class="site">
                <i class="icon">
                    <svg>
                        <use xlink:href="#<?php echo $class; ?>"></use>
                    </svg>
                </i>

                <h4 class="site--title"><?php echo $name; ?></h4>
            </a>
            <?php } ?>

        </div>

        <button id="supported-sites-cta" class="sites--cta"><?php _e('View all sites', 'savemp3'); ?></button>
    </div>
</section>
