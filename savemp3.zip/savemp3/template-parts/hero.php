<section class="hero">
	<audio id="audio"></audio>

	<div class="container--large">
		<?php include SVMP3_DIR . '/template-parts/alerts.php'; ?>

		<h1 class="hero--title">
			<?php echo  get_the_title(); ?>
		</h1>

		<div class="hero--form">
			<div id="search-bar-app"></div>
		</div>
	</div>
</section>
