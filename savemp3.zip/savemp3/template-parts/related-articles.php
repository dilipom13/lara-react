<?php if( !empty( $related_articles ) ) { ?>
<section class="section">
    <div class="container">
        <h2 class="section--title"><?php _e('Try these SaveMP3 online tools', 'savemp3'); ?></h2>
        <div class="page--links">
            <?php foreach ( $related_articles as $key => $pid ) { 

                $current_language       = apply_filters( 'wpml_current_language', NULL );
                $pid                    = apply_filters( 'wpml_object_id', $pid, 'page', true, $current_language );


            ?>
            <a href="<?php echo get_the_permalink( $pid ); ?>" class="page--link"><?php echo wp_strip_all_tags( get_the_title( $pid ) ); ?></a>
            <?php }  ?>
        </div>
    </div>
</section>
<?php } 