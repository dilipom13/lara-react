<?php
/**
 * Alerts template to display notifications on pages
 *
 * Variants     'info' | 'warning' | 'success'
 *
 * @package      Savemp3
 * @since        1.0.1
 */

    $alert_active   =   true;
    $closeable      =   true;
    $variant        =   'info';
    $message        =   'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fuga, veritatis laborum aperiam quia harum blanditiis, quos itaque a praesentium consequuntur asperiores sed molestias. Optio!';

    if( $alert_active ) { ?>
        <div class="alert <?php echo $variant; ?>">
            <?php if( $closeable ) { ?>
                <button class="alert--close">
                    <i class="icon">
                        <svg><use xlink:href="#icon-close"></use></svg>
                    </i>
                </button>
            <?php } ?>

            <i class="icon alert--icon">
                <svg>
                    <use xlink:href="#icon-alert-<?php echo $variant; ?>"></use>
                </svg>
            </i>

            <div class="alert--content">
                <p><?php echo $message; ?></p>
            </div>
        </div>
    <?php }
?>
