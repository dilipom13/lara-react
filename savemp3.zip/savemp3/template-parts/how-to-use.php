<section class="section">
    <div class="container">
        <article>
            <?php the_content(); ?>
        </article>
    </div>
</section>
