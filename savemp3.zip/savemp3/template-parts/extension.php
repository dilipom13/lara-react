<?php if( !empty($show_extensions_card) ){ ?>
<section class="section" id="extension">
	<div class="container">
		<div class="extensions">
			<div class="extensions--details">
				<?php
				echo $card_title;
				echo $card_description;
				?>
				<div class="extensions--cta">
					<div class="download">
						<button class="btn--primary download--init">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-<?php echo strtolower($browser['browser_name']); ?>"></use>
								</svg>
							</i>
							<span class="text"><?php _e("Add to", 'savemp3'); ?> <?php echo strtolower($browser['browser_name']); ?></span>
						</button>

						<?php if( $browser['browser_name'] == 'Chrome' || $browser['browser_name'] == 'Edge' || $browser['browser_name'] == 'Yandex Browser' || $browser['browser_name'] == 'UC Browser') { ?>
							<div class="dd--popup download--dropdown" id="main-download">
								<button class="dd--popup-close download--close"></button>
								<div class="dd--details">
									<div class="dd--icon">
										<img src="<?php echo SVMP3_URL; ?>/images/icon-crosspilot.png" alt="dd--icon">
									</div>

									<p class="dd--desc"> <b><?php _e('Crosspilot', 'savemp3'); ?></b> <?php _e('extension is needed to make YouTube Video
										Downloader work properly.', 'savemp3'); ?></p>
								</div>
								<div class="dd--actions">
									<a href="https://chrome.google.com/webstore/detail/crosspilot/migomhggnppjdijnfkiimcpjgnhmnale"
										target="_blank" class="btn--primary">
										<i class="icon"><img src="<?php echo SVMP3_URL; ?>/images/icon-webstore.png" alt="webstore"></i>
										<span><?php _e("Let's Go", 'savemp3'); ?></span>
									</a>

									<a class="link-text" data-fancybox=""
										href="https://www.youtube.com/watch?v=ol1bVODJm2g">
										<?php _e("Watch video", 'savemp3'); ?>
									</a>
								</div>
							</div>
						<?php } ?>

						<?php if( $browser['browser_name'] == 'Opera' ) { ?>

							<div class="dd--popup download--dropdown" id="main-download">
								<button class="dd--popup-close download--close"></button>

								<div class="dd--details">
									<div class="dd--icon">
										<img src="https://cdn-icons-png.flaticon.com/512/2476/2476231.png" alt="dd--icon">
									</div>

									<p class="dd--desc"><?php _e("It will show you a notification in the header. Upon clicking, It will take you to your Opera browser's extensions page. From there, click Install.", 'savemp3'); ?></p>
								</div>

								<div class="dd--actions">
									<a data-browser="Opera" href="javascript:void(0)" data-addon-id="44" class="ac-download-available download_counter btn-primary_green" rel="noopener noreferrer">
											<i class="icon"><img src="http://localhost/wordpress/wp-content/themes/addoncrop-theme/assets/images/icon-webstore.png" alt="webstore"></i>
											<span><?php _e('Download', 'savemp3'); ?></span>
									</a>

									<a class="link-text" data-fancybox="" href="https://www.youtube.com/watch?v=ol1bVODJm2g">
										<?php _e('Watch video', 'savemp3'); ?>
									</a>
								</div>
							</div>
						<?php } ?>

						<?php if( $browser['browser_name'] == 'Firefox' ) { ?>
							<div class="dd--popup download--dropdown" id="main-download">
								<button class="dd--popup-close download--close"></button>
								<div class="dd--details">
									<div class="dd--icon">
										<img src="http://localhost/wordpress/wp-content/uploads/2021/12/icon-tempermonkey.png" alt="dd--icon">
									</div>

									<p class="dd--desc">
										<?php _e('Please, install', 'savemp3'); ?> <a target="_blank" href="https://chrome.google.com/webstore/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo?hl=en" rel="noopener"><?php _e('Tampermonkey', 'savemp3'); ?></a>
										<?php _e('extension To add YouTube Video Downloader to Chrome properly.', 'savemp3'); ?>
									</p>
								</div>

								<div class="dd--steps">
									<a class="dd--step" target="_blank" href="https://chrome.google.com/webstore/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo?hl=en" rel="noopener">
										<label for=""><?php _e('Step 1', 'savemp3'); ?></label>
										<span><?php _e('Install', 'savemp3'); ?> <b><?php _e('Tampermonkey', 'savemp3'); ?></b></span>
									</a>
									<a href="https://userscript.s3.amazonaws.com/youtube-downloader/youtube-downloader.user.js" data-addon-id="42" data-extension-id="44" class="download_counter ac_us_dow_get dd--step onclick-loader">
										<label for=""><?php _e('Step 2', 'savemp3'); ?></label>
										<span><?php _e('Install', 'savemp3'); ?> <strong><?php _e('Userscript', 'savemp3'); ?></strong></span>
										<div class="loader">
											<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19 17">
												<circle class="loadingCircle" cx="2.2" cy="10" r="1.6"></circle>
												<circle class="loadingCircle" cx="9.5" cy="10" r="1.6"></circle>
												<circle class="loadingCircle" cx="16.8" cy="10" r="1.6"></circle>
											</svg>
										</div>
									</a>

								</div>

								<div class="dd--actions">
									<a class="link-text" data-fancybox="" href="https://www.youtube.com/watch?v=ol1bVODJm2g">
										<?php _e('Watch video', 'savemp3'); ?>
									</a>
								</div>
							</div>
						<?php } ?>
					</div>

					<?php if( strtolower($browser['browser_name'])!='chrome' ){ ?>
						<button class="btn--icon">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-chrome"></use>
								</svg>
							</i>
						</button>
					<?php } ?>

					<?php if( strtolower($browser['browser_name'])!='firefox' ){ ?>

					<button class="btn--icon">
						<i class="icon">
							<svg>
								<use xlink:href="#icon-firefox"></use>
							</svg>
						</i>
					</button>

					<?php } ?>
					<?php if( strtolower($browser['browser_name'])!='edge' ){ ?>
						<button class="btn--icon">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-edge"></use>
								</svg>
							</i>
						</button>
					<?php } ?>
				</div>
			</div>

			<div class="extensions--img">
				<?php if( !empty( $icon_scr ) ) { ?>
				<img src="<?php echo $icon_scr; ?>" alt="img">
				<?php } ?>
			</div>
		</div>
	</div>
</section>
<?php } ?>
