<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Savemp3
 * @since 1.0
 */

get_header(); ?>
<main>
    <div class="container">
        <section class="nrf">
            <h1 class="page--title"> <?php _e('404', 'savemp3'); ?></h1>

            <h3 class="page--subtitle">
                <?php _e("We couldn't find the page you are looking for", 'savemp3'); ?>
            </h3>

            <div class="nrf--cta">
                <a href="<?php echo site_url(); ?>" class="btn--default">
                    <?php _e('Go to home page', 'savemp3'); ?>
                </a>

                <span class="spacer">or</span>

                <a href="<?php echo get_permalink( get_page_by_path( 'contact' ) ); ?>" class="text--link">
                    <?php _e('Contact us', 'savemp3'); ?>
                </a>
            </div>

            <div class="nrf--links">
                <h3 class="page--subtitle">
                    <?php _e('May be you are looking for', 'savemp3'); ?>
                </h3>

                <div class="nrf--cta">
                    <a href="https://addoncrop.com/free-youtube-mp3-converter/" target="_blank" class="btn--primary">
                        <img src="https://i1.wp.com/addoncrop.com/wp-content/uploads/2021/03/icon-128.png" alt="YouTube Mp3 Converter">

                        <span class="text">
                            <?php _e('YouTube Mp3 Converter Chrome Extension', 'savemp3'); ?>
                        </span>
                    </a>
                </div>
            </div>
        </section>
    </div>
</main>
<?php
get_footer();
