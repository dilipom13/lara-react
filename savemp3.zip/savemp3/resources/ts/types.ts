
export type Extractor = 'Youtube' | 'Facebook' | 'Instagram' | 'Twitter' | 'Dailymotion' | 'Vimeo' | 'VK' | 'SoundCloud' | 'Tiktok';

export type APITask = {
    bitrate: number;
    filesize: string;
    hash: string;
};

export type TrackResponse = {
    error?: false;
    videoId: string;
    title: string;
    lengthSeconds: string;
    extractor: Extractor;
    tasks: APITask[];
} | {
    error: true;
    code: string;
    errorMsg: string;
    message: string;
};

export type TaskResponse = {
    taskId: number;
    status: 'queued' | 'finished' | 'failed';
    download_progress: number;
    convert_progress: number;
    title: string;
    ext: 'mp3' | 'mp4' | 'webm';
    download?: string;
};

export interface Track {
    id: string;
    title: string;
    trackUrl: string;
    thumbnailUrl: string | null;
    duration: string | null;
    durationSec: number;
    extractor: Extractor;
    tasks: APITask[];
    loading?: boolean;
    requestInProgress?: boolean;
    requestProgress?: number;
}

export interface SearchState {
    loading: boolean;
    error: string | null;
    track: Track | null;
    player: {
        id: string;
        track?: Track;
        state: 'playing' | 'paused';
    } | null;
}
