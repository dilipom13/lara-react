
import 'filepond/dist/filepond.min.css';
import '../sass/style.scss';

import { createApp } from 'vue';

import './icons';
import './modules/faqs';
import './modules/darkmode-toggle';
import './modules/extension-download';
import './modules/fancybox';
import './modules/header';
import './modules/quality-select';
import './modules/supported-sites';
import './modules/alert';
import './modules/article';
import './modules/file-pond';

import select from './components/select';
import burgerMenu from './components/burger-menu';

import SearchBar from './components/SearchBar/SearchBar.vue';
import Notification from './components/ui/Notification';
import popup from './components/popup';
import tabs from './components/tabs';

(() => {
    const rootContainer = document.getElementById('search-bar-app');

    if (rootContainer) {
        createApp(SearchBar)
            .use(Notification)
            .mount(rootContainer);
    }

    select.init('custom-select');
    popup.init('languages');
    popup.init('popup');

    tabs({
        tabClass: 'im--tab',
        contentClass: 'im--content',
        activeClass: 'is-active',
    });

    // Burger menu for mobile screens
    burgerMenu({
        container: 'burger-menu',
        active: 'open-menu',
        onClose: () => {
            document.body.classList.remove('active-mobile-menu');
        },
        onOpen: () => {
            document.body.classList.add('active-mobile-menu');
        },
    });

    // const supportedSites = document.getElementById('supported-sites');
    // const supportedSitesCta = document.getElementById('supported-sites-cta');
    // if (!supportedSites || !supportedSitesCta) { return; }

    // supportedSitesCta.addEventListener('click', (e) => {
    //     e.preventDefault();
    //     const initialHeight = '230px';
    //     const height = supportedSites.scrollHeight;
    //     if (supportedSites.classList.contains('open')) {
    //         supportedSites.classList.remove('open');
    //         supportedSites.style.maxHeight = initialHeight;
    //     } else {
    //         supportedSites.classList.add('open');
    //         supportedSites.style.maxHeight = `${height}px`;
    //     }
    // });
})();
