
declare global {
    const SAVEMP3_GLOB: {
        search_bar_placeholder: string;
        google_drive_global: '1' | '0';
        dropbox_drive_global: '1' | '0';
        playlist_max_results: string;
        dark_mode: 'on' | 'off';
    };

    const SAVEMP3_API_GLOB: {
        mp3: {
            [key in 'api' | 'youtube_api']: {
                url: string;
                public_key: string;
                timestamp: number;
                token: string;
            }
        }
    };
}

export { };
