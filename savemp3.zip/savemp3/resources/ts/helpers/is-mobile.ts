
export default () => /Mobi|Android/i.test(navigator.userAgent);
