
export default (length: number, full = false): string => {
    const hours = Math.floor(length / 3600);
    const minutes = Math.floor((length % 3600) / 60);
    const seconds = Math.round(length - (hours * 3600) - (minutes * 60));

    let result = '';

    if (hours > 0 || full) {
        result = `${(hours < 10 ? `0${hours}` : hours)}:`;
    }

    result += `${(minutes < 10 ? `0${minutes}` : minutes)}`;
    result += `:${(seconds < 10 ? `0${seconds}` : seconds)}`;

    return result;
};
