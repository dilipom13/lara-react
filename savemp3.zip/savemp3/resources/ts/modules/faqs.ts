
(() => {
    const faqs = <HTMLElement>document.querySelector('.faqs');
    if (!faqs) { return; }

    document.addEventListener('click', (e) => {
        const traget = <HTMLElement>e.target;

        if (traget.closest('.faq--question')) {
            const faqList: NodeListOf<HTMLElement> = document.querySelectorAll('.faq');
            const parent = <HTMLElement>traget.closest('.faq');
            if (!parent) { return; }

            const ans = <HTMLElement>parent.querySelector('.faq--answer');
            if (!ans) { return; }

            const height = ans.scrollHeight;

            if (parent.classList.contains('is-active')) {
                faqList.forEach((f) => f.classList.remove('is-active'));
                ans.style.maxHeight = '0px';
            } else {
                faqList.forEach((f) => {
                    if (f === parent) { return; }
                    f.classList.remove('is-active');
                    const relatedAns = <HTMLElement>f.querySelector('.faq--answer');
                    relatedAns.style.maxHeight = '0px';
                });

                parent.classList.add('is-active');
                ans.style.maxHeight = `${height}px`;
            }
        }
    });
})();
