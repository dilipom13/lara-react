import * as FilePond from 'filepond';

const inputElement = document.querySelector('input[type="file"]');

// Create a FilePond instance
if (inputElement) {
    FilePond.create(inputElement, {
        credits: false,
    });
}
