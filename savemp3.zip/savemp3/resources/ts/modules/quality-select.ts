
// eslint-disable-next-line func-names
$('select[data-menu]').each(function () {
    const select = $(this);
    const type = select.data('menu');
    const menu = $('<div />').addClass(`select-menu ${type}`);
    const button = $('<button />');
    const buttonDiv = $('<div />');
    $('<span />').text(select.find('option:selected').text()).appendTo(buttonDiv);
    $('<em />').prependTo(button);

    button.css({
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        '--h': select.outerHeight(),
        '--w': select.outerWidth(),
    });

    select.wrap(menu);
    button.append(buttonDiv).insertAfter(select);
});

// eslint-disable-next-line func-names
$(document).on('click', '.select-menu', function () {
    const menu = $(this);
    const select = menu.children('select');
    const options = select.find('option');
    const active = select.find('option:selected');
    const button = menu.children('button');
    const buttonDiv = button.children('div');
    const current = buttonDiv.children('span');

    if (!menu.hasClass('change')) {
        const nextOption = options.eq(active.index() === options.length - 1
            ? 0
            : active.index() + 1);
        const next = $('<span />').addClass('next').text(nextOption.text()).appendTo(buttonDiv);

        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        options.attr('selected', false);
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        nextOption.attr('selected', true);

        menu.addClass('change');

        setTimeout(() => {
            next.removeClass('next');
            menu.removeClass('change');
            current.remove();
        }, 650);
    }
});
