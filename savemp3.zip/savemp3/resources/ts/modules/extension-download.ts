
import createExtensionDownloadPopupMobile from '../components/create-extension-download-popup-mobile';
import isMobile from '../helpers/is-mobile';

document.addEventListener('click', (e) => {
    const target = <HTMLElement>e.target;
    const x = e.clientX;
    const y = e.clientY;
    const clientWidth = window.innerWidth;
    const clientHeight = window.innerHeight;
    const diffx = clientWidth - x;
    const diffy = clientHeight - y;

    if (target.classList.contains('download--init') || target.closest('.download--init')) {
        const btn = <HTMLElement>target.closest('.download--init');
        const doNothing = btn.classList.contains('installed');
        if (doNothing) { return; }

        if (isMobile()) {
            const alreadyThere = document.querySelector('.dd--mobile') !== null;

            if (alreadyThere) {
                document.querySelectorAll('.dd--mobile').forEach((d) => {
                    d.classList.remove('is-active');
                    setTimeout(() => { d.remove(); }, 250);
                });
                return;
            }

            const mobilePopup = createExtensionDownloadPopupMobile();
            document.body.appendChild(mobilePopup);

            setTimeout(() => { mobilePopup.classList.add('is-active'); }, 100);

            document.addEventListener('click', (ev) => {
                const t = ev.target as HTMLElement;

                if (t.closest('.download--close')) {
                    mobilePopup?.classList.remove('is-active');
                    setTimeout(() => { mobilePopup.remove(); }, 250);
                }
            });
            return;
        }

        const parent = <HTMLElement>target.closest('.download');

        if (!parent) { return; }

        if (parent.classList.contains('is-active')) {
            document.querySelectorAll('.download').forEach((d) => {
                d.classList.remove('is-active');
                d.classList.remove('align-right');
                d.classList.remove('align-top');
            });
        } else {
            document.querySelectorAll('.download').forEach((d) => {
                if (d === parent) return;
                d.classList.remove('is-active');
                d.classList.remove('align-right');
                d.classList.remove('align-top');
            });

            if (diffx <= 150) {
                parent.classList.add('align-right');
            }

            if (diffy <= 250) {
                parent.classList.add('align-top');
            }

            parent.classList.add('is-active');
        }
    } else if (target.classList.contains('download--close') || target.closest('.download--close')) {
        document.querySelectorAll('.download').forEach((d) => {
            d.classList.remove('is-active');
            d.classList.remove('align-right');
            d.classList.remove('align-top');
        });
    }
});
