
(() => {
    const settings = document.querySelector('.settings');
    if (!settings) { return; }

    function openSettingsMenu() {
        settings?.classList.add('is-active');
        const settingsInit = settings?.querySelector('.settings--init');

        if (settingsInit) {
            settingsInit.querySelector('use')?.setAttribute('xlink:href', '#icon-close');
            settingsInit.classList.add('cross');
        }

        setTimeout(() => { settings?.classList.add('show'); }, 50);
    }

    function closeSettingsMenu() {
        settings?.classList.remove('show');
        setTimeout(() => { settings?.classList.remove('is-active'); }, 250);

        const settingsInit = settings?.querySelector('.settings--init');

        if (settingsInit) {
            settingsInit.querySelector('use')?.setAttribute('xlink:href', '#icon-settings');
            settingsInit.classList.remove('cross');
        }
    }

    document.addEventListener('click', (e) => {
        const target = e.target as HTMLElement;

        if (target.closest('.settings--init')) {
            const parent = target.closest('.settings');
            if (!parent) { return; }

            if (parent.classList.contains('is-active')) {
                closeSettingsMenu();
            } else {
                openSettingsMenu();
            }
        } else if (target.closest('.settings') === null) {
            closeSettingsMenu();
        }
    });
})();
