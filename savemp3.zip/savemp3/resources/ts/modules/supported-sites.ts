(() => {
    const MAX_HEIGHT = 300;
    const supportedSites = <HTMLElement>document.getElementById('supported-sites');
    const supportedSitesCta = document.getElementById('supported-sites-cta');
    if (!supportedSites || !supportedSitesCta) return;

    const supportedSitesHeight = supportedSites.scrollHeight;
    if (supportedSitesHeight <= MAX_HEIGHT) return;

    supportedSitesCta.classList.add('active');
    supportedSites.classList.add('collapsed');

    supportedSitesCta.addEventListener('click', (e) => {
        e.preventDefault();
        // const height = supportedSites.scrollHeight;
        if (supportedSites.classList.contains('open')) {
            supportedSites.classList.remove('open');
            supportedSites.style.maxHeight = `${MAX_HEIGHT}px`;
        } else {
            supportedSites.classList.add('open');
            supportedSites.style.maxHeight = `${supportedSitesHeight + 20}px`;
        }
    });
})();
