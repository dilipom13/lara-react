
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { Fancybox } from '@fancyapps/ui';
import '@fancyapps/ui/dist/fancybox.css';

Fancybox.bind('[data-fancybox]', {
    // Your options go here
});
