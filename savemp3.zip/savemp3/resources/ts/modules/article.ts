
function showArticle(els: NodeListOf<HTMLElement>) {
    els.forEach((el) => el.classList.add('active'));
    localStorage.removeItem('hideArticle');
}

function hideArticle(els: NodeListOf<HTMLElement>) {
    els.forEach((el) => el.classList.remove('active'));
    localStorage.setItem('hideArticle', 'true');
}

(() => {
    const isArticleHidden: string | null = localStorage.getItem('hideArticle');

    const sectionsToBeHidden: NodeListOf<HTMLElement> = document.querySelectorAll('.section--hidden');
    const articleCheckBox = <HTMLInputElement>document.getElementById('article-switch');

    if (isArticleHidden) {
        articleCheckBox.checked = true;
    }

    if (articleCheckBox.checked) {
        hideArticle(sectionsToBeHidden);
    } else {
        showArticle(sectionsToBeHidden);
    }

    articleCheckBox.addEventListener('change', (e: Event) => {
        const target = e.target as HTMLInputElement;

        if (sectionsToBeHidden.length > 0) {
            if (target.checked) {
                hideArticle(sectionsToBeHidden);
            } else {
                showArticle(sectionsToBeHidden);
            }
        }
    });
})();
