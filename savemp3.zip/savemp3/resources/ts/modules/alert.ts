
document.body.addEventListener('click', (e) => {
    const target = e.target as HTMLElement;

    if (target.closest('.alert--close')) {
        const parent = target.closest('.alert');
        if (!parent) return;
        parent.remove();
    }
});
