
(() => {
    interface Options {
        darkTheme?: boolean
    }

    let options: Options = {};

    const setData = (key: string, value: object) => {
        localStorage.setItem(key, JSON.stringify(value));
    };

    const getData = (key: string) => {
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        const data = JSON.parse(localStorage.getItem(key)!);
        return data;
    };

    const IS_DARKMODE_ON = SAVEMP3_GLOB.dark_mode === 'on';
    if (IS_DARKMODE_ON) setData('options', { darkTheme: true });

    const themeToggleInput = <HTMLInputElement>document.querySelector('#darkMode-init');

    options = getData('options');

    if (options) {
        if (options.darkTheme) {
            document.body.classList.add('dark-theme');

            if (!themeToggleInput) { return; }
            themeToggleInput.checked = true;
        }
    }

    if (themeToggleInput) {
        if (themeToggleInput.checked) {
            document.body.classList.add('dark-theme');
        }

        themeToggleInput.addEventListener('change', () => {
            if (themeToggleInput.checked) {
                document.body.classList.add('dark-theme');
                options = {
                    darkTheme: true,
                };

                setData('options', options);
            } else {
                document.body.classList.remove('dark-theme');

                options = {
                    darkTheme: false,
                };

                setData('options', options);
            }
        });
    }
})();
