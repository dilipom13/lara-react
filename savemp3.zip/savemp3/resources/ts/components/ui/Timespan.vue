
<template>
    <div
        class="timespan-input"
        :class="{ 'is-focused': inFocus, 'is-disabled': disabled }"
        @click.self="setFocus"
    >
        <span
            ref="hoursTickerEl"
            :tabindex="!disabled && time.hours.editable ? '-1' : undefined"
            class="timespan-input__ticker"
            :class="{
                'is-focused': time.hours.inEditMode,
                'is-disabled': !time.hours.editable,
            }"
            :min="time.hours.min"
            :max="time.hours.max"
            @focus="onFocus('hours')"
            @blur="onBlur('hours');"
            @keydown.right.prevent="minutesTickerEl?.focus()"
            @keydown.up.prevent="increment(60 * 60)"
            @keydown.down.prevent="decrement(60 * 60)"
            @keydown.prevent="onHoursInput"
        >
            {{ labels.hours }}
        </span>:<!--
        --><span
            ref="minutesTickerEl"
            :tabindex="!disabled && time.minutes.editable ? '-1' : undefined"
            class="timespan-input__ticker"
            :class="{
                'is-focused': time.minutes.inEditMode,
                'is-disabled': !time.minutes.editable,
            }"
            :min="time.minutes.min"
            :max="time.minutes.max"
            @focus="onFocus('minutes')"
            @blur="onBlur('minutes');"
            @keydown.left.prevent="hoursTickerEl?.focus()"
            @keydown.right.prevent="secondsTickerEl?.focus()"
            @keydown.up.prevent="increment(60)"
            @keydown.down.prevent="decrement(60)"
            @keydown.prevent="onMinutesInput"
        >
            {{ labels.minutes }}
        </span>:<!--
        --><span
            ref="secondsTickerEl"
            :tabindex="!disabled && time.seconds.editable ? '-1' : undefined"
            class="timespan-input__ticker"
            :class="{
                'is-focused': time.seconds.inEditMode,
                'is-disabled': !time.seconds.editable,
            }"
            :min="time.seconds.min"
            :max="time.seconds.max"
            @focus="onFocus('seconds')"
            @blur="onBlur('seconds');"
            @keydown.left.prevent="minutesTickerEl?.focus()"
            @keydown.up.prevent="increment(1)"
            @keydown.down.prevent="decrement(1)"
            @keydown.prevent="onSecondsInput"
        >
            {{ labels.seconds }}
        </span>
    </div>
</template>

<script lang="ts">
import {
    defineComponent,
    ref,
    watch,
    reactive,
    computed,
} from 'vue';

export default defineComponent({
    name: 'TimeSpan',
    props: {
        modelValue: { type: Number, required: true },
        min: { type: Number, default: 0 },
        max: { type: Number, required: true },
        disabled: { type: Boolean, default: false },
    },
    emits: ['update:modelValue', 'change'],
    setup(props, { emit }) {
        const timespan = ref(props.modelValue);

        watch(
            () => props.modelValue,
            () => { timespan.value = props.modelValue; },
        );

        function parseTime(time: number): { hours: number, minutes: number, seconds: number } {
            const hours = Math.floor(time / 3600);
            const minutes = Math.floor((time % 3600) / 60);
            const seconds = Math.round(time - (hours * 3600) - (minutes * 60));

            return { hours, minutes, seconds };
        }

        const parsedTimespan = computed(() => parseTime(timespan.value));
        const parsedMin = computed(() => parseTime(props.min));
        const parsedMax = computed(() => parseTime(props.max));

        const time = reactive({
            hours: {
                editable: true,
                inEditMode: false,
                firstChar: true,
                val: computed(() => parsedTimespan.value.hours),
                min: computed(() => {
                    const minHours = parsedMin.value.hours;
                    const minCheck = (minHours * 60 * 60)
                        + (parsedTimespan.value.minutes * 60)
                        + parsedTimespan.value.seconds;

                    return minCheck < props.min ? minHours + 1 : minHours;
                }),
                max: computed(() => {
                    const maxHours = parsedMax.value.hours;
                    const maxCheck = (maxHours * 60 * 60)
                        + (parsedTimespan.value.minutes * 60)
                        + parsedTimespan.value.seconds;

                    return maxCheck > props.max ? maxHours - 1 : maxHours;
                }),
            },
            minutes: {
                editable: true,
                inEditMode: false,
                firstChar: true,
                val: computed(() => parsedTimespan.value.minutes),
                min: computed(() => {
                    if (parsedTimespan.value.hours > time.hours.min) {
                        return 0;
                    }

                    const minMinutes = parsedMin.value.minutes;
                    const minCheck = (parsedTimespan.value.hours * 60 * 60)
                        + (minMinutes * 60)
                        + parsedTimespan.value.seconds;

                    return minCheck < props.min ? minMinutes + 1 : minMinutes;
                }),
                max: computed(() => {
                    if (parsedTimespan.value.hours < time.hours.max) {
                        return 59;
                    }

                    const maxMinutes = parsedMax.value.minutes;
                    const maxCheck = (parsedTimespan.value.hours * 60 * 60)
                        + (maxMinutes * 60)
                        + parsedTimespan.value.seconds;

                    return maxCheck > props.max ? maxMinutes - 1 : maxMinutes;
                }),
            },
            seconds: {
                editable: true,
                inEditMode: false,
                firstChar: true,
                val: computed(() => parsedTimespan.value.seconds),
                min: computed(() => {
                    if (
                        parsedTimespan.value.hours > time.hours.min
                        || parsedTimespan.value.minutes > time.minutes.min
                    ) {
                        return 0;
                    }

                    return parsedMin.value.seconds;
                }),
                max: computed(() => {
                    if (
                        parsedTimespan.value.hours < time.hours.max
                        || parsedTimespan.value.minutes < time.minutes.max
                    ) {
                        return 59;
                    }

                    return parsedMax.value.seconds;
                }),
            },
        });

        time.hours.editable = time.hours.min !== time.hours.max;
        time.minutes.editable = time.minutes.min !== time.minutes.max;
        time.seconds.editable = time.seconds.min !== time.seconds.max;

        const labels = computed(() => ({
            hours: `${(time.hours.val < 10 ? `0${time.hours.val}` : time.hours.val)}`,
            minutes: `${(time.minutes.val < 10 ? `0${time.minutes.val}` : time.minutes.val)}`,
            seconds: `${(time.seconds.val < 10 ? `0${time.seconds.val}` : time.seconds.val)}`,
        }));

        const inFocus = computed(() => time.hours.inEditMode
            || time.minutes.inEditMode
            || time.seconds.inEditMode);

        const hoursTickerEl = ref<HTMLElement | null>(null);
        const minutesTickerEl = ref<HTMLElement | null>(null);
        const secondsTickerEl = ref<HTMLElement | null>(null);

        function updateModelValue() {
            emit('update:modelValue', timespan.value);
            emit('change', timespan.value);
        }

        function setFocus() {
            if (time.hours.editable) {
                hoursTickerEl.value?.focus();
            } else if (time.minutes.editable) {
                minutesTickerEl.value?.focus();
            } else if (time.seconds.editable) {
                secondsTickerEl.value?.focus();
            }
        }

        function onFocus(ticker: 'hours' | 'minutes' | 'seconds') {
            if (props.disabled || !time[ticker].editable) {
                return;
            }

            time[ticker].inEditMode = true;
            time[ticker].firstChar = true;
        }

        function onBlur(ticker: 'hours' | 'minutes' | 'seconds') {
            time[ticker].inEditMode = false;

            // Check minimum value
            if (timespan.value < props.min) {
                let value: null | number = null;

                if (ticker === 'hours') {
                    value = (parsedMin.value.hours * 60 * 60)
                        + (parsedTimespan.value.minutes * 60)
                        + parsedTimespan.value.seconds;
                } else if (ticker === 'minutes') {
                    value = (parsedTimespan.value.hours * 60 * 60)
                        + (parsedMin.value.minutes * 60)
                        + parsedTimespan.value.seconds;
                } else if (ticker === 'seconds') {
                    value = (parsedTimespan.value.hours * 60 * 60)
                        + (parsedTimespan.value.minutes * 60)
                        + parsedMin.value.seconds;
                }

                if (value !== null) {
                    timespan.value = value > props.min ? value : props.min;
                    updateModelValue();
                }
            }
        }

        function increment(by: number) {
            const change = timespan.value + by;

            if (change <= props.max) {
                timespan.value = change;
                updateModelValue();
            }
        }

        function decrement(by: number) {
            const change = timespan.value - by;

            if (change >= props.min) {
                timespan.value = change;
                updateModelValue();
            }
        }

        function onInput(e: KeyboardEvent, ticker: 'hours' | 'minutes' | 'seconds') {
            if (!/(digit|numpad)[0-9]/.test(e.code.toLowerCase())) {
                return;
            }

            const value = parseInt(e.key, 10);

            if (Number.isNaN(value)) {
                return;
            }

            let change: number | null = null;

            if (time[ticker].firstChar) { // Start new
                if (ticker === 'hours') {
                    change = (value * 60 * 60) + (time.minutes.val * 60) + time.seconds.val;
                } else if (ticker === 'minutes') {
                    change = (time.hours.val * 60 * 60) + (value * 60) + time.seconds.val;
                } else if (ticker === 'seconds') {
                    change = (time.hours.val * 60 * 60) + (time.minutes.val * 60) + value;
                }
            } else { // Add to current
                if (ticker === 'hours') { // eslint-disable-line no-lonely-if
                    change = (time.hours.val * 60 * 60 * 10)
                        + (value * 60 * 60)
                        + (time.minutes.val * 60)
                        + time.seconds.val;
                } else if (ticker === 'minutes') {
                    change = (time.hours.val * 60 * 60)
                        + (time.minutes.val * 60 * 10)
                        + (value * 60)
                        + time.seconds.val;
                } else if (ticker === 'seconds') {
                    change = (time.hours.val * 60 * 60)
                        + (time.minutes.val * 60)
                        + (time.seconds.val * 10)
                        + value;
                }
            }

            if (change === null || change > props.max) {
                return;
            }

            if (time[ticker].firstChar) {
                time[ticker].firstChar = false;
            }

            timespan.value = change;
            updateModelValue();

            if (time[ticker].val * 10 > time[ticker].max) {
                if (time.hours.inEditMode) {
                    minutesTickerEl.value?.focus();
                } else if (time.minutes.inEditMode) {
                    secondsTickerEl.value?.focus();
                } else if (time.seconds.inEditMode) {
                    secondsTickerEl.value?.blur();
                }
            }
        }

        function onHoursInput(e: KeyboardEvent) {
            onInput(e, 'hours');
        }

        function onMinutesInput(e: KeyboardEvent) {
            onInput(e, 'minutes');
        }

        function onSecondsInput(e: KeyboardEvent) {
            onInput(e, 'seconds');
        }

        return {
            timespan,
            labels,
            inFocus,
            time,
            hoursTickerEl,
            minutesTickerEl,
            secondsTickerEl,
            setFocus,
            onFocus,
            onBlur,
            increment,
            decrement,
            onHoursInput,
            onMinutesInput,
            onSecondsInput,
        };
    },
});
</script>
