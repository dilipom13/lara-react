<template>
    <button
        class="track--download btn--icon tooltip download-button"
        :data-tooltip="!loading ? 'Download single track' : 'Converting'"
        :disabled="disabled || loading"
    >
        <template v-if="!loading">
            <i class="icon">
                <svg>
                    <use xlink:href="#icon-download" />
                </svg>
            </i>
        </template>

        <template v-else>
            <svg
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                x="0px"
                y="0px"
                viewBox="0 0 100 100"
                enable-background="new 0 0 100 100"
                xml:space="preserve"
                class="download-button__loader"
            >
                <circle
                    cx="50"
                    cy="50"
                    :r="circleRadius"
                    stroke="#00c084"
                    stroke-width="3"
                    fill="transparent"
                    :stroke-dasharray="strokeDashArray"
                />
            </svg>
            <span class="download-button__progress">{{ progress }}</span>
        </template>
    </button>
</template>

<script lang="ts" setup>
import { computed } from 'vue';

const props = defineProps({
    disabled: { type: Boolean, default: false },
    loading: { type: Boolean, default: false },
    progress: { type: Number, default: null },
});

const circleRadius = 48;
const diameter = 2 * Math.PI * circleRadius;

const strokeDashArray = computed(() => `${(diameter * props.progress) / 100}, ${diameter}`);
</script>
