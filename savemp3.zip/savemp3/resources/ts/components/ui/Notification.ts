
import { Plugin } from 'vue';

type Notify = (
    type: 'info' | 'success' | 'warning' | 'danger',
    message: string,
    options?: {
        duration?: number,
        onClick?: () => void,
    },
) => void;

declare module '@vue/runtime-core' {
    interface ComponentCustomProperties {
        $notify: Notify
    }
}

const notify: Notify = (type, message, options = { duration: 5 }) => {
    const {
        duration,
        onClick,
    } = options;

    const content = document.createElement('p');
    content.className = 'alert-notification__text';
    content.innerText = message;

    const notification = document.createElement('div');
    notification.className = `alert-notification is-${type}`;
    notification.appendChild(content);

    notification.classList.add('is-entering'); // 0.75s
    setTimeout(() => {
        notification.classList.remove('is-entering');
    }, 800);

    function leave(n = notification) {
        n.classList.add('is-leaving');
        setTimeout(() => {
            n.remove();
        }, 1000); // Leaving animation 1s
    }

    notification.addEventListener('click', () => {
        if (onClick) {
            onClick();
        }

        leave();
    });

    document.body.appendChild(notification);

    // Leave notification
    setTimeout(() => {
        leave();
    }, ((duration || 5) * 1000) + 750); // Duration + 0.75 enter animation time

    // Move notifications
    const notifications = document.querySelectorAll<HTMLElement>('.alert-notification');

    notifications.forEach((notificationEl, i) => {
        let currentIndex = i + 1;
        let sum = 32;

        while (currentIndex < notifications.length) {
            sum += notifications[currentIndex].clientHeight + 16;
            currentIndex += 1;
        }

        // eslint-disable-next-line no-param-reassign
        notificationEl.style.bottom = `${sum}px`;
    });
};

const plugin: Plugin = {
    install(app) {
        // eslint-disable-next-line no-param-reassign
        app.config.globalProperties.$notify = notify;
    },
};

export default plugin;
