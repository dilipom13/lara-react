
<template>
    <div class="range range-slider-container">
        <div ref="sliderEl" class="range-slider" :class="{ 'is-disabled': disabled }">
            <div
                v-for="(item, index) in [
                    { knob: knobOne, offset: knobOneOffset },
                    { knob: knobTwo, offset: knobTwoOffset },
                ]"
                :key="index"
                class="range-slider__knob-container"
                :style="{ left: `${item.offset}px` }"
            >
                <span
                    :ref="el => { item.knob.el = el }"
                    class="range-slider__knob"
                    :class="{ 'is-focused': item.knob.isDragging }"
                    @mouseenter="item.knob.isHovering = true"
                    @mouseleave="item.knob.isHovering = false"
                />

                <transition name="fade">
                    <span
                        v-show="item.knob.isHovering || item.knob.isDragging"
                        class="range-slider__tooltip"
                    >
                        {{ formatTooltip(item.knob.value) }}
                    </span>
                </transition>
            </div>

            <div
                class="range-slider__track"
                :style="{ width: `${trackWidth}px`, marginLeft: `${trackOffset}px` }"
            />
        </div>

        <ul class="range-slider__labels">
            <li
                v-for="(label, index) in labels"
                :key="index"
                :style="{ left: `${label.position}%` }"
            >
                {{ label.text }}
            </li>
        </ul>
    </div>
</template>

<script lang="ts">
import {
    PropType,
    Ref,
    defineComponent,
    ref,
    reactive,
    watch,
    onMounted,
    computed,
} from 'vue';

export default defineComponent({
    name: 'RangeSlider',
    props: {
        modelValue: { type: Object as PropType<{ from: number, to: number }>, required: true },
        min: { type: Number, default: 0 },
        max: { type: Number, required: true },
        disabled: { type: Boolean, default: false },
        formatTooltip: {
            type: Function as PropType<(value: number) => string>,
            default: (value: number) => value.toString(),
        },
    },
    emits: ['update:modelValue', 'change'],
    setup(props, { emit }) {
        const sliderEl = ref<HTMLElement | null>(null) as Ref<HTMLElement | null>;

        const steps = Math.ceil(props.max / (window.innerWidth > 780 ? 8 : 5));

        let diff = steps % 30;
        diff = diff < 15 ? (-1 * diff) : (30 - diff);
        const interval = steps + diff;
        const labels: { text: string; position: number }[] = [];
        labels.push({ text: props.formatTooltip(0), position: 0 });

        if (interval > 0) {
            for (let x = interval; x <= (props.max - (interval / 2)); x += interval) {
                labels.push({
                    text: props.formatTooltip(x),
                    position: (x / props.max) * 100,
                });
            }
        }

        labels.push({ text: props.formatTooltip(props.max), position: 100 });

        const knobOne = reactive({
            el: null as null | HTMLElement,
            value: props.modelValue.from,
            isHovering: false,
            isDragging: false,
        });

        const knobTwo = reactive({
            el: null as null | HTMLElement,
            value: props.modelValue.to,
            isHovering: false,
            isDragging: false,
        });

        const knobSize = 20;
        const knobMargin = knobSize / 2;
        const sliderLength = ref(0);
        const sliderOffset = ref(0);
        const changeUnit = ref(0);

        function getKnobOffset(value: number): number {
            return ((value - props.min) / changeUnit.value) - knobMargin;
        }

        const knobOneOffset = computed(() => getKnobOffset(knobOne.value));
        const knobTwoOffset = computed(() => getKnobOffset(knobTwo.value));

        const trackOffset = computed(() => ((knobTwoOffset.value >= knobOneOffset.value
            ? knobOneOffset
            : knobTwoOffset
        ).value + knobMargin));
        const trackWidth = computed(() => Math.abs(knobTwoOffset.value - knobOneOffset.value));

        watch(
            () => [props.modelValue.from, props.modelValue.to],
            () => {
                let { from, to } = props.modelValue;

                if (from < props.min) { from = props.min; }
                if (from > props.max) { from = props.max; }

                if (to < props.min) { to = props.min; }
                if (to > props.max) { to = props.max; }

                if (knobTwo.value >= knobOne.value) {
                    knobOne.value = from;
                    knobTwo.value = to;
                } else {
                    knobTwo.value = from;
                    knobOne.value = to;
                }
            },
        );

        function updateModelValue() {
            const from = knobTwo.value >= knobOne.value ? knobOne.value : knobTwo.value;
            const to = knobTwo.value >= knobOne.value ? knobTwo.value : knobOne.value;

            emit('update:modelValue', { from, to });
            emit('change', { from, to });
        }

        onMounted(() => {
            if (!sliderEl.value) {
                return;
            }

            sliderLength.value = sliderEl.value.clientWidth;
            sliderOffset.value = sliderEl.value.getBoundingClientRect().left;
            changeUnit.value = (props.max - props.min) / sliderLength.value;

            window.addEventListener('resize', () => {
                if (sliderEl.value) {
                    sliderLength.value = sliderEl.value.clientWidth;
                    sliderOffset.value = sliderEl.value.getBoundingClientRect().left;
                    changeUnit.value = (props.max - props.min) / sliderLength.value;
                }
            });

            [knobOne, knobTwo].forEach((knob) => {
                knob.el?.addEventListener('touchstart', () => {
                    if (props.disabled) {
                        return;
                    }

                    // eslint-disable-next-line no-param-reassign
                    knob.isDragging = true;
                });

                document.addEventListener('touchend', () => {
                    if (props.disabled) {
                        return;
                    }

                    // eslint-disable-next-line no-param-reassign
                    knob.isDragging = false;
                });

                document.addEventListener('touchmove', (e) => {
                    if (props.disabled || !knob.isDragging) {
                        return;
                    }

                    const touchPos = e.touches[0].pageX;

                    // #Hack - Fixes a bug where cursor position is reported way too high
                    // when it should be 0 (on left most side of the screen)
                    if (touchPos > window.innerWidth) {
                        return;
                    }

                    let offset = touchPos - sliderOffset.value;

                    if (touchPos < sliderOffset.value) {
                        offset = 0;
                    } else if (touchPos > sliderOffset.value + sliderLength.value) {
                        offset = sliderLength.value;
                    }

                    // eslint-disable-next-line no-param-reassign
                    knob.value = Math.round((offset) * changeUnit.value) + props.min;
                    updateModelValue();
                });
            });

            [knobOne, knobTwo].forEach((knob) => {
                knob.el?.addEventListener('mousedown', () => {
                    if (props.disabled) {
                        return;
                    }

                    // eslint-disable-next-line no-param-reassign
                    knob.isDragging = true;
                });

                document.addEventListener('mouseup', () => {
                    if (props.disabled) {
                        return;
                    }

                    // eslint-disable-next-line no-param-reassign
                    knob.isDragging = false;
                });

                document.addEventListener('mousemove', (e) => {
                    if (props.disabled || !knob.isDragging) {
                        return;
                    }

                    const cursorPos = e.pageX;

                    // #Hack - Fixes a bug where cursor position is reported way too high
                    // when it should be 0 (on left most side of the screen)
                    if (cursorPos > window.innerWidth) {
                        return;
                    }

                    let offset = cursorPos - sliderOffset.value;

                    if (cursorPos < sliderOffset.value) {
                        offset = 0;
                    } else if (cursorPos > sliderOffset.value + sliderLength.value) {
                        offset = sliderLength.value;
                    }

                    // eslint-disable-next-line no-param-reassign
                    knob.value = Math.round((offset) * changeUnit.value) + props.min;
                    updateModelValue();
                });
            });
        });

        return {
            sliderEl,
            labels,
            knobOne,
            knobTwo,
            knobOneOffset,
            knobTwoOffset,
            trackOffset,
            trackWidth,
        };
    },
});
</script>
