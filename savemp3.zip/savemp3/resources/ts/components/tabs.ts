interface TabsOptions {
    tabClass: string,
    contentClass: string,
    activeClass: string
}

const tabs = (options: TabsOptions) => {
    const DOMStrings = {
        tabClass: options.tabClass,
        tabContentClass: options.contentClass,
        activeClass: options.activeClass,
    };

    const tabEls = document.querySelectorAll(`.${DOMStrings.tabClass}`);
    const tabContents = document.querySelectorAll(`.${DOMStrings.tabContentClass}`);

    if (!tabEls || !tabContents) { return; }

    const activeTab = document.querySelector(`.${DOMStrings.tabClass}.${DOMStrings.activeClass}`);

    if (activeTab) {
        const href = activeTab.getAttribute('rel');
        if (!href) { return; }

        const relatedContent = document.getElementById(href);
        if (!relatedContent) { return; }

        tabContents.forEach((tc) => {
            if (tc === relatedContent) { return; }
            tc.classList.remove(DOMStrings.activeClass);
        });

        tabEls.forEach((t) => {
            if (t === activeTab) { return; }
            t.classList.remove(DOMStrings.activeClass);
        });

        activeTab.classList.add(DOMStrings.activeClass);
        relatedContent.classList.add(DOMStrings.activeClass);
    } else {
        if (tabEls.length < 1) { return; }
        tabEls[0].classList.add(DOMStrings.activeClass);
        document.querySelector(`#${tabEls[0].getAttribute('rel')}`)?.classList.add(DOMStrings.activeClass);
    }

    tabEls.forEach((tab) => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            const href = tab.getAttribute('rel');
            if (!href) { return; }

            const relatedContent = document.getElementById(href);
            if (!relatedContent) { return; }

            tabContents.forEach((tc) => {
                if (tc === relatedContent) { return; }
                tc.classList.remove(DOMStrings.activeClass);
            });

            tabEls.forEach((t) => {
                if (t === tab) { return; }
                t.classList.remove(DOMStrings.activeClass);
            });


            tab.classList.add(DOMStrings.activeClass);
            relatedContent.classList.add(DOMStrings.activeClass);
        });
    });
};

export default tabs;
