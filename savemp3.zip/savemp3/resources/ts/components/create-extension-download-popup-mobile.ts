
export default () => {
    const wrap = document.createElement('div');
    wrap.classList.add('dd--mobile');

    const str = '<button class="dd--popup-close download--close"></button><div class="dd--details"><div class="dd--icon"><img src="./images/icon-crosspilot.png" alt="dd--icon"></div><p class="dd--desc"> <b>Crosspilot</b> extension is needed to make YouTube Video Downloader work properly.</p></div><div class="dd--actions"><a href="https://chrome.google.com/webstore/detail/crosspilot/migomhggnppjdijnfkiimcpjgnhmnale" target="_blank" class="btn--primary"><i class="icon"><img src="./images/icon-webstore.png" alt="webstore"></i><span>Let\'s Go</span></a><a class="link-text" data-fancybox="" href="https://www.youtube.com/watch?v=ol1bVODJm2g">Watch video</a></div>';

    wrap.innerHTML = str;

    return wrap;
};
