<template>
    <div class="track--wrap">
        <div
            class="track"
            :class="{
                'is-single': !multiple,
                'playing': player?.id === track.id,
                'is-loading': !!track.loading,
                'open--cut': cutterOpen,
            }"
        >
            <div v-if="!track.loading" class="track--header" :class="{ 'is-single': !multiple }">
                <div
                    class="track--thumbnail"
                    :class="{ 'is-playable': track.extractor === 'Youtube' }"
                    :style="{ backgroundImage: `url('${track.thumbnailUrl ?? defaultThumbnail}')` }"
                >
                    <div v-if="track.extractor === 'Youtube'" class="track--controls">
                        <button
                            class="track--control"
                            @click.prevent="togglePlay(track.id)"
                        >
                            <i class="icon">
                                <svg>
                                    <use
                                        :xlink:href="`#icon-${
                                            player?.id === track.id && player?.state === 'playing'
                                                ? 'pause'
                                                : 'play'
                                        }`"
                                    />
                                </svg>
                            </i>
                        </button>
                    </div>
                </div>

                <h3 class="track--title">
                    {{ track.title }}
                </h3>

                <span v-if="track.duration" class="track--duration">
                    <i class="icon">
                        <svg>
                            <use xlink:href="#icon-music" />
                        </svg>
                    </i>
                    {{ track.duration }}
                </span>

                <div class="track--cta" :style="[ !track.duration ? 'margin-left: auto;' : '' ]">
                    <download-button
                        :loading="track.requestInProgress ?? false"
                        :progress="track.requestProgress ?? undefined"
                        :disabled="track.requestInProgress ?? false"
                        v-on="track.requestInProgress ? {} : { click: () => download(false) }"
                    />

                    <button v-if="showGoogleDriveButton" class="track--download btn--icon">
                        <i class="icon">
                            <svg>
                                <use xlink:href="#icon-gdrive" />
                            </svg>
                        </i>
                    </button>

                    <button v-if="showDropboxButton" class="track--download btn--icon">
                        <i class="icon">
                            <svg>
                                <use xlink:href="#icon-dropbox" />
                            </svg>
                        </i>
                    </button>

                    <button
                        v-if="track.durationSec"
                        class="track--cut btn--icon"
                        @click.prevent="cutterOpen = true"
                    >
                        <i class="icon">
                            <svg>
                                <use xlink:href="#icon-cut" />
                            </svg>
                        </i>
                    </button>
                </div>
            </div>

            <div v-else class="track--header">
                <div class="track--thumbnail">
                    <div class="skeleton-loader" />
                </div>
                <h3 class="track--title">
                    <div class="skeleton-loader" />
                </h3>
                <span class="track--duration">
                    <div class="skeleton-loader" />
                </span>
                <div class="track--cta">
                    <div class="skeleton-loader" />
                </div>
            </div>

            <div v-if="cutterOpen && track.durationSec" class="track--body">
                <div class="player--cut">
                    <div class="range-wrapper">
                        <div class="results">
                            <div class="result-inputs">
                                <timespan
                                    v-model="time.from"
                                    :min="0"
                                    :max="time.to"
                                />
                                <timespan
                                    v-model="time.to"
                                    :min="time.from"
                                    :max="track.durationSec"
                                />

                                <span class="track--duration ml-auto">
                                    <i class="icon">
                                        <svg>
                                            <use xlink:href="#icon-music" />
                                        </svg>
                                    </i>
                                    {{ durationAfterTrim }}
                                </span>

                                <div class="track--cta">
                                    <download-button
                                        :loading="track.requestInProgress ?? false"
                                        :progress="track.requestProgress ?? undefined"
                                        :disabled="track.requestInProgress ?? false"
                                        v-on="track.requestInProgress
                                            ? {}
                                            : { click: () => download(true) }"
                                    />

                                    <button v-if="showGoogleDriveButton" class="btn--icon">
                                        <i class="icon">
                                            <svg>
                                                <use xlink:href="#icon-gdrive" />
                                            </svg>
                                        </i>
                                    </button>

                                    <button v-if="showDropboxButton" class="btn--icon">
                                        <i class="icon">
                                            <svg>
                                                <use xlink:href="#icon-dropbox" />
                                            </svg>
                                        </i>
                                    </button>

                                    <button
                                        class="track--cut btn--icon"
                                        @click.prevent="cutterOpen = false"
                                    >
                                        <i class="icon">
                                            <svg>
                                                <use xlink:href="#icon-close" />
                                            </svg>
                                        </i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <range-slider
                            v-model="time"
                            :min="0"
                            :max="track.durationSec"
                            :format-tooltip="parseVideoLength"
                        />
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts" setup>
import {
    computed,
    PropType,
    ref,
    watch,
} from 'vue';
import { Track } from '@types';
import parseVideoLength from '@helpers/parse-video-length';
import Timespan from '../ui/Timespan.vue';
import RangeSlider from '../ui/RangeSlider.vue';
import DownloadButton from '../ui/DownloadButton.vue';
import useSearchState from './search-state';

const defaultThumbnail = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEBLAEsAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCABAAEADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD+F+iilUZIFf1wtWl3PqByoW6d+nuauw2MsnSMkHHJ7e3ZeR65P41s6HpL308UaoWaR1RQBnntgknIAxkDAJ61+hP7Pn7C3xd+O99a6b4B8BeLfGWqXFs90mj+E/DOreI9Va0iUyXFyNO0i2urkW9vGvmTzeV5cKEPIwXBr0qeFoUqDxeMr0sLh4azq1pqnBLR/FKyXk++nk/teGeCs04knbB4epWSjKcuSLahTguepObSajGEE5SlLSMU5OyTt+eUGiXEmNsbHnBAUnk56ADB57gnHXuAdQ+FrxY/MNvKFxkExkDH0/z7ZxX9TXwm/wCDfr9oKfSLbxf8VNG8F/BLwJHpC61qXjf4x+NfD3hjRtEt5JIbe3t/EOmWd/q3irw9e3Nxcwwpbaz4dsvLnZYbqS1mkijl+kbb/gkD+wz4k1uw+Cfhf/goF8Itf+PfiLR0s/DnhvRfh/q2sfDnVviDqGgLfaR4Tt/i5pHibUfDbWt5rTDSLfUI4JdeuZZLaytfCMnim4tvC8/m0+J+EZVnh6OLrY72bft6uX4LGY6jQhBKVSdWrg6FeEKdOKcqkpSSjG7drH6JPwtoYHCVamLzLBupSp1pVIYN1szdGph+VVaWLnllHGQwNalp7SGMlh/YqUHV9n7Snz/xY3dhLblg6kY7HqPw6gjrnp6VlspU/wAv8+1fav7XfwG1v9n/AOKvjj4ZeJtPTS/EngjxPr3hLxDp8VzZXsdhrfhzVJ9K1W0S+0+4vLG7S2vLaeJLmyurmznCCW1uJ4Hjkb4xmUZOOxP6df0wT6mvezfLFg/ZVKbU6VanCrSlF3jOnNKUZRezTUk1Zu61W+v4xmmEhg8XOjCSlGLaUotSTs7aNaNdmrrtpYrVJEMsPw/U/wD66jq1BEzMAATkrwB3z0HqT/ntXiQi5Sil3X5nBTi5Tikr3ktPme7/AAd0+C/8UaLbzIrK97CrBh8uC+QD9OmOPvY6Yz/aVqHxz8S/sKf8Eu/2YvEP7PcekfDrxb+0PF8Zb74sfEHTdKtLnxzrcPgfxBeeD/D+m6druppev4fsrDSdfmlsZtFgs9U0XV7WHWfDeoaJqeoeI7rXP4y/gnCyeMNDyp/4/YST24YHr9Tx69ea/qt/b1uPK/4JPf8ABO9s/JLpf7S6ggjkR/EnSlOD3xnOAAwyCcBgK5eK8vjmWI4My2vTVXCYnOk6+Hmr060aWAxVVRqwd4zSlC/LJNNp8y3P6z8L6uGwHDdXEYilSmpYvExqUMRGNSjiVQ4S4ozDCwxFCpenXp4fNcDluPo06sJwhjMHhcTFKtQpTj+FHx7/AOChHx1+Luuy33jf4j+NfGd/bQf2Xaah4s8T6x4gu7XTYbi7uYrG2uNUubqW3sY7q+vrmO0gMdvHcXl1LHGGuZXf6I/4JRfEnxD4n/bi/ZaXVdQlufN/aJ+DgIkkJH7zx/oQ+ZSCD3HPB7jOTX48XWkX+rapdLZQyTPJM3CKzYyxCjIzngdc9+cYr9Tv+CTnh3WNA/bh/ZNmv7WW3R/2j/gsMuuMK3xD8Prk8dyQMY4PTPIH67lvDtKOX4/BYLL6OHw/9nY6MYUKEIQv9XnraEElrre1tPu/G+LuO81qfW8VmOPqzp0qc4UITqyUIQT5Y06cHJRjC11GMUopbJdeb/4LK3Yl/bk/asXJLJ+0b8bEJ7/J8RPEEY/4CuAOewA6V+OMp5f8f1A/+tX6wf8ABYLUPtH7d/7W0YyDH+0z8dYtpJJUR/FDxLGM5AOcqTz0+77n8nG/5afU/wAhWHHOC+oUMpoOPK45bl91ZLfDU30S7p7W7Jan4vlWdRzzD08bCoqkKrqOM1LmUkpNJpptNbW/PskKbmAx1PHc4HU4/D9PSvWPA/gjUPEt/b2FhbPNPPJGqhV3H5s8Hnp6np2zjNeZaeAZUzx/LGcn+VftF/wSX+HHgn4j/tVfATwj430y31zw94p+MPw08Oa7os9xdWqaro2s+LNNsdT0xrrT7i1v7ZNQtJpbN59PurW+iWYyWVxBdLFKvweHnSwmCxuY1acqscHh6uIdOKvKSpU/aNJPS9o6a/inb9Y8P8jw2cZpSp4qTjRTcqjjyuXJC0pKClKEXNpWinOCbdnKKTZ1nwD/AOCXn7VXinR/D3xI8JfAX4w+KfDF4JbrTfEPhz4b+LdX0TUY7K9ubC7bTtSsdKns75ba/sruzn+xzSmK8tbi3bEsMiL+sv8AwUk0bVvCf/BLz/gnb4V13TdQ0bXdFl/a20PWtJ1WyuNO1PTdU0n4uabp9/puo2F4kV1YahY3MUtteWVzFHcW1xHJDNGkqso9P/4KBf8ABR39q34ZftY+Jvhx8KPGfif4R/Dv4F+O7zwN8PfAfgp7XQfDVlongi407RNP/tTSNO02wsfFOiat/YEOrWWgeKbbWtH0rStRPh7T4DoRe3uMb/gtn8ePFnxw/YE/4Jy/Fz4h6ZPonjDxl4T+ND63DdxwWs2sX3h64+GPhuXxXHZ2ul6JZ2lv42TSovGdtZ6fpsGmWdr4gittOkurCO3vLjPIsPxHnmc8C5hmuCy2hl+MzHF4zCLCV6s8Rh2+G85xNGhiIzhGnVc6Hvzq0nyU6tLkaanCZ+mcVZ7gsgy2jgMHQoYZPEVK9WNPFVa86Mq+VZnhKGHm5YehTr1PYY9xxNek40oYiE6dCNejKGIfwP8A8Env2Uv2cvEfhn9oT9rL9rKxPiH9n39l/wAHaVqnifwNpkviK38Q+PfGnxGn1jw18OvD9hL4bl067tbOTWLOZXvz4i0OGz16XwyNVuI/C0/iXUtI/Uz9kb/gox/wTv8A2if2p/gb8JNd/wCCfXwn/Z+1SP4qeEJvgx8TvhxqiwazoXxN0iLT4vh5pvi0eAfh54H1nxXba/42tobRbrXr/UPDMV9qujXni3Qbi007VfEw/Gj/AIJZftw/s9fD/R/jX+yt+1zaXqfsx/tUaR4V0D4g+MfDdzrdr41+G3iDwFqep694B8a6L/Ytpq82paZput38sms6I2gat9quU0TU7m21fRNH1zwd4u/Qn4Z/AH/glH/wT38W+CP2zvFX/BQDwn+15rXhrQ7z4q/BD4D/AAu8Ov4U17V/iXoMOha94DPj+/8ADfjn4i654DfSr/UrG+Hhf4jaN8O55fEFh5Wt/wBqaf4Y8Y+CNU/fsNkGW1a2cyzeHF9XHYrCzocHrhuHEToSpVcjgq0cJismkslwmcwzilmlTMZcU1sNh45RHL6lWcssliHH+DPFLjHMZ46eAwsqClGrh3VWKngY0acFiqUnPEYbFz+t4nC4mjL2VJ5XRr4mddVaFJQxMKF/wM/4K45/4b5/bEGc4/ah+O56Y4b4neI2H553HuTnPJNfly3O8+pP8hX0/wDtY/HLV/2hvjh8U/jH4gttIsdd+KHxC8ZfETW7DQYLq20Sx1fxn4hv/EOoWmk299falew6ba3V/Lb2UV7qF/dJbJGs97czCSeT5eY4U++cfQk/06V8l4qYqjUzGjRjOEp4bDYTD1PZyVSHtaFCnSqck4rlnHnhLlkrXVnbU+n8OsFiMFwzllLEwnTq+xnVlCouWpD203UUZwesZpSipRbdmtG1qTWsoidW/unnPbnIOe3I69ueK+sP2evjp4h+DHjPw74z8L63qWga74e1jTNb0fWtIvrjTtT0jVtJu473TdT06+tXjns7+xu4obm2uIHjmgmiSSORXUMPkUEg8fj71dhuXjxtY8YIAOCOnp39/f8AP82yzGU6EpQrQjUpTi4VITXNGUJJRlGUX7rTTaaaaevofrGT51iMorKrQm4NPeOj3T3X+TVvkf2C6h/wWc/Y4+NWmeD/ABt+1f8AsK+CvjV8ddD0fTtO8U/FLSfi5r/wu/4T2fRAlvpWseIfCPhbwq+kXmqNpdpp9hqS6pLrFi62722k2ei+HlsfDVl+Pn/BTj/gpp40/bn8dafIdPtPAfwl8A6dN4V+CvwY8O3iv4N+FPghDZ29tpGlQ22n6PYXmsXljpmkQa/4gg0XSv7VXStK0+y07SPDuh+HdA0b8jP7WugpXzZNvXAc+nXDdcdNvPbANZ80xlOWJPGCWYk9R3J6D2wenPHP0uX47hvIacKuVZdOliqVGvRwrrY3MMXRwNPFOLxEMuwmKxdfCZdGokqbWBo4flo3oRaoN03x51mFbNq0ak51eWMrwpc8/ZQ1VlTpuThSpwVlCnSUKUUrRikklfi1W6glMsM0kbbslkbBJB55BGfxx7jk1fn8UavPF5Ut7MybQrAs53Dnr0B6nqPeuYLgEgAEeuf5fj9f60eZ7frWUOOc4owqUqOJq06c27whUkoq9ui02/FLXt89UyrCV6ka1ahSqVY25ZzpxlKNmnpJptdbWdlfTqyZ5GcksSe+ScnI9/T8R6YxVdjk+w6UFievT0ptfKYzG18bVlVrzc5S1bfe9+/f5noU6caceWK0/pfp/nc//9k=';
const showGoogleDriveButton = SAVEMP3_GLOB.google_drive_global === '1';
const showDropboxButton = SAVEMP3_GLOB.dropbox_drive_global === '1';

const { player, togglePlay, downloadTrack } = useSearchState();

const props = defineProps({
    track: { type: Object as PropType<Track>, required: true },
    multiple: { type: Boolean, default: false },
    show: { type: Boolean, default: true },
});

const cutterOpen = ref(false);
const time = ref({ from: 0, to: props.track.durationSec ?? 0 });

watch(() => props.track.durationSec, () => {
    time.value.to = props.track.durationSec ?? 0;
});

const durationAfterTrim = computed(() => {
    const diff = time.value.to - time.value.from;
    return parseVideoLength(diff);
});

function download(trim = false) {
    const selectEl = document.querySelector<HTMLSelectElement>('.select-menu .quality-hidden-select');
    const optionEls = selectEl?.querySelectorAll('option');

    if (!selectEl || !optionEls) return;

    const bitrate = parseInt(optionEls[selectEl.selectedIndex].value, 10);
    const task = props.track.tasks.find((v) => v.bitrate === bitrate);

    if (!task) return;

    if (!trim) {
        downloadTrack(props.track, task);
    } else {
        downloadTrack(
            props.track,
            task,
            time.value.from !== 0 ? time.value.from : null,
            time.value.to < props.track.durationSec ? time.value.to : null,
        );
    }
}
</script>
