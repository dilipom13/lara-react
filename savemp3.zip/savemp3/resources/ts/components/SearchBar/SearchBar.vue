<template>
    <div id="search-bar" class="search-bar">
        <div
            class="search"
            :class="{
                'focus': focused && !completed,
                'preparing': loading,
                'completed': completed,
            }"
        >
            <input
                v-model="search"
                type="url"
                class="search--input"
                :placeholder="inputPlaceholder"
                @input="onInput"
                @focus="focused = true"
            >

            <div
                class="search--cta"
                v-on="!loading ? { click: pasteText } : {}"
            >
                <span class="text">
                    {{ loading ? 'Preparing' : 'Paste Link' }}
                </span>
            </div>

            <button class="search--clear" @click.prevent="resetForm">
                <i class="icon">
                    <svg>
                        <use xlink:href="#icon-close" />
                    </svg>
                </i>
            </button>
        </div>

        <p v-if="searchError || error" class="search--error">
            {{ error ? error : searchError }}
        </p>

        <div v-if="completed" class="search--result">
            <track-item v-if="track !== null" :track="track" />
        </div>

        <div id="yt-player" />

        <player-card v-if="completed" />
    </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';

import extractService from './extract-service';
import useSearchState from './search-state';
import TrackItem from './TrackItem.vue';
import PlayerCard from './PlayerCard.vue';

const inputPlaceholder = SAVEMP3_GLOB.search_bar_placeholder;

const {
    loading,
    completed,
    track,
    reset,
    fetchTrack,
    error,
} = useSearchState();

const search = ref('');
const searchError = ref<string | null>(null);
const focused = ref(false);

function onInput() {
    if (!search.value) {
        searchError.value = null;
        return;
    }

    const url = search.value;
    const service = extractService(url);

    if (!service) {
        searchError.value = 'URL is unsupported.';
        return;
    }

    searchError.value = null;
    const { type } = service;

    if (type === 'track') {
        fetchTrack(url);
    } else {
        searchError.value = 'Playlists are not supported.';
    }
}

const url = (new URL(window.location.href)).searchParams.get('url');
if (url) {
    focused.value = true;
    search.value = url;
    onInput();
}

async function pasteText() {
    if (navigator.clipboard) {
        search.value = await navigator.clipboard.readText();

        onInput();
    }
}

function resetForm() {
    reset();
    search.value = '';
    focused.value = false;
}
</script>
