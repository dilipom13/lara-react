<template>
    <div
        v-if="player && player.track"
        class="player-card"
    >
        <div
            class="player-card__thumbnail"
            :style="{ backgroundImage: `url('${player.track.thumbnailUrl}')` }"
        >
            <div class="player-card__controls">
                <button
                    class="player-card__control"
                    @click.prevent="togglePlay(player.track.id)"
                >
                    <i class="icon">
                        <svg>
                            <use
                                :xlink:href="`#icon-${
                                    player.id === player.track.id && player.state === 'playing'
                                        ? 'pause'
                                        : 'play'
                                }`"
                            />
                        </svg>
                    </i>
                </button>
            </div>
        </div>

        <h3 class="player-card__title">
            {{ player.track.title }}
        </h3>
    </div>
</template>

<script lang="ts" setup>
import useSearchState from './search-state';

const { player, togglePlay } = useSearchState();
</script>
