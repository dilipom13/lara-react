
import axios, { AxiosError, AxiosResponse } from 'axios';

import {
    Extractor,
    Track,
    TrackResponse,
    APITask,
    TaskResponse,
} from '@types';
import parseVideoLength from '@helpers/parse-video-length';

export default class DownloaderApi {
    // eslint-disable-next-line class-methods-use-this
    private generateThumbnail(extractor: Extractor, videoId: string): string | null {
        switch (extractor) {
            case 'Youtube': return `http://i3.ytimg.com/vi/${videoId}/hqdefault.jpg`;
            case 'Dailymotion': return `https://www.dailymotion.com/thumbnail/video/${videoId}`;
            default: return null;
        }
    }

    public async getInfo(url: string): Promise<Track> {
        const response = await axios.post<TrackResponse>('/wp-json/api/v1/get_video_info', { url });
        const { data } = response;

        if (data.error) {
            throw new Error(data.message);
        }

        const durationSec = parseFloat(data.lengthSeconds);

        return {
            extractor: data.extractor,
            id: data.videoId,
            title: data.title,
            trackUrl: url,
            thumbnailUrl: this.generateThumbnail(data.extractor, data.videoId),
            durationSec,
            duration: parseVideoLength(durationSec),
            tasks: data.tasks,
        };
    }

    // eslint-disable-next-line class-methods-use-this
    public async download(
        task: APITask,
        length: number,
        from: number | null = null,
        to: number | null = null,
        onProgress?: (progress: number) => void,
    ): Promise<string | null> {
        return new Promise((resolve, reject) => {
            axios.post<{ taskId: string }>(
                '/wp-json/api/v1/download',
                {
                    hash: task.hash,
                    length,
                    from,
                    to,
                },
            ).then((response) => {
                const { taskId } = response.data;

                function fetchStatus() {
                    setTimeout(async () => {
                        let res: AxiosResponse<TaskResponse>;

                        try {
                            res = await axios.post<TaskResponse>('/wp-json/api/v1/status', { taskId });
                        } catch (error) {
                            fetchStatus();
                            return;
                        }

                        if (res.data.status === 'finished') {
                            resolve(res.data.download ?? null);
                        } else if (res.data.status === 'failed') {
                            resolve(null);
                        } else {
                            if (onProgress) onProgress(res.data.convert_progress);
                            fetchStatus();
                        }
                    }, 1500);
                }

                fetchStatus();
            }).catch((error) => {
                const err = error as AxiosError<{ message: string }>;

                if (err.response && err.response.data) {
                    reject(new Error(err.response.data.message));
                } else {
                    reject(new Error(err.message));
                }
            });
        });
    }
}
