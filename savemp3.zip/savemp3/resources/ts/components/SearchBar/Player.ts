
import YouTubePlayer from 'youtube-player';
import { Extractor } from '@types';
import PlayerStates from 'youtube-player/dist/constants/PlayerStates';

export default class Player {
    private players = {
        youtube: YouTubePlayer('yt-player', {
            width: 0,
            height: 0,
            playerVars: { autoplay: 1, controls: 1 },
        }),
    };

    private currentTrack: string | null = null;

    public constructor(private service: Extractor) {
        this.players.youtube.on('stateChange', () => {
            // TODO: add listener for state change on media buttons
        });
    }

    public async toggle(id: string) {
        if (this.service === 'Youtube') {
            if (this.currentTrack === id) {
                const state = await this.players.youtube.getPlayerState();

                if (state === PlayerStates.PLAYING) {
                    await this.players.youtube.pauseVideo();
                } else {
                    await this.players.youtube.playVideo();
                }
            } else {
                this.currentTrack = id;
                await this.players.youtube.loadVideoById(id);
                await this.players.youtube.playVideo();
            }
        }
    }

    public async stop() {
        if (this.service === 'Youtube') {
            await this.players.youtube.stopVideo();
            await this.players.youtube.destroy();
        }
    }
}
