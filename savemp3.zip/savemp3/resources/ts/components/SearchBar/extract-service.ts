
const services = [
    {
        name: 'Youtube',
        hostRegex: /youtu(?:be)?(?:-nocookie)?\.(?:com|be)/,
        trackRegex: /(?:youtube(?:-nocookie)?\.com\/(?:[^/\n\s]+\/\S+\/|(?:v|e(?:mbed)?|(?:shorts))\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
        playlistRegex: [
            /((?:(FL|PL|UU|LL)[a-zA-Z0-9-_]{16,41})|(?:UC[a-zA-Z0-9-_]{22,32})|(?:(RDC|O)LAK5uy_[a-zA-Z0-9-_]{33}))/,
            /\/c\/(\w+)/,
        ],
    },
    {
        name: 'Facebook',
        hostRegex: /(www|m|mbasic|business)?\.?(?:facebook|fb)\.(com|watch)/,
        trackRegex: [
            /(?:(?:www|m|mbasic|business)\.(?:facebook|fb)\.com\/)(?:gaming\/)?(?:photo(?:\.php|s)|permalink\.php|video\.php|media|watch\/?|questions|reel|notes|[^/]+\/(?:activity|posts|videos|photos))[/?](?:fbid=|story_fbid=|id=|b=|v=|)(([0-9]+)|[^/]+\/(\d+))/,
            /fb\.watch\/(\w+)/,
        ],
    },
    {
        name: 'Instagram',
        hostRegex: /(www\.)?instagram\.com/,
        trackRegex: /(?:www\.)?instagram\.com\S*?\/p\/(\w{11})\/?/,
    },
    {
        name: 'Twitter',
        hostRegex: /twitter\.com/,
        trackRegex: /twitter\.com\/(?:#!\/)?(?:\w+)\/status(?:es)?\/(\d+)/,
    },
    {
        name: 'Dailymotion',
        hostRegex: /(?:www\.)?dai\.?ly(?:motion)?(?:\.com)?/,
        trackRegex: /(?:www\.)?dai\.?ly(?:motion)?(?:\.com)?\/?.*(?:video|embed)?(?:.*v=|v\/|\/)([a-z0-9]+)/,
    },
    {
        name: 'Vimeo',
        hostRegex: /(?:www.)?vimeo.com/,
        trackRegex: /(?:www.)?vimeo.com\/([0-9]{9})/,
    },
    {
        name: 'VK',
        hostRegex: /vk\.com/,
        trackRegex: /(?:vk\.com)(?:.*)(?:(?:audio|video)(?:-|)((?:[0-9]+)_(?:[0-9]+)))/,
    },
    {
        name: 'SoundCloud',
        hostRegex: /(soundcloud\.com|snd\.sc)/,
        trackRegex: /(?:soundcloud\.com|snd\.sc)\/([^?]+)/,
        playlistRegex: /(?:soundcloud\.com|snd\.sc)\/([^?]+)\/sets\/([^?]+)/,
    },
    {
        name: 'Tiktok',
        hostRegex: /(?:www|m)\.(?:tiktok.com)/,
        trackRegex: /(?:(?:www|m)\.(?:tiktok.com)\/(?:v|embed|trending|(?:@[\w\-.]+)\/video\/)(?:\/)?(?:\?shareId=)?)([\da-z]+)/,
    },
];

export default (url: string): {
    name: string;
    type: 'track' | 'playlist';
    id: string;
} | null => {
    let host: string;
    let href: string;

    try {
        ({ host, href } = new URL(url));
    } catch (error) {
        return null;
    }


    for (let i = 0; i < services.length; i += 1) {
        const {
            name,
            hostRegex,
            trackRegex,
            playlistRegex,
        } = services[i];

        if (hostRegex.test(host)) {
            let matches: RegExpMatchArray | null;

            if (typeof playlistRegex !== 'undefined') {
                if (Array.isArray(playlistRegex)) {
                    for (let j = 0; j < playlistRegex.length; j += 1) {
                        matches = href.match(playlistRegex[j]);
                        if (matches) {
                            return { name, type: 'playlist', id: matches[1] };
                        }
                    }
                } else {
                    matches = href.match(playlistRegex);

                    if (matches) {
                        return { name, type: 'playlist', id: matches[1] };
                    }
                }
            }

            if (Array.isArray(trackRegex)) {
                for (let j = 0; j < trackRegex.length; j += 1) {
                    matches = href.match(trackRegex[j]);

                    if (matches) {
                        return { name, type: 'track', id: matches[1] };
                    }
                }
            } else {
                matches = href.match(trackRegex);

                if (matches) {
                    return { name, type: 'track', id: matches[1] };
                }
            }
        }
    }

    return null;
};
