<template>
    <div v-if="playlist" class="playlist">
        <!-- <div class="playlist--controls">
            <button class="btn--download tooltip" data-tooltip="Download playlist">
                <i class="icon">
                    <svg>
                        <use xlink:href="#icon-download" />
                    </svg>
                </i>
                <span class="text">Download</span>
            </button>

            <button class="btn--icon">
                <i class="icon">
                    <svg>
                        <use xlink:href="#icon-gdrive" />
                    </svg>
                </i>
            </button>

            <button class="btn--icon">
                <i class="icon">
                    <svg>
                        <use xlink:href="#icon-dropbox" />
                    </svg>
                </i>
            </button>
        </div> -->

        <track-item
            v-for="(track, index) in playlist.tracks"
            v-show="index < playlist.showItems"
            :key="index"
            :track="track"
            :multiple="true"
        />

        <button
            v-if="playlist.itemsCount > playlist.showItems && !loadingMore"
            class="btn--text-loading playlist--loadmore"
            @click.prevent="loadMorePlaylistItems"
        >
            <span class="text">Load more</span>
        </button>
    </div>
</template>

<script lang="ts" setup>
import TrackItem from './TrackItem.vue';
import useSearchState from './search-state';

const { playlist, loadingMore, loadMorePlaylistItems } = useSearchState();
</script>
