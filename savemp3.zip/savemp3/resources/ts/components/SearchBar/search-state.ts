
import {
    computed,
    ComputedRef,
    getCurrentInstance,
    reactive,
    toRefs,
    ToRefs,
} from 'vue';

import {
    APITask,
    SearchState,
    Track,
} from '@types';
import DownloaderApi from './DownloaderApi';
import Player from './Player';

const state = reactive<SearchState>({
    loading: false,
    error: null,
    track: null,
    player: null,
});
let player: Player | null = null;
let downloader: DownloaderApi;


const useSearchState = (): ToRefs<SearchState> & {
    completed: ComputedRef<boolean>;
    reset(): void;
    fetchTrack(url: string): Promise<void>;
    togglePlay(id: string): void;
    downloadTrack(
    track: Track,
    task: APITask,
    from?: number | null,
    to?: number | null
    ): Promise<void>;
} => {
    if (typeof downloader === 'undefined') {
        downloader = new DownloaderApi();
    }

    const completed = computed(() => !state.loading && (state.track !== null));

    const instance = getCurrentInstance()?.proxy;

    function reset() {
        player?.stop();
        player = null;

        state.loading = false;
        state.error = null;
        state.track = null;
        state.player = null;
    }

    async function fetchTrack(url: string) {
        reset();
        state.loading = true;
        let track: Track;

        try {
            track = await downloader.getInfo(url);
        } catch (error) {
            state.error = (error as Error).message;
            state.loading = false;
            return;
        }

        state.track = track;
        player = new Player(track.extractor);
        state.loading = false;
    }

    function togglePlay(id: string) {
        player?.toggle(id);
        if (!state.track) return;

        if (!state.player || state.player.id !== id) {
            state.player = { id, track: state.track, state: 'playing' };
        } else if (state.player.id === id) {
            state.player.state = state.player.state === 'playing' ? 'paused' : 'playing';
        }
    }

    async function downloadTrack(
        track: Track,
        task: APITask,
        from: number | null = null,
        to: number | null = null,
    ) {
        /* eslint-disable no-param-reassign */
        track.requestInProgress = true;
        track.requestProgress = Math.floor(Math.random() * (7 - 3 + 1) + 3);
        let downloadUrl: string | null;

        try {
            downloadUrl = await downloader.download(
                task,
                track.durationSec,
                from,
                to,
                (progress) => {
                    track.requestProgress = progress;
                },
            );
        } catch (error) {
            instance?.$notify('danger', (error as Error).message);
            track.requestInProgress = false;
            delete track.requestProgress;
            return;
        }

        track.requestInProgress = false;
        delete track.requestProgress;

        if (!downloadUrl) {
            instance?.$notify('danger', 'Failed to get download url.');
            return;
        }

        const a = document.createElement('a');
        a.toggleAttribute('download');
        a.href = downloadUrl;
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        setTimeout(a.remove, 500);
        /* eslint-enable */
    }

    return {
        ...toRefs(state),
        completed,
        reset,
        fetchTrack,
        togglePlay,
        downloadTrack,
    };
};

export default useSearchState;
