const popup = {
    init: (selector: string) => {
        const DOMStrings = {
            selector,
            init: `${selector}--init`,
            close: `${selector}--close`,
            active: 'is-active',
            show: 'show',
        };

        const elements = document.querySelectorAll(`.${DOMStrings.selector}`);

        if (elements.length < 1) { return; }

        document.addEventListener('click', (e) => {
            const target = <HTMLElement>e.target;

            if (target.classList.contains(DOMStrings.init) || target.closest(`.${DOMStrings.init}`)) {
                e.preventDefault();
                const href = target.getAttribute('rel') || target.closest(`.${DOMStrings.init}`)?.getAttribute('rel');
                if (!href) { return; }

                const matchingEl = document.getElementById(href);

                if (matchingEl) {
                    matchingEl.classList.add(DOMStrings.active);

                    setTimeout(() => { matchingEl.classList.add(DOMStrings.show); }, 100);
                }
            } else if (target.closest(`.${DOMStrings.close}`)) {
                elements.forEach((element) => {
                    element.classList.remove(DOMStrings.show);

                    setTimeout(() => {
                        element.classList.remove(DOMStrings.active);
                    }, 100);
                });
            }
        });
    },
};

export default popup;
