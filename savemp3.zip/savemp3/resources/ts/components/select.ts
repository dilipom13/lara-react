
const select = (() => {
    const createSelectElement = (
        element: HTMLSelectElement,
        onChange?: (el: HTMLSelectElement, selected: HTMLOptionElement) => void,
    ) => {
        const customElement = document.createElement('div');
        customElement.classList.add('custom-select-container');

        const labelElement = document.createElement('span');
        labelElement.classList.add('custom-select-value');

        const optionsCustomElement = document.createElement('ul');
        optionsCustomElement.classList.add('custom-select-options');

        element.classList.contains('top');
        optionsCustomElement.classList.add('top');

        const options = element.querySelectorAll('option');

        options.forEach((option, index) => {
            const optionData = {
                label: option.label,
                value: option.value,
                selected: option.selected,
                hidden: option.hidden,
            };

            if (option.selected) {
                labelElement.innerText = option.label;
            }

            const customOptionElement = document.createElement('li');
            customOptionElement.classList.add('custom-select-option');
            customOptionElement.classList.toggle('selected', optionData.selected);

            customOptionElement.innerText = optionData.label;
            customOptionElement.dataset.value = optionData.value;
            if (option.hidden) {
                customOptionElement.classList.add('hide');
            }
            customOptionElement.addEventListener('click', () => {
                labelElement.innerText = optionData.label;
                options.forEach((v) => v.removeAttribute('selected'));
                optionsCustomElement.querySelectorAll('li').forEach((item) => item.classList.remove('selected'));
                options[index].setAttribute('selected', '');
                customOptionElement.classList.add('selected');
                optionsCustomElement.classList.remove('show');
                element.dispatchEvent(new Event('change'));

                if (onChange) {
                    onChange(element, options[index]);
                }
            });

            optionsCustomElement.append(customOptionElement);
        });

        customElement.append(labelElement);
        customElement.append(optionsCustomElement);
        // eslint-disable-next-line no-param-reassign
        element.style.display = 'none';
        element.after(customElement);

        customElement.tabIndex = 0;
        customElement.addEventListener('keydown', (e) => {
            switch (e.code) {
                case 'Space': {
                    optionsCustomElement.classList.toggle('show');
                    labelElement.classList.toggle('open');
                    break;
                }

                case 'ArrowUp': {
                    const selectedElement = optionsCustomElement.querySelector('li.selected');
                    const selectedOption = Array.from(options).find((option) => option.selected);

                    const prevElement = selectedElement?.previousElementSibling;
                    const prevOption = <HTMLOptionElement>selectedOption?.previousElementSibling;
                    if (!prevElement) { return; }

                    selectedElement.classList.remove('selected');
                    selectedOption?.removeAttribute('selected');
                    labelElement.innerText = prevOption.label;
                    prevElement?.classList.add('selected');
                    prevElement.scrollIntoView({ block: 'nearest' });
                    prevOption?.setAttribute('selected', '');

                    // if (onChange) {
                    //     onChange(prevOption);
                    // }

                    break;
                }

                case 'ArrowDown': {
                    const selectedElement = optionsCustomElement.querySelector('li.selected');
                    const selectedOption = Array.from(options).find((option) => option.selected);

                    const nextElement = selectedElement?.nextElementSibling;
                    const nextOption = <HTMLOptionElement>selectedOption?.nextElementSibling!; // eslint-disable-line @typescript-eslint/no-non-null-assertion, @typescript-eslint/no-non-null-asserted-optional-chain, max-len

                    if (!nextElement) { return; }

                    selectedElement.classList.remove('selected');
                    selectedOption?.removeAttribute('selected');
                    labelElement.innerText = nextOption.label;
                    nextElement?.classList.add('selected');
                    nextElement.scrollIntoView({ block: 'nearest' });
                    nextOption?.setAttribute('selected', '');

                    // if (onChange) {
                    //     onChange(nextOption);
                    // }

                    break;
                }

                case 'Escape':
                case 'Enter': {
                    optionsCustomElement.classList.toggle('show');
                    labelElement.classList.toggle('open');
                    break;
                }

                default: {
                    //
                }
            }
        });
    };

    document.addEventListener('click', (e) => {
        const target = <HTMLElement>e.target;
        const selectOptions = document.querySelectorAll('.custom-select-options');
        const clickedOutSide = target.closest('.custom-select-options') === null;

        if (target.closest('.custom-select-value')) {
            target.closest('.custom-select-value')?.classList.add('open');

            selectOptions.forEach((option) => {
                if (option === target.nextElementSibling) { return; }
                option.classList.remove('show');
                option.closest('.custom-select-container')?.querySelector('.custom-select-value')?.classList.remove('open');
            });

            if (target.nextElementSibling?.classList.contains('show')) {
                target.nextElementSibling?.classList.remove('show');
                target.closest('.custom-select-value')?.classList.remove('open');
            } else {
                target.nextElementSibling?.classList.add('show');
                target.closest('.custom-select-value')?.classList.add('open');
            }
        } else if (clickedOutSide) {
            selectOptions.forEach((option) => {
                option.classList.remove('show');
                option.closest('.custom-select-container')?.querySelector('.custom-select-value')?.classList.remove('open');
            });
        }
    });
    return {
        init: (
            selector: string,
            onChange?: (el: HTMLSelectElement, selected: HTMLOptionElement) => void,
        ) => {
            const selectElements: NodeListOf<HTMLSelectElement> = document.querySelectorAll(`.${selector}`);

            selectElements.forEach((element) => {
                const parent = element.parentElement;
                const checkElement = parent?.querySelector('.custom-select-container');

                if (checkElement) { return; }
                createSelectElement(element, onChange);
            });
        },
        refresh: (el: HTMLSelectElement) => {
            el.nextElementSibling?.remove();
            createSelectElement(el);
        },
    };
})();

export default select;
