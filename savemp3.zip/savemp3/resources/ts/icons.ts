
const req = require.context('../icons', true, /\w+\.svg$/i);
req.keys().forEach(req);
