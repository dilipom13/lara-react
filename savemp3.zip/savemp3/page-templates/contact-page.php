<?php
/**
 * Template Name: Contact Page
 * @link https://codex.wordpress.org/Template_Hierarchy
 * @package Savemp3
 * @since 1.0
 */
get_header();
?>

<main>
    <div class="container">
        <h1 class="page--title"><?php echo get_the_title(); ?></h1>
        <article>
            <?php the_content(); ?>
        </article>

        <div class="contact">
            <form class="contactForm">
                <div class="form--groups">
                    <div class="form--group">
                        <label for="name"><?php _e('Name', 'savemp3'); ?></label>
                        <input type="text" name="name" id="name" placeholder="<?php _e('Enter your full name', 'savemp3'); ?>">
                    </div>
                    <div class="form--group">
                        <label for="email"><?php _e('Email', 'savemp3'); ?></label>
                        <input type="email" name="email" id="email" placeholder="<?php _e('Enter your email', 'savemp3'); ?>">

                    </div>
                </div>
                <div class="form--group">
                    <label for="title"><?php _e('Title', 'savemp3'); ?></label>
                    <input type="text" name="title" id="title" placeholder="<?php _e('Enter message title', 'savemp3'); ?>">
                </div>
                <div class="form--group">
                    <label for="message"><?php _e('Message', 'savemp3'); ?></label>
                    <textarea name="message" id="message" cols="30" rows="10" placeholder="<?php _e('Enter your message', 'savemp3'); ?>"></textarea>
                </div>
                <button class="btn--loading" type="submit">
                    <i class="icon">
                        <svg>
                            <use xlink:href="#icon-send"></use>
                        </svg>
                    </i>
                    <span class="text"><?php _e('Submit', 'savemp3'); ?></span>
                </button>
            </form>
        </div>
    </div>
</main>

<?php get_footer();
