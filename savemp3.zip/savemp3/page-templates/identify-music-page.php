<?php
/**
 * Template Name: Identify music Page
 * @link https://codex.wordpress.org/Template_Hierarchy
 * @package Savemp3
 * @since 1.1.10
 */

global $post, $savemp3_options, $browser;

get_header();

$prefix                 = SVMP3_META_PREFIX; // Metabox prefix

$main_lang_post_id = apply_filters( 'wpml_object_id', $post->ID, 'page', true, 'en' );

$show_extensions_card   = get_post_meta( $post->ID, $prefix.'show_extensions_card', true );

$related_articles       = get_post_meta( $main_lang_post_id, $prefix.'related_articles', true );

$card_title             = !empty( $savemp3_options['card_title'] )?$savemp3_options['card_title'] : '';
$card_description       = !empty( $savemp3_options['card_description'] )?$savemp3_options['card_description'] : '';
$card_image             = !empty( $savemp3_options['card_image'] )?$savemp3_options['card_image'] : '';
$icon_scr               = !empty($card_image['icon_scr'])?$card_image['icon_scr']:'';
$icon_id                = !empty($card_image['icon_id'])?$card_image['icon_id']:'';
?>

<div class="trending--wrap container">
	<main>
		<h1 class="page--title">Identify Music</h1>

		<div class="im--wrap">
			<div class="im--header">
				<ul class="im--tabs">
					<li class="im--tab is-active" rel="im-upload">
						<i class="icon">
							<svg>
								<use xlink:href="#icon-upload"></use>
							</svg>
						</i>

						Upload
					</li>

					<li class="im--tab " rel="im-add-url">
						<i class="icon">
							<svg>
								<use xlink:href="#icon-url
							"></use>
							</svg>
						</i>

						Add Url
					</li>
				</ul>
			</div>

			<div class="im--body">
				<div class="im--content" id="im-upload">
					<div class="im--upload">
						<i class="icon">
							<svg>
								<use xlink:href="#icon-identify-music"></use>
							</svg>
						</i>

						<p>Drag files here to upload.</p>
						<p>Alternatively, you can select a file by </p>

						<input type="file" class="upload--file" data-label="Upload files">
					</div>
				</div>

				<div class="im--content" id="im-add-url">
					<div class="im--url">
						<div class="search">
							<input type="url" class="search--input"
								placeholder="Paste YouTube video, Channel or Playlist link here">

							<div class="search--cta">
								<span class="text">Paste Link</span>
							</div>

							<button class="search--clear">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-close"></use>
									</svg>
								</i>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php include SVMP3_DIR . '/template-parts/extension.php';?>

		<div class="section--hidden active">
			<?php include SVMP3_DIR . '/template-parts/how-to-use.php'; ?>
		</div>

		<?php include SVMP3_DIR . '/template-parts/supported-sites.php'; ?>

		<div class="section--hidden active">
			<?php include SVMP3_DIR . '/template-parts/related-articles.php'; ?>
		</div>
	</main>
</div>

<?php get_footer( );
