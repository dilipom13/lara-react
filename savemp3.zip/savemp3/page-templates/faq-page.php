<?php
/**
 * Template Name: FAQ Page
 * @link https://codex.wordpress.org/Template_Hierarchy
 * @package Savemp3
 * @since 1.0
 */
get_header(); 
?>

<main>
    <div class="container">
        <h1 class="page--title"><?php echo get_the_title(); ?></h1>
        <?php the_content(); ?>
    </div>
</main>

<?php get_footer(); 