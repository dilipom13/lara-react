<?php
/**
 * Template Name: Converter Page
 * @link https://codex.wordpress.org/Template_Hierarchy
 * @package Savemp3
 * @since 1.0
 */

global $post,$savemp3_options,$browser;
$custom_home_page            = !empty( $savemp3_options['home_page'] )?$savemp3_options['home_page'] : '';
if( ( is_front_page() || is_home() ) && !empty( $custom_home_page ) ){

    $current_language       = apply_filters( 'wpml_current_language', NULL );
    $custom_home_page    = apply_filters( 'wpml_object_id', $custom_home_page, 'page', true, $current_language );
    wp_redirect( get_permalink( $custom_home_page ), 301 );
    exit;
}

get_header();




$main_lang_post_id = apply_filters( 'wpml_object_id', $post->ID, 'page', true, 'en' );



$prefix                 = SVMP3_META_PREFIX; // Metabox prefix
$input_placeholder      = get_post_meta( $post->ID, $prefix.'input_placeholder', true );

$download_video_url     = get_post_meta( $post->ID, $prefix.'download_video_url', true );
$show_extensions_card   = get_post_meta( $post->ID, $prefix.'show_extensions_card', true );



$how_to_use_title               = get_post_meta( $post->ID, $prefix.'how_to_use_title', true );




//$related_articles       = get_post_meta( $post->ID, $prefix.'related_articles', true );
$related_articles       = get_post_meta( $main_lang_post_id, $prefix.'related_articles', true );



$card_title             = !empty( $savemp3_options['card_title'] )?$savemp3_options['card_title'] : '';
$card_description       = !empty( $savemp3_options['card_description'] )?$savemp3_options['card_description'] : '';
$card_image             = !empty( $savemp3_options['card_image'] )?$savemp3_options['card_image'] : '';
$icon_scr               = !empty($card_image['icon_scr'])?$card_image['icon_scr']:'';
$icon_id                = !empty($card_image['icon_id'])?$card_image['icon_id']:'';

$default_placeholder    = !empty( $savemp3_options['default_placeholder'] )?$savemp3_options['default_placeholder']:'';
$input_placeholder      = !empty( $input_placeholder )?$input_placeholder:$default_placeholder;

?>
<main>
	<?php include SVMP3_DIR . '/template-parts/hero.php'; ?>
	<?php include SVMP3_DIR . '/template-parts/extension.php';?>

	<div class="section--hidden active">
		<?php include SVMP3_DIR . '/template-parts/how-to-use.php'; ?>
	</div>

	<?php include SVMP3_DIR . '/template-parts/supported-sites.php'; ?>

	<div class="section--hidden active">
		<?php include SVMP3_DIR . '/template-parts/related-articles.php'; ?>
	</div>
</main>
<?php

get_footer();
