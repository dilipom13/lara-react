<?php
/**
 * Template Name: Trending Page
 * @link https://codex.wordpress.org/Template_Hierarchy
 * @package Savemp3
 * @since 1.1.10
 */

get_header();
?>

<div class="trending--wrap container">
	<main>
		<h1 class="page--title">Trending tracks</h1>

		<div class="trending">
			<div class="track--wrap">
				<div class="track is-single open--cut">
					<div class="track--header is-single">
						<div class="track--thumbnail is-playable"
							style="background-image: url(&quot;http://i3.ytimg.com/vi/atygrkDwCLo/hqdefault.jpg&quot;);">
							<div class="track--controls">
								<button class="track--control">
									<i class="icon">
										<svg>
											<use xlink:href="#icon-play"></use>
										</svg>
									</i>
								</button>
							</div>
						</div>

						<h3 class="track--title">Mooroo Podcast #60 Suneel Sarfraz Munj</h3>

						<span class="track--duration">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-music"></use>
								</svg>
							</i>
							01:21:07
						</span>

						<div class="track--cta">
							<button class="track--download btn--icon tooltip download-button"
								data-tooltip="Download single track">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-download"></use>
									</svg>
								</i>
							</button>

							<button class="track--cut btn--icon">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-cut"></use>
									</svg>
								</i>
							</button>
						</div>
					</div>

					<div class="track--body">
						<div class="player--cut">
							<div class="range-wrapper">
								<div class="results">
									<div class="result-inputs">
										<div class="timespan-input"><span tabindex="-1" class="timespan-input__ticker"
												min="0" max="1">00</span>:

											<span tabindex="-1" class="timespan-input__ticker" min="0"
												max="59">00</span>:

											<span tabindex="-1" class="timespan-input__ticker" min="0"
												max="59">00</span>
										</div>
										<div class="timespan-input"><span tabindex="-1" class="timespan-input__ticker"
												min="0" max="1">01</span>:

											<span tabindex="-1" class="timespan-input__ticker" min="0"
												max="21">21</span>:

											<span tabindex="-1" class="timespan-input__ticker" min="0" max="7">07</span>
										</div><span class="track--duration ml-auto"><i class="icon"><svg>
													<use xlink:href="#icon-music"></use>
												</svg></i> 01:21:07</span>
										<div class="track--cta"><button
												class="track--download btn--icon tooltip download-button"
												data-tooltip="Download single track"><i class="icon"><svg>
														<use xlink:href="#icon-download"></use>
													</svg></i></button>

											<button class="track--cut btn--icon"><i class="icon"><svg>
														<use xlink:href="#icon-close"></use>
													</svg></i></button>
										</div>
									</div>
								</div>
								<div class="range range-slider-container">
									<div class="range-slider">
										<div class="range-slider__knob-container" style="left: -10px;"><span
												class="range-slider__knob"></span><span class="range-slider__tooltip"
												style="display: none;">00:00</span></div>
										<div class="range-slider__knob-container" style="left: 818px;"><span
												class="range-slider__knob"></span><span class="range-slider__tooltip"
												style="display: none;">01:21:07</span></div>
										<div class="range-slider__track" style="width: 828px; margin-left: 0px;"></div>
									</div>
									<ul class="range-slider__labels">
										<li style="left: 0%;">00:00</li>
										<li style="left: 12.3279%;">10:00</li>
										<li style="left: 24.6558%;">20:00</li>
										<li style="left: 36.9838%;">30:00</li>
										<li style="left: 49.3117%;">40:00</li>
										<li style="left: 61.6396%;">50:00</li>
										<li style="left: 73.9675%;">01:00:00</li>
										<li style="left: 86.2955%;">01:10:00</li>
										<li style="left: 100%;">01:21:07</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="track is-single">
					<div class="track--header is-single">
						<div class="track--thumbnail is-playable"
							style="background-image: url(&quot;http://i3.ytimg.com/vi/atygrkDwCLo/hqdefault.jpg&quot;);">
							<div class="track--controls">
								<button class="track--control">
									<i class="icon">
										<svg>
											<use xlink:href="#icon-play"></use>
										</svg>
									</i>
								</button>
							</div>
						</div>

						<h3 class="track--title">Moore Podcast #60 Suneel Sarfraz Munj</h3>

						<ul class="track--meta">
							<li class="track--links">
								<a href="#">Ghost</a>
								<a href="#">Maldy</a>
							</li>

							<li class="track--links">
								<a href="#">LOKERA</a>
							</li>
						</ul>

						<span class="track--duration">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-music"></use>
								</svg>
							</i> 01:21:07
						</span>

						<div class="track--cta">
							<button class="track--download btn--icon tooltip download-button"
								data-tooltip="Download single track">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-download"></use>
									</svg>
								</i>
							</button>

							<button class="track--cut btn--icon">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-cut"></use>
									</svg>
								</i>
							</button>
						</div>
					</div>
				</div>

				<div class="track is-single">
					<div class="track--header is-single">
						<div class="track--thumbnail is-playable"
							style="background-image: url(&quot;http://i3.ytimg.com/vi/atygrkDwCLo/hqdefault.jpg&quot;);">
							<div class="track--controls">
								<button class="track--control">
									<i class="icon">
										<svg>
											<use xlink:href="#icon-play"></use>
										</svg>
									</i>
								</button>
							</div>
						</div>

						<h3 class="track--title">Moore Podcast #60 Suneel Sarfraz Munj</h3>

						<ul class="track--meta">
							<li class="track--links">
								<a href="#">Ghost</a>
								<a href="#">Maldy</a>
							</li>

							<li class="track--links">
								<a href="#">LOKERA</a>
							</li>
						</ul>

						<span class="track--duration">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-music"></use>
								</svg>
							</i> 01:21:07
						</span>

						<div class="track--cta">
							<button class="track--download btn--icon tooltip download-button"
								data-tooltip="Download single track">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-download"></use>
									</svg>
								</i>
							</button>

							<button class="track--cut btn--icon">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-cut"></use>
									</svg>
								</i>
							</button>
						</div>
					</div>
				</div>

				<div class="track is-single">
					<div class="track--header is-single">
						<div class="track--thumbnail is-playable"
							style="background-image: url(&quot;http://i3.ytimg.com/vi/atygrkDwCLo/hqdefault.jpg&quot;);">
							<div class="track--controls">
								<button class="track--control">
									<i class="icon">
										<svg>
											<use xlink:href="#icon-play"></use>
										</svg>
									</i>
								</button>
							</div>
						</div>

						<h3 class="track--title">Moore Podcast #60 Suneel Sarfraz Munj</h3>

						<ul class="track--meta">
							<li class="track--links">
								<a href="#">Ghost</a>
								<a href="#">Maldy</a>
							</li>

							<li class="track--links">
								<a href="#">LOKERA</a>
							</li>
						</ul>

						<span class="track--duration">
							<i class="icon">
								<svg>
									<use xlink:href="#icon-music"></use>
								</svg>
							</i> 01:21:07
						</span>

						<div class="track--cta">
							<button class="track--download btn--icon tooltip download-button"
								data-tooltip="Download single track">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-download"></use>
									</svg>
								</i>
							</button>

							<button class="track--cut btn--icon">
								<i class="icon">
									<svg>
										<use xlink:href="#icon-cut"></use>
									</svg>
								</i>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</main>
</div>

<?php get_footer( );
