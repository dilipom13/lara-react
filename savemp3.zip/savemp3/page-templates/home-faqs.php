<div class="faqs" itemscope="itemscope" itemtype="https://schema.org/FAQPage">
    <div class="faq" itemscope="itemscope" itemprop="mainEntity" itemtype="https://schema.org/Question">
        <div class="faq--question">
            <h3 itemprop="name">
                How do I choose a publisher?
            </h3>
        </div>

        <div class="faq--answer" itemscope="itemscope" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
            <div class="faq--body" itemprop="text">
                <p>
                    Use filters to get a list of the most relevant websites. There are ten handy filters
                    to help you with this goal.
                </p>
                <p>
                    Start from metrics like DA and DR to ensure you are getting backlinks from authority
                    sources. Continue with filters like monthly traffic, and links. Set your GEO
                    preferences by picking a language and country.
                </p>
                <p>
                    Decide what service type you need - content placement or content creation and
                    placement. After this, choose if you want your posts to be marked as sponsored or
                    not. Also, you can select a precise price range you are interested in.
                </p>
            </div>
        </div>
    </div>

    <div class="faq" itemscope="itemscope" itemprop="mainEntity" itemtype="https://schema.org/Question">
        <div class="faq--question">
            <h3 itemprop="name">
                How do I choose a publisher?
            </h3>
        </div>

        <div class="faq--answer" itemscope="itemscope" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
            <div class="faq--body" itemprop="text">
                <p>
                    Use filters to get a list of the most relevant websites. There are ten handy filters
                    to help you with this goal.
                </p>
                <p>
                    Start from metrics like DA and DR to ensure you are getting backlinks from authority
                    sources. Continue with filters like monthly traffic, and links. Set your GEO
                    preferences by picking a language and country.
                </p>
                <p>
                    Decide what service type you need - content placement or content creation and
                    placement. After this, choose if you want your posts to be marked as sponsored or
                    not. Also, you can select a precise price range you are interested in.
                </p>
            </div>
        </div>
    </div>

    <div class="faq" itemscope="itemscope" itemprop="mainEntity" itemtype="https://schema.org/Question">
        <div class="faq--question">
            <h3 itemprop="name">
                How do I choose a publisher?
            </h3>
        </div>

        <div class="faq--answer" itemscope="itemscope" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
            <div class="faq--body" itemprop="text">
                <p>
                    Use filters to get a list of the most relevant websites. There are ten handy filters
                    to help you with this goal.
                </p>
                <p>
                    Start from metrics like DA and DR to ensure you are getting backlinks from authority
                    sources. Continue with filters like monthly traffic, and links. Set your GEO
                    preferences by picking a language and country.
                </p>
                <p>
                    Decide what service type you need - content placement or content creation and
                    placement. After this, choose if you want your posts to be marked as sponsored or
                    not. Also, you can select a precise price range you are interested in.
                </p>
            </div>
        </div>
    </div>

    <div class="faq" itemscope="itemscope" itemprop="mainEntity" itemtype="https://schema.org/Question">
        <div class="faq--question">
            <h3 itemprop="name">
                How do I choose a publisher?
            </h3>
        </div>

        <div class="faq--answer" itemscope="itemscope" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
            <div class="faq--body" itemprop="text">
                <p>
                    Use filters to get a list of the most relevant websites. There are ten handy filters
                    to help you with this goal.
                </p>
                <p>
                    Start from metrics like DA and DR to ensure you are getting backlinks from authority
                    sources. Continue with filters like monthly traffic, and links. Set your GEO
                    preferences by picking a language and country.
                </p>
                <p>
                    Decide what service type you need - content placement or content creation and
                    placement. After this, choose if you want your posts to be marked as sponsored or
                    not. Also, you can select a precise price range you are interested in.
                </p>
            </div>
        </div>
    </div>
</div>
