<?php
/**
 * Template Name: Privacy Page
 * @link https://codex.wordpress.org/Template_Hierarchy
 * @package Savemp3
 * @since 1.0
 */
get_header(); 
global $post;
?>
<main>
    <div class="container">
        <h1 class="page--title"><?php echo get_the_title(); ?></h1>
        <article>
            <p>Last updated: <?php  echo date("M j, Y", strtotime( $post->post_modified ) ); ?></p>
            <?php the_content(); ?>
        </article>

    </div>
</main>

<?php get_footer(); 