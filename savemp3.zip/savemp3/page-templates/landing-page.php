<?php
/**
 * Template Name: Landing Page
 * @link https://codex.wordpress.org/Template_Hierarchy
 * @package Savemp3
 * @since 1.0
 */
get_header(); 

global $post,$savemp3_options,$browser;
?>

<div class="container--landing">
    <a href="<?php echo site_url(); ?>" class="back-to-home tooltip tooltip--bottom" data-tooltip="Back to Home">
        <i class="icon">
            <svg>
                <use xlink:href="#icon-back"></use>
            </svg>
        </i>
    </a>

    <section class="landing--section landing--hero">
        <div class="landing--hero-content">
            <div class="landing--icon">
                <img src="<?php echo SVMP3_URL; ?>/images/logo.png" alt="landing image">
            </div>

            <h1 class="landing--hero-title h1">Carrd </h1>
            <p class="landing--hero-subtitle">Simple, free, fully responsive one-page sites for pretty much
                anything.</p>

            <div class="landing--hero-cta">
                <div class="download landing--download">
                    <button class="btn--solid download--init">
                        <i class="icon">
                            <svg>
                                <use xlink:href="#icon-<?php echo strtolower($browser['browser_name']); ?>"></use>
                            </svg>
                        </i>
                        <span class="text">Add to <?php echo $browser['browser_name']; ?></span>
                    </button>

                    <div class="dd--popup download--dropdown" id="main-download">
                        <button class="dd--popup-close download--close"></button>

                        <div class="dd--details">
                            <div class="dd--icon">
                                <img src="<?php echo SVMP3_URL; ?>/images/icon-crosspilot.png" alt="dd--icon">
                            </div>

                            <p class="dd--desc"> <b>Crosspilot</b> extension is needed to make YouTube Video
                                Downloader work properly.</p>
                        </div>

                        <div class="dd--actions">
                            <a href="https://chrome.google.com/webstore/detail/crosspilot/migomhggnppjdijnfkiimcpjgnhmnale"
                                target="_blank" class="btn--solid is-small">
                                <i class="icon"><img src="<?php echo SVMP3_URL; ?>/images/icon-webstore.png" alt="webstore"></i>
                                <span>Let's Go</span>
                            </a>

                            <a class="link-text" data-fancybox="" href="https://www.youtube.com/watch?v=ol1bVODJm2g">
                                Watch video
                            </a>
                        </div>
                    </div>
                </div>

                <div class="browsers">
                    <span class="text">Other Browsers</span>

                    <div class="browsers--list">
                        <a href="#" class="browser">
                            <i class="icon">
                                <svg>
                                    <use xlink:href="#icon-chrome"></use>
                                </svg>
                            </i>
                        </a>
                        <a href="#" class="browser">
                            <i class="icon">
                                <svg>
                                    <use xlink:href="#icon-firefox"></use>
                                </svg>
                            </i>
                        </a>
                        <a href="#" class="browser">
                            <i class="icon">
                                <svg>
                                    <use xlink:href="#icon-edge"></use>
                                </svg>
                            </i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <a href="#landing-about" class="btn--transparent small go-to-next">What is Carrd?</a>
    </section>

    <section class="landing--section landing--about" id="landing-about">
        <header class="about--header">
            <h2 class="about--title h1">
                Build one-page sites for <br>
                pretty much anything
            </h2>

            <p>
                Whether it's a personal profile, a landing page to capture emails, or something a bit more
                elaborate, Carrd has you covered. Simple, responsive, and yup — totally free.
            </p>
        </header>

        <div class="about--showcase"></div>
    </section>

    <section class="landing--section landing--highlights">
        <div class="highlight">
            <div class="highlight--img"></div>

            <div class="highlight--content">
                <h3 class="highlight--title h2">Simple</h3>
                <p class="highlight--desc">
                    Start with one of dozens of templates (or a blank canvas) and make it your own.
                </p>
            </div>
        </div>
        <div class="highlight">
            <div class="highlight--img"></div>

            <div class="highlight--content">
                <h3 class="highlight--title h2">Simple</h3>
                <p class="highlight--desc">
                    Start with one of dozens of templates (or a blank canvas) and make it your own.
                </p>
            </div>
        </div>
        <div class="highlight">
            <div class="highlight--img"></div>

            <div class="highlight--content">
                <h3 class="highlight--title h2">Simple</h3>
                <p class="highlight--desc">
                    Start with one of dozens of templates (or a blank canvas) and make it your own.
                </p>
            </div>
        </div>
    </section>

    <section class="landing--section landing--features">
        <div class="features--header">
            <h2 class="features--title h2">Optional: Go Pro!</h2>

            <p>
                Upgrade your Carrd experience! Go Pro from just $19 / year (yup, per year) <br> and get access
                to Pro-exclusive features like:
            </p>
        </div>

        <div class="features--content">
            <div class="features--list">
                <div class="feature">
                    <h3 class="feature--title h3">Custom Domains</h3>
                    <p class="feature--desc">Publish sites to any custom domains you own with full SSL support (via
                        Let's Encrypt).</p>
                </div>

                <div class="feature">
                    <h3 class="feature--title h3">More Sites</h3>
                    <p class="feature--desc">Build and publish more than three sites from a single Carrd account.
                    </p>
                </div>

                <div class="feature">
                    <h3 class="feature--title h3">Forms</h3>
                    <p class="feature--desc">Add contact, signup (using ActiveCampaign, Buttondown, ConvertKit,
                        EmailOctopus, GetResponse, MailChimp, MailerLite, Revue, SendFox, Sendinblue, and Sendy),
                        custom, and payment-enabled forms.</p>
                </div>

                <div class="feature">
                    <h3 class="feature--title h3">Widgets + Embeds</h3>
                    <p class="feature--desc">Embed your own custom code and widgets from third-party services like
                        Stripe, PayPal, Gumroad, Typeform, and more.</p>
                </div>

                <div class="feature">
                    <h3 class="feature--title h3">Google Analytics</h3>
                    <p class="feature--desc">Add an optional Google Analytics tracking ID to each of your sites to
                        track
                        and report traffic.</p>
                </div>

                <div class="feature">
                    <h3 class="feature--title h3">No Branding</h3>
                    <p class="feature--desc">Publish sites without the "Made with Carrd" branding in the footer.</p>
                </div>
            </div>

            <div class="features--cta">
                <p>
                    <strong>Try it free for 7 days.</strong> PayPal and all major credit and debit cards accepted.
                </p>
                <button class="btn--transparent">Learn More</button>
            </div>
        </div>
    </section>

    <section class="landing--section landing--cta">
        <h2 class="landing--cta-title h2">Sounds good?</h2>

        <p class="landing--cta-desc">Click below to get started. No signup required.</p>

        <div class="download landing--download">
            <button class="btn--solid download--init">
                <i class="icon">
                    <svg>
                        <use xlink:href="#icon-<?php echo strtolower($browser['browser_name']); ?>"></use>
                    </svg>
                </i>
                <span class="text">Add to <?php echo $browser['browser_name']; ?></span>
            </button>

            <div class="dd--popup download--dropdown" id="main-download">
                <button class="dd--popup-close download--close"></button>

                <div class="dd--details">
                    <div class="dd--icon">
                        <img src="<?php echo SVMP3_URL; ?>/images/icon-crosspilot.png" alt="dd--icon">
                    </div>

                    <p class="dd--desc"> <b>Crosspilot</b> extension is needed to make YouTube Video
                        Downloader work properly.</p>
                </div>

                <div class="dd--actions">
                    <a href="https://chrome.google.com/webstore/detail/crosspilot/migomhggnppjdijnfkiimcpjgnhmnale"
                        target="_blank" class="btn--solid is-small">
                        <i class="icon"><img src="<?php echo SVMP3_URL; ?>/images/icon-webstore.png" alt="webstore"></i>
                        <span>Let's Go</span>
                    </a>

                    <a class="link-text" data-fancybox="" href="https://www.youtube.com/watch?v=ol1bVODJm2g">
                        Watch video
                    </a>
                </div>
            </div>
        </div>
    </section>
</div>

<?php get_footer(); 